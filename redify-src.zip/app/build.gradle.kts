import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    alias(libs.plugins.kotlin.jvm)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.compose.multiplatform)
    alias(libs.plugins.compose.compiler)
}

kotlin {
    jvmToolchain(21)
}

dependencies {
    implementation(project(":innertube"))
    implementation(project(":lrclib"))
    implementation(libs.sqlite)
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation(compose.materialIconsExtended)
    implementation(libs.coroutines.core)
    implementation(libs.coroutines.swing)
    implementation(libs.serialization.json)
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.coil)
    implementation(libs.coil.network.okhttp)
    implementation(libs.vlcj)
}

compose.desktop {
    application {
        mainClass = "com.redify.desktop.MainKt"

        nativeDistributions {
            targetFormats(TargetFormat.Msi, TargetFormat.Exe, TargetFormat.Dmg, TargetFormat.Deb)
            packageName = "Redify"
            packageVersion = "2.3.3"
            description = "Redify - YouTube Music client"
            vendor = "Redify"
            // Ship the whole JDK module set: sqlite-jdbc, JNA (vlcj), OkHttp TLS and Coil
            // each pull in modules that jlink's auto-detection misses.
            includeAllModules = true

            windows {
                menuGroup = "Redify"
                shortcut = true
                perUserInstall = true
                iconFile.set(project.file("src/main/resources/icon.ico"))
            }
        }
    }
}
