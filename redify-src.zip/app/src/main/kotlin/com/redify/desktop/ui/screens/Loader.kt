package com.redify.desktop.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.redify.desktop.ui.ErrorBox
import com.redify.desktop.ui.LoadingBox

sealed class Load<out T> {
    data object Loading : Load<Nothing>()
    data class Error(val message: String) : Load<Nothing>()
    data class Ready<T>(val value: T) : Load<T>()
}

class Loader<T>(private val fetch: suspend () -> Result<T>) {
    var state by mutableStateOf<Load<T>>(Load.Loading)
        private set
    var attempt by mutableIntStateOf(0)
        private set

    suspend fun run() {
        state = Load.Loading
        state = fetch().fold(
            onSuccess = { Load.Ready(it) },
            onFailure = { Load.Error(it.message ?: it.toString()) },
        )
    }

    fun retry() { attempt++ }
}

/** Loads [fetch] once per [key] and renders loading / error / content states. */
@Composable
fun <T> Loaded(
    key: Any,
    fetch: suspend () -> Result<T>,
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit,
) {
    val loader = remember(key) { Loader(fetch) }
    LaunchedEffect(key, loader.attempt) { loader.run() }
    when (val s = loader.state) {
        Load.Loading -> LoadingBox(modifier)
        is Load.Error -> ErrorBox(s.message, onRetry = { loader.retry() }, modifier = modifier)
        is Load.Ready -> content(s.value)
    }
}
