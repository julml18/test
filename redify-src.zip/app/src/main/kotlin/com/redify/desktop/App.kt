package com.redify.desktop

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redify.desktop.playback.PlayerController
import com.redify.desktop.ui.Artwork
import com.redify.desktop.ui.player.PlayerScreen
import com.redify.desktop.ui.player.StylesScreen
import com.redify.desktop.ui.screens.AlbumScreen
import com.redify.desktop.ui.screens.ArtistItemsScreen
import com.redify.desktop.ui.screens.ArtistScreen
import com.redify.desktop.ui.screens.BrowseScreen
import com.redify.desktop.ui.screens.ExploreScreen
import com.redify.desktop.ui.screens.HomeScreen
import com.redify.desktop.ui.screens.ImportScreen
import com.redify.desktop.ui.screens.LibraryScreen
import com.redify.desktop.ui.screens.LocalPlaylistScreen
import com.redify.desktop.ui.screens.PlaylistScreen
import com.redify.desktop.ui.screens.SearchPage
import com.redify.desktop.ui.screens.ProfileScreen
import com.redify.desktop.ui.screens.SettingsHubScreen
import com.redify.desktop.ui.screens.SettingsPageScreen

val LocalNavigator = compositionLocalOf<Navigator> { error("Navigator not provided") }
val LocalPlayer = compositionLocalOf<PlayerController> { error("PlayerController not provided") }
val LocalOpenPlayer = compositionLocalOf<() -> Unit> { {} }

/** Musicfy-style shell: full-bleed content, floating mini-player + pill navigation, expanded player overlay. */
@Composable
fun App(player: PlayerController) {
    val nav = remember { Navigator() }
    var playerOpen by remember { mutableStateOf(false) }
    val state by player.state.collectAsState()

    CompositionLocalProvider(
        LocalNavigator provides nav,
        LocalPlayer provides player,
        LocalOpenPlayer provides { playerOpen = true },
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .onPreviewKeyEvent { event ->
                    when (event.key) {
                        Key.MediaPlayPause -> { player.togglePlayPause(); true }
                        Key.MediaNext -> { player.next(); true }
                        Key.MediaPrevious -> { player.previous(); true }
                        Key.Escape -> if (playerOpen) { playerOpen = false; true } else false
                        else -> false
                    }
                },
        ) {
            // Page content
            Box(Modifier.fillMaxSize()) {
                when (val screen = nav.current) {
                    Screen.Home -> HomeScreen()
                    Screen.Explore -> ExploreScreen()
                    Screen.Library -> LibraryScreen()
                    Screen.Settings -> ProfileScreen()
                    Screen.SettingsHub -> SettingsHubScreen()
                    is Screen.SettingsPage -> if (screen.key == "styles") StylesScreen() else SettingsPageScreen(screen.key)
                    Screen.Import -> ImportScreen()
                    is Screen.Search -> SearchPage(screen.query)
                    is Screen.Album -> AlbumScreen(screen.browseId)
                    is Screen.Artist -> ArtistScreen(screen.browseId)
                    is Screen.Playlist -> PlaylistScreen(screen.playlistId)
                    is Screen.LocalPlaylist -> LocalPlaylistScreen(screen.id)
                    is Screen.ArtistItems -> ArtistItemsScreen(screen.title, screen.endpoint)
                    is Screen.Browse -> BrowseScreen(screen.title, screen.browseId, screen.params)
                }
                if (nav.canGoBack && nav.current != Screen.Home) {
                    IconButton(
                        onClick = nav::back,
                        modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                            .clip(CircleShape).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
                    ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") }
                }
            }

            // Floating mini player + navigation pill
            Column(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AnimatedVisibility(visible = state.current != null, enter = fadeIn() + slideInVertically { it / 2 }, exit = fadeOut() + slideOutVertically { it / 2 }) {
                    MiniPlayer(onOpen = { playerOpen = true })
                }
                Spacer(Modifier.height(10.dp))
                PillNav(nav)
            }

            AnimatedVisibility(
                visible = playerOpen,
                enter = fadeIn() + slideInVertically { it / 3 },
                exit = fadeOut() + slideOutVertically { it / 3 },
            ) {
                PlayerScreen(onCollapse = { playerOpen = false })
            }
        }
    }
}

@Composable
private fun MiniPlayer(onOpen: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current ?: return
    Row(
        Modifier
            .width(560.dp)
            .shadow(16.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xFF151517))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(22.dp))
            .clickable(onClick = onOpen)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(song.thumbnail, Modifier.size(56.dp), RoundedCornerShape(12.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                state.error ?: listOfNotNull(song.artists.joinToString { it.name }.ifBlank { null }, song.album?.name).joinToString(" — "),
                color = if (state.error != null) Color(0xFFFF8A80) else Color.White.copy(alpha = 0.65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        IconButton(onClick = player::previous) { Icon(Icons.Default.FastRewind, "Sebelumnya", tint = Color.White, modifier = Modifier.size(28.dp)) }
        IconButton(onClick = player::togglePlayPause) {
            if (state.isBuffering) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
            else Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Putar", tint = Color.White, modifier = Modifier.size(28.dp))
        }
        IconButton(onClick = player::next) { Icon(Icons.Default.FastForward, "Berikutnya", tint = Color.White, modifier = Modifier.size(28.dp)) }
    }
}

@Composable
private fun PillNav(nav: Navigator) {
    val root = nav.stack.first()
    Row(
        Modifier
            .shadow(16.dp, CircleShape)
            .clip(CircleShape)
            .background(Color(0xFF151517))
            .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NavPill(Icons.Default.Home, "Beranda", root == Screen.Home && nav.stack.size == 1) { nav.replaceRoot(Screen.Home) }
        NavPill(Icons.Default.Search, "Cari", root is Screen.Search) { nav.replaceRoot(Screen.Search("")) }
        NavPill(Icons.Default.LibraryMusic, "Koleksi", root == Screen.Library) { nav.replaceRoot(Screen.Library) }
        NavPill(Icons.Default.Settings, "Profil", root == Screen.Settings) { nav.replaceRoot(Screen.Settings) }
    }
}

@Composable
private fun NavPill(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White.copy(alpha = 0.16f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = if (selected) 18.dp else 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, tint = Color.White.copy(alpha = if (selected) 1f else 0.7f), modifier = Modifier.size(24.dp))
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
