package com.redify.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redify.desktop.LocalPlayer
import com.redify.desktop.data.Lyrics
import com.redify.desktop.data.LyricsProvider

/**
 * Full-screen "now playing" view: big artwork on the left, large synced lyrics on the right,
 * tinted with the artwork palette - the desktop take on Musicfy's expanded player.
 */
@Composable
fun NowPlayingScreen(onClose: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current

    var lyrics by remember { mutableStateOf<Lyrics?>(null) }
    var loading by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(song?.id) {
        lyrics = null
        if (song == null) return@LaunchedEffect
        loading = true
        lyrics = runCatching { LyricsProvider.forSong(song) }.getOrNull()
        loading = false
    }

    val activeIndex = lyrics?.indexAt(com.redify.desktop.ui.player.rememberLivePosition()) ?: -1
    LaunchedEffect(activeIndex) {
        if (activeIndex >= 0) listState.animateScrollToItem(activeIndex, scrollOffset = -220)
    }

    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(scheme.primaryContainer.copy(alpha = 0.35f), scheme.background))),
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 32.dp)) {
            // Left: artwork + title
            Column(
                Modifier.weight(0.9f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Artwork(
                    song?.thumbnail,
                    Modifier.size(380.dp).shadow(24.dp, RoundedCornerShape(16.dp)),
                    RoundedCornerShape(16.dp),
                )
                Spacer(Modifier.height(28.dp))
                Text(
                    song?.title ?: "Tidak ada yang diputar",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    song?.artists?.joinToString { it.name } ?: "",
                    style = MaterialTheme.typography.titleMedium,
                    color = scheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Spacer(Modifier.size(32.dp))

            // Right: lyrics
            Box(Modifier.weight(1.3f).fillMaxHeight()) {
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    lyrics == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            if (song == null) "" else "Lirik tidak tersedia",
                            style = MaterialTheme.typography.titleLarge,
                            color = scheme.onSurfaceVariant,
                        )
                    }
                    else -> {
                        val l = lyrics!!
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 200.dp, bottom = 260.dp, end = 24.dp),
                        ) {
                            itemsIndexed(l.lines) { i, line ->
                                val active = i == activeIndex
                                val passed = l.synced && i < activeIndex
                                Text(
                                    line.text.ifBlank { "♪" },
                                    fontSize = if (l.synced) 34.sp else 24.sp,
                                    lineHeight = if (l.synced) 44.sp else 34.sp,
                                    fontWeight = if (active || !l.synced) FontWeight.Bold else FontWeight.SemiBold,
                                    color = when {
                                        active || !l.synced -> scheme.onSurface
                                        passed -> scheme.onSurfaceVariant.copy(alpha = 0.35f)
                                        else -> scheme.onSurfaceVariant.copy(alpha = 0.55f)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = l.synced) { player.seekTo(line.timeMs) }
                                        .padding(vertical = 10.dp),
                                )
                            }
                        }
                        Text(
                            "Lirik: ${l.source}",
                            Modifier.align(Alignment.BottomEnd).padding(8.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = scheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)) {
            Icon(Icons.Default.FullscreenExit, "Keluar layar penuh")
        }
    }
}
