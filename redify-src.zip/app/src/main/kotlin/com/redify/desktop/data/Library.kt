package com.redify.desktop.data

import com.music.innertube.YouTube
import com.music.innertube.models.SongItem
import com.redify.desktop.appDataDir
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.sql.Connection
import java.sql.DriverManager

data class LocalPlaylist(
    val id: Long,
    val name: String,
    val songCount: Int,
    val thumbnail: String?,
)

data class HistoryEntry(val song: SongItem, val playedAt: Long)

/**
 * Local library (liked songs, playlists, history) - the desktop counterpart of
 * Musicfy's Room database, implemented with plain SQLite/JDBC to keep the build simple.
 */
object Library {
    private val json = Json { ignoreUnknownKeys = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val conn: Connection

    private val _liked = MutableStateFlow<List<SongItem>>(emptyList())
    val liked: StateFlow<List<SongItem>> = _liked
    private val _likedIds = MutableStateFlow<Set<String>>(emptySet())
    val likedIds: StateFlow<Set<String>> = _likedIds
    private val _playlists = MutableStateFlow<List<LocalPlaylist>>(emptyList())
    val playlists: StateFlow<List<LocalPlaylist>> = _playlists
    private val _history = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val history: StateFlow<List<HistoryEntry>> = _history

    init {
        val dbFile = File(appDataDir(), "library.db")
        conn = DriverManager.getConnection("jdbc:sqlite:${dbFile.absolutePath}")
        conn.createStatement().use { st ->
            st.executeUpdate(
                """
                CREATE TABLE IF NOT EXISTS songs (
                    id TEXT PRIMARY KEY,
                    json TEXT NOT NULL,
                    liked INTEGER NOT NULL DEFAULT 0,
                    liked_at INTEGER,
                    play_count INTEGER NOT NULL DEFAULT 0,
                    last_played INTEGER
                )
                """.trimIndent()
            )
            st.executeUpdate(
                """
                CREATE TABLE IF NOT EXISTS playlists (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                )
                """.trimIndent()
            )
            st.executeUpdate(
                """
                CREATE TABLE IF NOT EXISTS playlist_songs (
                    playlist_id INTEGER NOT NULL,
                    song_id TEXT NOT NULL,
                    position INTEGER NOT NULL,
                    PRIMARY KEY (playlist_id, song_id)
                )
                """.trimIndent()
            )
            st.executeUpdate(
                """
                CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    song_id TEXT NOT NULL,
                    played_at INTEGER NOT NULL
                )
                """.trimIndent()
            )
        }
        refreshAll()
    }

    // ---- Songs ----------------------------------------------------------------

    @Synchronized
    private fun upsertSong(song: SongItem) {
        conn.prepareStatement(
            "INSERT INTO songs (id, json) VALUES (?, ?) ON CONFLICT(id) DO UPDATE SET json = excluded.json"
        ).use {
            it.setString(1, song.id)
            it.setString(2, json.encodeToString(song))
            it.executeUpdate()
        }
    }

    @Synchronized
    private fun readSong(id: String): SongItem? =
        conn.prepareStatement("SELECT json FROM songs WHERE id = ?").use { ps ->
            ps.setString(1, id)
            ps.executeQuery().use { rs -> if (rs.next()) decode(rs.getString(1)) else null }
        }

    private fun decode(text: String): SongItem? = runCatching { json.decodeFromString<SongItem>(text) }.getOrNull()

    // ---- Liked ----------------------------------------------------------------

    fun isLiked(id: String): Boolean = id in _likedIds.value

    fun toggleLike(song: SongItem) = scope.launch {
        val liked = !isLiked(song.id)
        synchronized(this@Library) {
            upsertSong(song)
            conn.prepareStatement("UPDATE songs SET liked = ?, liked_at = ? WHERE id = ?").use {
                it.setInt(1, if (liked) 1 else 0)
                it.setLong(2, System.currentTimeMillis())
                it.setString(3, song.id)
                it.executeUpdate()
            }
        }
        refreshLiked()
        // Mirror the like to the signed-in YouTube Music account (Musicfy does the same).
        if (Settings.current.isLoggedIn) YouTube.likeVideo(song.id, liked)
    }

    // ---- Playlists --------------------------------------------------------------

    fun createPlaylist(name: String, firstSong: SongItem? = null) = scope.launch {
        val id = createPlaylistSync(name)
        if (firstSong != null) addToPlaylistSync(id, firstSong)
        refreshPlaylists()
    }

    /** Creates a playlist and returns its id without refreshing the UI (importer uses this in bulk). */
    @Synchronized
    fun createPlaylistSync(name: String): Long {
        conn.prepareStatement("INSERT INTO playlists (name, created_at) VALUES (?, ?)").use {
            it.setString(1, name.trim().ifBlank { "Playlist baru" })
            it.setLong(2, System.currentTimeMillis())
            it.executeUpdate()
        }
        return conn.createStatement().use { st -> st.executeQuery("SELECT last_insert_rowid()").use { rs -> rs.next(); rs.getLong(1) } }
    }

    fun refreshPlaylistsNow() = refreshPlaylists()

    fun renamePlaylist(id: Long, name: String) = scope.launch {
        synchronized(this@Library) {
            conn.prepareStatement("UPDATE playlists SET name = ? WHERE id = ?").use {
                it.setString(1, name.trim()); it.setLong(2, id); it.executeUpdate()
            }
        }
        refreshPlaylists()
    }

    fun deletePlaylist(id: Long) = scope.launch {
        synchronized(this@Library) {
            conn.prepareStatement("DELETE FROM playlist_songs WHERE playlist_id = ?").use { it.setLong(1, id); it.executeUpdate() }
            conn.prepareStatement("DELETE FROM playlists WHERE id = ?").use { it.setLong(1, id); it.executeUpdate() }
        }
        refreshPlaylists()
    }

    fun addToPlaylist(playlistId: Long, song: SongItem) = scope.launch {
        addToPlaylistSync(playlistId, song)
        refreshPlaylists()
    }

    fun addAllToPlaylist(playlistId: Long, songs: List<SongItem>) = scope.launch {
        songs.forEach { addToPlaylistSync(playlistId, it) }
        refreshPlaylists()
    }

    @Synchronized
    fun addToPlaylistSync(playlistId: Long, song: SongItem) {
        upsertSong(song)
        val next = conn.prepareStatement("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_songs WHERE playlist_id = ?").use {
            it.setLong(1, playlistId)
            it.executeQuery().use { rs -> rs.next(); rs.getInt(1) }
        }
        conn.prepareStatement("INSERT OR IGNORE INTO playlist_songs (playlist_id, song_id, position) VALUES (?, ?, ?)").use {
            it.setLong(1, playlistId); it.setString(2, song.id); it.setInt(3, next); it.executeUpdate()
        }
    }

    /** Moves a song up (-1) or down (+1) inside a playlist. */
    fun movePlaylistSong(playlistId: Long, songId: String, delta: Int) = scope.launch {
        synchronized(this@Library) {
            val ids = conn.prepareStatement("SELECT song_id FROM playlist_songs WHERE playlist_id = ? ORDER BY position").use { ps ->
                ps.setLong(1, playlistId)
                ps.executeQuery().use { rs -> buildList { while (rs.next()) add(rs.getString(1)) } }
            }.toMutableList()
            val from = ids.indexOf(songId)
            val to = from + delta
            if (from < 0 || to !in ids.indices) return@synchronized
            ids.removeAt(from); ids.add(to, songId)
            conn.prepareStatement("UPDATE playlist_songs SET position = ? WHERE playlist_id = ? AND song_id = ?").use { ps ->
                ids.forEachIndexed { i, id -> ps.setInt(1, i); ps.setLong(2, playlistId); ps.setString(3, id); ps.addBatch() }
                ps.executeBatch()
            }
        }
        refreshPlaylists()
    }

    fun removeFromPlaylist(playlistId: Long, songId: String) = scope.launch {
        synchronized(this@Library) {
            conn.prepareStatement("DELETE FROM playlist_songs WHERE playlist_id = ? AND song_id = ?").use {
                it.setLong(1, playlistId); it.setString(2, songId); it.executeUpdate()
            }
        }
        refreshPlaylists()
    }

    @Synchronized
    fun playlistSongs(playlistId: Long): List<SongItem> =
        conn.prepareStatement(
            "SELECT s.json FROM playlist_songs ps JOIN songs s ON s.id = ps.song_id WHERE ps.playlist_id = ? ORDER BY ps.position"
        ).use { ps ->
            ps.setLong(1, playlistId)
            ps.executeQuery().use { rs ->
                buildList { while (rs.next()) decode(rs.getString(1))?.let(::add) }
            }
        }

    @Synchronized
    fun playlistName(playlistId: Long): String =
        conn.prepareStatement("SELECT name FROM playlists WHERE id = ?").use { ps ->
            ps.setLong(1, playlistId)
            ps.executeQuery().use { rs -> if (rs.next()) rs.getString(1) else "Playlist" }
        }

    // ---- History ------------------------------------------------------------------

    fun recordPlay(song: SongItem) = scope.launch {
        synchronized(this@Library) {
            upsertSong(song)
            val now = System.currentTimeMillis()
            conn.prepareStatement("UPDATE songs SET play_count = play_count + 1, last_played = ? WHERE id = ?").use {
                it.setLong(1, now); it.setString(2, song.id); it.executeUpdate()
            }
            conn.prepareStatement("INSERT INTO history (song_id, played_at) VALUES (?, ?)").use {
                it.setString(1, song.id); it.setLong(2, now); it.executeUpdate()
            }
        }
        refreshHistory()
    }

    fun clearHistory() = scope.launch {
        synchronized(this@Library) { conn.createStatement().use { it.executeUpdate("DELETE FROM history") } }
        refreshHistory()
    }

    // ---- Refresh ------------------------------------------------------------------

    private fun refreshAll() { refreshLiked(); refreshPlaylists(); refreshHistory() }

    @Synchronized
    private fun refreshLiked() {
        val songs = conn.createStatement().use { st ->
            st.executeQuery("SELECT json FROM songs WHERE liked = 1 ORDER BY liked_at DESC").use { rs ->
                buildList { while (rs.next()) decode(rs.getString(1))?.let(::add) }
            }
        }
        _liked.value = songs
        _likedIds.value = songs.map { it.id }.toSet()
    }

    @Synchronized
    private fun refreshPlaylists() {
        _playlists.value = conn.createStatement().use { st ->
            st.executeQuery(
                """
                SELECT p.id, p.name,
                       (SELECT COUNT(*) FROM playlist_songs ps WHERE ps.playlist_id = p.id) AS cnt,
                       (SELECT s.json FROM playlist_songs ps JOIN songs s ON s.id = ps.song_id
                         WHERE ps.playlist_id = p.id ORDER BY ps.position LIMIT 1) AS first_json
                FROM playlists p ORDER BY p.created_at DESC
                """.trimIndent()
            ).use { rs ->
                buildList {
                    while (rs.next()) {
                        add(
                            LocalPlaylist(
                                id = rs.getLong(1),
                                name = rs.getString(2),
                                songCount = rs.getInt(3),
                                thumbnail = rs.getString(4)?.let { decode(it)?.thumbnail },
                            )
                        )
                    }
                }
            }
        }
    }

    @Synchronized
    private fun refreshHistory() {
        _history.value = conn.createStatement().use { st ->
            st.executeQuery(
                "SELECT s.json, h.played_at FROM history h JOIN songs s ON s.id = h.song_id ORDER BY h.played_at DESC LIMIT 300"
            ).use { rs ->
                buildList {
                    while (rs.next()) decode(rs.getString(1))?.let { add(HistoryEntry(it, rs.getLong(2))) }
                }
            }
        }
    }
}
