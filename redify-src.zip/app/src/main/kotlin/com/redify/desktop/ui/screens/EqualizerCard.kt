package com.redify.desktop.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.redify.desktop.LocalPlayer
import com.redify.desktop.data.Settings

/** 10-band LibVLC equalizer with presets - counterpart of Musicfy's equalizer screen. */
@Composable
fun EqualizerCard() {
    val player = LocalPlayer.current
    val settings by Settings.state.collectAsState()
    val bands = player.eqBandFrequencies
    val amps = if (settings.eqAmps.size == bands.size) settings.eqAmps else List(bands.size) { 0f }
    var presetMenu by remember { mutableStateOf(false) }

    fun save(enabled: Boolean = settings.eqEnabled, preamp: Float = settings.eqPreamp, newAmps: List<Float> = amps, preset: String? = settings.eqPreset) {
        Settings.update { it.copy(eqEnabled = enabled, eqPreamp = preamp, eqAmps = newAmps, eqPreset = preset) }
        player.applyEqualizer(enabled, preamp, newAmps)
    }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Equalizer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Switch(checked = settings.eqEnabled, onCheckedChange = { save(enabled = it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box {
                    OutlinedButton(onClick = { presetMenu = true }, enabled = settings.eqEnabled) {
                        Text(settings.eqPreset ?: "Preset")
                    }
                    DropdownMenu(expanded = presetMenu, onDismissRequest = { presetMenu = false }) {
                        player.eqPresets.forEach { name ->
                            DropdownMenuItem(text = { Text(name) }, onClick = {
                                presetMenu = false
                                save(newAmps = player.presetAmps(name).toList(), preset = name)
                            })
                        }
                    }
                }
                TextButton(onClick = { save(newAmps = List(bands.size) { 0f }, preamp = 12f, preset = null) }, enabled = settings.eqEnabled) { Text("Reset") }
                Text("Preamp ${"%.0f".format(settings.eqPreamp - 12f)} dB", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = settings.eqPreamp,
                    onValueChange = { save(preamp = it) },
                    valueRange = 0f..40f,
                    enabled = settings.eqEnabled,
                    modifier = Modifier.width(160.dp),
                )
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                items(bands.indices.toList()) { i ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${"%+.0f".format(amps[i])}", style = MaterialTheme.typography.labelSmall)
                        VerticalSlider(
                            value = amps[i],
                            onValueChange = { v -> save(newAmps = amps.toMutableList().also { it[i] = v }, preset = null) },
                            enabled = settings.eqEnabled,
                        )
                        Text(formatHz(bands[i]), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

private fun formatHz(hz: Float): String = if (hz >= 1000f) "${"%.0f".format(hz / 1000f)}k" else "%.0f".format(hz)

/** A Slider rotated to run bottom-to-top. */
@Composable
private fun VerticalSlider(value: Float, onValueChange: (Float) -> Unit, enabled: Boolean) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = -20f..20f,
        enabled = enabled,
        modifier = Modifier
            .graphicsLayer { rotationZ = 270f }
            .layout { measurable, constraints ->
                val placeable = measurable.measure(
                    androidx.compose.ui.unit.Constraints(
                        minWidth = constraints.minHeight, maxWidth = constraints.maxHeight,
                        minHeight = constraints.minWidth, maxHeight = constraints.maxWidth,
                    )
                )
                layout(placeable.height, placeable.width) {
                    placeable.place(-(placeable.width - placeable.height) / 2, (placeable.width - placeable.height) / 2)
                }
            }
            .width(140.dp)
            .height(40.dp),
    )
}
