package com.redify.desktop.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Same palette as Musicfy Android (ui/theme/Theme.kt): monochrome, no dynamic colour.
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFE0E0E0),
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF333333),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFB0B0B0),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF2C2C2C),
    onSecondaryContainer = Color.White,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF1A1A1A),
    onSurfaceVariant = Color.White,
    surfaceContainer = Color(0xFF121212),
    surfaceContainerHigh = Color(0xFF1C1C1C),
    surfaceContainerHighest = Color(0xFF262626),
    surfaceTint = Color.Black,
    outline = Color(0xFF3A3A3A),
    outlineVariant = Color(0xFF2A2A2A),
)

private val LightScheme = lightColorScheme(
    primary = Color.Black,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E0E0),
    onPrimaryContainer = Color.Black,
    secondary = Color(0xFF333333),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCCCCCC),
    onSecondaryContainer = Color.Black,
    background = Color.White,
    onBackground = Color.Black,
    surface = Color.White,
    onSurface = Color.Black,
    surfaceVariant = Color(0xFFF0F0F0),
    onSurfaceVariant = Color.Black,
    surfaceContainer = Color(0xFFF5F5F5),
    surfaceContainerHigh = Color(0xFFEDEDED),
    surfaceContainerHighest = Color(0xFFE3E3E3),
    surfaceTint = Color.White,
)

@Composable
fun RedifyTheme(
    darkTheme: Boolean = true,
    palette: ArtworkPalette? = null,
    content: @Composable () -> Unit,
) {
    val base = if (darkTheme) DarkScheme else LightScheme
    // "Warna dari sampul": same idea as Musicfy's player palette, applied app-wide.
    val scheme = if (palette == null) base else base.copy(
        primary = palette.accent,
        onPrimary = palette.onAccent,
        primaryContainer = palette.container,
        onPrimaryContainer = palette.onContainer,
        secondaryContainer = palette.container,
        onSecondaryContainer = palette.onContainer,
        surfaceContainer = if (darkTheme) palette.surface else base.surfaceContainer,
        surfaceContainerHigh = if (darkTheme) palette.container.copy(alpha = 1f).blend(palette.surface, 0.5f) else base.surfaceContainerHigh,
        surfaceVariant = if (darkTheme) palette.surface else base.surfaceVariant,
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun Color.blend(other: Color, t: Float) = Color(
    red = red + (other.red - red) * t,
    green = green + (other.green - green) * t,
    blue = blue + (other.blue - blue) * t,
)
