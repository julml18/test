package com.redify.desktop.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.music.innertube.YouTube
import com.music.innertube.models.BrowseEndpoint
import com.music.innertube.models.SongItem
import com.music.innertube.models.YTItem
import com.redify.desktop.LocalNavigator
import com.redify.desktop.LocalPlayer
import com.redify.desktop.Screen
import com.redify.desktop.data.Downloads
import com.redify.desktop.ui.Artwork
import com.redify.desktop.ui.GridItemCard
import com.redify.desktop.ui.ItemCarousel
import com.redify.desktop.ui.SectionHeader
import com.redify.desktop.ui.SongRow

@Composable
private fun DetailHeader(
    thumbnail: String?,
    title: String,
    subtitle: String,
    description: String? = null,
    artworkShape: Shape = RoundedCornerShape(12.dp),
    onPlay: (() -> Unit)?,
    onShuffle: (() -> Unit)?,
    onRadio: (() -> Unit)? = null,
    onDownload: (() -> Unit)? = null,
) {
    Row(Modifier.fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.Bottom) {
        Artwork(thumbnail, Modifier.size(200.dp), shape = artworkShape)
        Spacer(Modifier.width(24.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!description.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (onPlay != null) {
                    Button(onClick = onPlay) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Putar")
                    }
                }
                if (onShuffle != null) {
                    OutlinedButton(onClick = onShuffle) {
                        Icon(Icons.Default.Shuffle, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Acak")
                    }
                }
                if (onRadio != null) {
                    OutlinedButton(onClick = onRadio) {
                        Icon(Icons.Default.Radio, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Radio")
                    }
                }
                if (onDownload != null) {
                    OutlinedButton(onClick = onDownload) {
                        Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Unduh semua")
                    }
                }
            }
        }
    }
}

@Composable
fun AlbumScreen(browseId: String) {
    val player = LocalPlayer.current
    val playerState by player.state.collectAsState()
    Loaded(key = "album:$browseId", fetch = { YouTube.album(browseId) }) { page ->
        val songs = page.songs
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
            item {
                DetailHeader(
                    thumbnail = page.album.thumbnail,
                    title = page.album.title,
                    subtitle = listOfNotNull(
                        page.album.artists?.joinToString { it.name },
                        page.album.year?.toString(),
                        "${songs.size} lagu",
                    ).joinToString(" • "),
                    description = page.description,
                    onPlay = { player.playQueue(songs, 0, page.album.title) },
                    onShuffle = {
                        player.playQueue(songs.shuffled(), 0, page.album.title)
                    },
                    onDownload = { Downloads.downloadAll(songs) },
                )
            }
            items(songs, key = { it.id }) { song ->
                SongRow(
                    song = song,
                    index = songs.indexOf(song),
                    isActive = playerState.current?.id == song.id,
                    showArtwork = false,
                    onClick = { player.playQueue(songs, songs.indexOf(song), page.album.title) },
                )
            }
            if (page.otherVersions.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(16.dp))
                    SectionHeader("Versi lain")
                    ItemCarousel(page.otherVersions)
                }
            }
        }
    }
}

@Composable
fun PlaylistScreen(playlistId: String) {
    val player = LocalPlayer.current
    val playerState by player.state.collectAsState()
    var songs by remember(playlistId) { mutableStateOf<List<SongItem>>(emptyList()) }
    var continuation by remember(playlistId) { mutableStateOf<String?>(null) }

    Loaded(key = "playlist:$playlistId", fetch = {
        YouTube.playlist(playlistId).onSuccess { songs = it.songs; continuation = it.songsContinuation }
    }) { page ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
            item {
                DetailHeader(
                    thumbnail = page.playlist.thumbnail,
                    title = page.playlist.title,
                    subtitle = listOfNotNull(page.playlist.author?.name, page.playlist.songCountText).joinToString(" • "),
                    onPlay = { player.playQueue(songs, 0, page.playlist.title) },
                    onShuffle = { player.playQueue(songs.shuffled(), 0, page.playlist.title) },
                    onRadio = page.playlist.radioEndpoint?.let { ep -> { player.startRadio(ep) } },
                    onDownload = { Downloads.downloadAll(songs) },
                )
            }
            items(songs, key = { it.id + it.setVideoId }) { song ->
                SongRow(
                    song = song,
                    index = songs.indexOf(song),
                    isActive = playerState.current?.id == song.id,
                    onClick = { player.playQueue(songs, songs.indexOf(song), page.playlist.title) },
                )
            }
            if (continuation != null) {
                item {
                    LaunchedEffect(songs.size) {
                        val c = continuation ?: return@LaunchedEffect
                        YouTube.playlistContinuation(c).onSuccess {
                            songs = songs + it.songs
                            continuation = it.continuation
                        }.onFailure { continuation = null }
                    }
                    Text("Memuat…", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            page.related?.takeIf { it.isNotEmpty() }?.let { related ->
                item {
                    Spacer(Modifier.height(16.dp))
                    SectionHeader("Terkait")
                    ItemCarousel(related)
                }
            }
        }
    }
}

@Composable
fun ArtistScreen(browseId: String) {
    val player = LocalPlayer.current
    val nav = LocalNavigator.current
    Loaded(key = "artist:$browseId", fetch = { YouTube.artist(browseId) }) { page ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
            item {
                DetailHeader(
                    thumbnail = page.artist.thumbnail,
                    title = page.artist.title,
                    subtitle = listOfNotNull(page.subscriberCountText, page.monthlyListenerCount).joinToString(" • "),
                    description = page.description,
                    artworkShape = CircleShape,
                    onPlay = null,
                    onShuffle = page.artist.shuffleEndpoint?.let { ep -> { player.startRadio(ep) } },
                    onRadio = page.artist.radioEndpoint?.let { ep -> { player.startRadio(ep) } },
                )
            }
            page.sections.forEach { section ->
                item {
                    SectionHeader(
                        section.title,
                        onMore = section.moreEndpoint?.let { ep -> { nav.push(Screen.ArtistItems(section.title, ep)) } },
                    )
                }
                val songs = section.items.filterIsInstance<SongItem>()
                if (songs.isNotEmpty() && songs.size == section.items.size) {
                    items(songs, key = { section.title + it.id }) { song ->
                        SongRow(song, onClick = { player.playQueue(songs, songs.indexOf(song), section.title) })
                    }
                } else {
                    item { ItemCarousel(section.items) }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun ArtistItemsScreen(title: String, endpoint: BrowseEndpoint) {
    val player = LocalPlayer.current
    var items by remember(endpoint) { mutableStateOf<List<YTItem>>(emptyList()) }
    var continuation by remember(endpoint) { mutableStateOf<String?>(null) }

    Loaded(key = "artistItems:${endpoint.browseId}:${endpoint.params}", fetch = {
        YouTube.artistItems(endpoint).onSuccess { items = it.items; continuation = it.continuation }
    }) { page ->
        val songs = items.filterIsInstance<SongItem>()
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
            item {
                Text(
                    page.title.ifBlank { title },
                    Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (songs.isNotEmpty() && songs.size == items.size) {
                items(songs, key = { it.id }) { song ->
                    SongRow(song, onClick = { player.playQueue(songs, songs.indexOf(song), title) })
                }
            } else {
                item {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(170.dp),
                        modifier = Modifier.fillMaxWidth().height(((items.size / 5 + 1) * 230).dp),
                        contentPadding = PaddingValues(horizontal = 18.dp),
                        userScrollEnabled = false,
                    ) {
                        items(items, key = { it.id }) { GridItemCard(it) }
                    }
                }
            }
            if (continuation != null) {
                item {
                    LaunchedEffect(items.size) {
                        val c = continuation ?: return@LaunchedEffect
                        YouTube.artistItemsContinuation(c).onSuccess {
                            items = items + it.items
                            continuation = it.continuation
                        }.onFailure { continuation = null }
                    }
                    Text("Memuat…", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
