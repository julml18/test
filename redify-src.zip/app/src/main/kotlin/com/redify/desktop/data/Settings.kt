package com.redify.desktop.data

import com.music.innertube.YouTube
import com.music.innertube.models.AccountInfo
import com.redify.desktop.appDataDir
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class AppSettings(
    val cookie: String? = null,
    val visitorData: String? = null,
    val dataSyncId: String? = null,
    val accountName: String? = null,
    val accountEmail: String? = null,
    val accountHandle: String? = null,
    val accountThumbnail: String? = null,
    val volume: Int = 100,
    val darkTheme: Boolean = true,
    val artworkTheme: Boolean = true,
    val eqEnabled: Boolean = false,
    val eqPreset: String? = null,
    val eqPreamp: Float = 12f,
    val eqAmps: List<Float> = emptyList(),
    val lyricsOffsetMs: Int = 300,
    val showHeroOnHome: Boolean = true,
    // Profile
    val profileName: String = System.getProperty("user.name")?.takeIf { it.isNotBlank() } ?: "Listener",
    val joinedAt: Long = System.currentTimeMillis(),
    val listeningSeconds: Long = 0,
    // General
    val offlineMode: Boolean = false,
    val dontSkipOnFailure: Boolean = false,
    val skipTimeoutSec: Int = 6,
    // Playback
    val saveLastState: Boolean = true,
    val resumeOnLaunch: Boolean = false,
    // Audio
    val audioQuality: String = "AUTO", // AUTO | HIGH | MEDIUM | LOW
    val normalization: Boolean = true,
    val crossfadeEnabled: Boolean = false,
    val crossfadeSec: Int = 6,
    // Appearance
    val showFormatBadge: Boolean = true,
    val showSampleRate: Boolean = false,
    val blurEnabled: Boolean = true,
    val blurStrength: Int = 70,
    val animations: Boolean = true,
    /** Player style: DEFAULT | TURNTABLE | POSTER | TIMELINE | LYRICS_STAGE (Musicfy "Styles"). */
    val playerStyle: String = "TURNTABLE",
) {
    val isLoggedIn: Boolean get() = !cookie.isNullOrBlank() && "SAPISID" in cookie
}

/** Persisted preferences (equivalent of Musicfy's DataStore), stored as JSON in the app data folder. */
object Settings {
    private val file = File(appDataDir(), "settings.json")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true; encodeDefaults = true }

    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state
    val current: AppSettings get() = _state.value

    private fun load(): AppSettings = runCatching {
        if (file.exists()) json.decodeFromString<AppSettings>(file.readText()) else AppSettings()
    }.getOrDefault(AppSettings())

    fun update(transform: (AppSettings) -> AppSettings) {
        _state.update(transform)
        runCatching { file.writeText(json.encodeToString(_state.value)) }
    }

    /** Pushes stored session values into the innertube singleton. */
    fun applyToYouTube() {
        val s = current
        YouTube.cookie = s.cookie?.takeIf { it.isNotBlank() }
        s.visitorData?.let { YouTube.visitorData = it }
        YouTube.dataSyncId = s.dataSyncId
        YouTube.useLoginForBrowse = s.isLoggedIn
        YouTube.offline = s.offlineMode
    }

    /**
     * Logs in with a raw Cookie header copied from music.youtube.com.
     * Same logic as Musicfy's YouTubeLoginScreen.finishLogin, minus the WebView.
     */
    suspend fun login(rawCookie: String): Result<AccountInfo> {
        val cookie = rawCookie.trim().removePrefix("Cookie:").trim()
        if ("SAPISID" !in cookie) {
            return Result.failure(IllegalArgumentException("Cookie tidak valid: harus mengandung SAPISID"))
        }
        YouTube.cookie = cookie
        YouTube.useLoginForBrowse = true
        return YouTube.accountInfo().onSuccess { info ->
            update {
                it.copy(
                    cookie = cookie,
                    accountName = info.name,
                    accountEmail = info.email,
                    accountHandle = info.channelHandle,
                    accountThumbnail = info.thumbnailUrl,
                )
            }
        }.onFailure {
            YouTube.cookie = null
            YouTube.useLoginForBrowse = false
        }
    }

    fun logout() {
        YouTube.cookie = null
        YouTube.dataSyncId = null
        YouTube.useLoginForBrowse = false
        YouTube.clearGuestSession()
        update {
            it.copy(
                cookie = null,
                dataSyncId = null,
                accountName = null,
                accountEmail = null,
                accountHandle = null,
                accountThumbnail = null,
            )
        }
    }
}
