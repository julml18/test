package com.redify.desktop.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.music.innertube.YouTube
import com.redify.desktop.LocalNavigator
import com.redify.desktop.Screen
import com.redify.desktop.ui.GridItemCard
import com.redify.desktop.ui.ItemCarousel
import com.redify.desktop.ui.SectionHeader

@Composable
fun ExploreScreen() {
    val nav = LocalNavigator.current
    Loaded(key = "explore", fetch = { YouTube.explore() }) { page ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
            item {
                Text(
                    "Jelajahi",
                    Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (page.newReleaseAlbums.isNotEmpty()) {
                item {
                    SectionHeader("Rilis baru")
                    ItemCarousel(page.newReleaseAlbums)
                    Spacer(Modifier.height(16.dp))
                }
            }
            if (page.moodAndGenres.isNotEmpty()) {
                item { SectionHeader("Mood & genre") }
                item {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(180.dp),
                        modifier = Modifier.fillMaxWidth().height(((page.moodAndGenres.size / 4 + 1) * 64).dp),
                        contentPadding = PaddingValues(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        userScrollEnabled = false,
                    ) {
                        items(page.moodAndGenres, key = { it.title }) { item ->
                            Row(
                                Modifier
                                    .height(52.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                    .clickable { nav.push(Screen.Browse(item.title, item.endpoint.browseId, item.endpoint.params)) },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(Modifier.width(6.dp).fillMaxHeight().background(Color(item.stripeColor)))
                                Text(
                                    item.title,
                                    Modifier.padding(horizontal = 14.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Generic browse page (mood/genre, "more" shelves, charts-like pages). */
@Composable
fun BrowseScreen(title: String, browseId: String, params: String?) {
    Loaded(key = browseId + params, fetch = { YouTube.browse(browseId, params) }) { page ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
            item {
                Text(
                    page.title ?: title,
                    Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (page.items.size == 1 && page.items.first().title == null) {
                // A single untitled section - render as a grid like Musicfy does.
                val only = page.items.first().items
                item {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(170.dp),
                        modifier = Modifier.fillMaxWidth().height(((only.size / 5 + 1) * 230).dp),
                        contentPadding = PaddingValues(horizontal = 18.dp),
                        userScrollEnabled = false,
                    ) {
                        items(only, key = { it.id }) { GridItemCard(it) }
                    }
                }
            } else {
                page.items.forEach { section ->
                    item {
                        section.title?.let { SectionHeader(it) }
                        ItemCarousel(section.items)
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}
