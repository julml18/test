package com.redify.desktop.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redify.desktop.LocalPlayer
import com.redify.desktop.data.Downloads
import com.redify.desktop.data.Library
import com.redify.desktop.ui.Artwork
import com.redify.desktop.ui.screens.AddToPlaylistDialog
import java.awt.Toolkit
import java.awt.datatransfer.StringSelection

private val SheetBg = Color(0xFF0C0C0E)
private val TileBg = Color(0xFF1B1B1E)

/** The "Other menu" bottom sheet from Musicfy's player. */
@Composable
fun PlayerMenuSheet(onDismiss: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    val likedIds by Library.likedIds.collectAsState()
    val liked = song != null && song.id in likedIds
    val downloads by Downloads.entries.collectAsState()
    val downloaded = song != null && downloads.any { it.song.id == song.id }

    var sub by remember { mutableStateOf<String?>(null) } // "output" | "sleep" | "speed"
    var addToPlaylist by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }

    if (addToPlaylist && song != null) AddToPlaylistDialog(song, onDismiss = { addToPlaylist = false })

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onDismiss)) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .widthIn(max = 640.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(SheetBg)
                .clickable(enabled = false) {}
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(Modifier.align(Alignment.CenterHorizontally).width(72.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)))
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Artwork(song?.thumbnail, Modifier.size(72.dp), RoundedCornerShape(12.dp))
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(song?.title ?: "", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "by ${song?.artists?.joinToString { it.name } ?: ""}${song?.album?.let { " on ${it.name}" } ?: ""}",
                        color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

            // Volume card
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(TileBg).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SmallIcon(Icons.Default.VolumeUp)
                    Spacer(Modifier.width(14.dp))
                    Text("${state.volume}%", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeDown, null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f)) {
                        ProgressBar(
                            fraction = state.volume / 100f,
                            onSeek = { player.setVolume((it * 100).toInt()) },
                            onDrag = { player.setVolume((it * 100).toInt()) },
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Icon(Icons.Default.VolumeUp, null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
                }
            }

            Tile(Icons.Default.Cast, "Change device output") { sub = if (sub == "output") null else "output" }
            if (sub == "output") {
                val devices = remember { player.outputDevices() }
                if (devices.isEmpty()) SubText("Tidak ada daftar perangkat dari VLC (gunakan pengaturan suara Windows).")
                devices.forEach { (id, name) -> SubOption(name) { player.setOutputDevice(id); toast = "Output: $name" } }
            }

            Tile(Icons.Default.Timer, state.sleepTimerEndsAt?.let { "Sleep timer: ${((it - System.currentTimeMillis()) / 60_000).coerceAtLeast(0)} mnt lagi" } ?: "Sleep timer") {
                sub = if (sub == "sleep") null else "sleep"
            }
            if (sub == "sleep") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 10, 15, 30, 45, 60).forEach { m -> Chip("$m mnt") { player.setSleepTimer(m); sub = null } }
                    Chip("Matikan") { player.setSleepTimer(null); sub = null }
                }
            }

            Tile(Icons.Default.Speed, "Playback speed and tempo (${"%.2f".format(state.rate)}x)") { sub = if (sub == "speed") null else "speed" }
            if (sub == "speed") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { r -> Chip("${r}x", selected = state.rate == r) { player.setRate(r) } }
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Tile(Icons.Default.PlaylistAdd, "add to playlist", enabled = song != null) { addToPlaylist = true }
            Tile(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, if (liked) "remove from liked" else "add to liked", enabled = song != null) {
                song?.let(Library::toggleLike)
            }
            Tile(Icons.Default.Download, if (downloaded) "remove download" else "download music", enabled = song != null) {
                song?.let { if (downloaded) Downloads.delete(it.id) else Downloads.download(it) }
                toast = if (downloaded) "Unduhan dihapus" else "Mengunduh…"
            }
            Tile(Icons.Default.Share, "share song", enabled = song != null) {
                song?.let {
                    runCatching { Toolkit.getDefaultToolkit().systemClipboard.setContents(StringSelection(it.shareLink), null) }
                    toast = "Tautan disalin ke clipboard"
                }
            }
            toast?.let { Text(it, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SmallIcon(icon: ImageVector) {
    Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun Tile(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(TileBg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SmallIcon(icon)
        Spacer(Modifier.width(14.dp))
        Text(label, color = if (enabled) Color.White else Color.White.copy(alpha = 0.4f), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SubOption(label: String, onClick: () -> Unit) {
    Text(
        label, color = Color.White, fontSize = 15.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 10.dp),
    )
}

@Composable
private fun SubText(text: String) {
    Text(text, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
}

@Composable
private fun Chip(label: String, selected: Boolean = false, onClick: () -> Unit) {
    Text(
        label, color = if (selected) Color.Black else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}
