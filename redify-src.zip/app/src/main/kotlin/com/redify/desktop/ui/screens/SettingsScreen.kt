package com.redify.desktop.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.redify.desktop.data.Downloads
import com.redify.desktop.data.Settings
import com.redify.desktop.openUrl
import com.redify.desktop.ui.Artwork
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val settings by Settings.state.collectAsState()
    val scope = rememberCoroutineScope()
    var cookie by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Pengaturan", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        AccountCard()

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Tampilan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Tema gelap", Modifier.weight(1f))
                    Switch(checked = settings.darkTheme, onCheckedChange = { v -> Settings.update { it.copy(darkTheme = v) } })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Warna dari sampul album")
                        Text("Warna aplikasi mengikuti sampul lagu yang diputar", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = settings.artworkTheme, onCheckedChange = { v -> Settings.update { it.copy(artworkTheme = v) } })
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Text(
                    "Redify 2.0 • mesin audio LibVLC • data tersimpan di folder Redify pada AppData",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        EqualizerCard()

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val downloads by Downloads.entries.collectAsState()
                Text("Unduhan offline", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "${downloads.size} lagu • ${"%.1f".format(Downloads.totalBytes() / 1024f / 1024f)} MB tersimpan di folder downloads pada AppData\\Redify",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(170.dp))
    }
}

/** YouTube Music account card (login via cookie / logout). Shared by Settings and Modules. */
@Composable
fun AccountCard() {
    val settings by Settings.state.collectAsState()
    val scope = rememberCoroutineScope()
    var cookie by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Akun YouTube Music", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (settings.isLoggedIn) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Artwork(settings.accountThumbnail, Modifier.size(56.dp), CircleShape)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(settings.accountName ?: "Akun", fontWeight = FontWeight.SemiBold)
                        Text(
                            listOfNotNull(settings.accountHandle, settings.accountEmail).joinToString(" • "),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    OutlinedButton(onClick = { Settings.logout(); message = "Berhasil keluar." }) { Text("Keluar") }
                }
                Text(
                    "Beranda, rekomendasi, dan Koleksi → Akun YouTube sekarang memakai akunmu.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Text(
                    "Masuk dengan menyalin cookie dari browser (cara yang sama dengan \"Login via cookie\" di Musicfy Android):",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    "1. Buka music.youtube.com di Chrome/Edge dan pastikan sudah login.\n" +
                        "2. Tekan F12 → tab Network → muat ulang halaman → klik request pertama (music.youtube.com).\n" +
                        "3. Di Request Headers, salin seluruh nilai baris \"Cookie:\" lalu tempel di bawah.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = { openUrl("https://music.youtube.com") }) { Text("Buka music.youtube.com") }
                OutlinedTextField(
                    value = cookie,
                    onValueChange = { cookie = it },
                    label = { Text("Cookie") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        enabled = cookie.isNotBlank() && !busy,
                        onClick = {
                            busy = true; message = null
                            scope.launch {
                                Settings.login(cookie).fold(
                                    onSuccess = { message = "Masuk sebagai ${it.name}"; cookie = "" },
                                    onFailure = { message = "Gagal masuk: ${it.message}" },
                                )
                                busy = false
                            }
                        },
                    ) { Text("Masuk") }
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }

}
