package com.redify.desktop.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.music.innertube.YouTube
import com.music.innertube.models.SongItem
import com.music.innertube.models.YTItem
import com.music.innertube.utils.completed
import com.redify.desktop.LocalNavigator
import com.redify.desktop.LocalPlayer
import com.redify.desktop.Screen
import com.redify.desktop.data.DownloadStatus
import com.redify.desktop.data.Downloads
import com.redify.desktop.data.Library
import com.redify.desktop.data.Settings
import com.redify.desktop.ui.Artwork
import com.redify.desktop.ui.GridItemCard
import com.redify.desktop.ui.SectionHeader
import com.redify.desktop.ui.SongRow
import java.text.SimpleDateFormat
import java.util.Date

private enum class LibTab(val label: String) { LIKED("Disukai"), PLAYLISTS("Playlist"), DOWNLOADS("Unduhan"), HISTORY("Riwayat"), YOUTUBE("Akun YouTube") }

@Composable
fun LibraryScreen() {
    val settings by Settings.state.collectAsState()
    var tab by remember { mutableStateOf(LibTab.LIKED) }
    val tabs = LibTab.entries.filter { it != LibTab.YOUTUBE || settings.isLoggedIn }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 16.dp)) {
            val nav = LocalNavigator.current
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Koleksi", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { nav.push(Screen.Import) }) {
                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("Impor dari Spotify / lainnya")
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tabs) { t -> FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(t.label) }) }
            }
        }
        when (tab) {
            LibTab.LIKED -> LikedTab()
            LibTab.PLAYLISTS -> PlaylistsTab(onOpenLiked = { tab = LibTab.LIKED })
            LibTab.DOWNLOADS -> DownloadsTab()
            LibTab.HISTORY -> HistoryTab()
            LibTab.YOUTUBE -> YouTubeLibraryTab()
        }
    }
}

@Composable
private fun LikedTab() {
    val player = LocalPlayer.current
    val liked by Library.liked.collectAsState()
    val playerState by player.state.collectAsState()
    if (liked.isEmpty()) { Empty("Belum ada lagu yang disukai. Tekan ikon hati di pemutar atau menu lagu."); return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
        item {
            Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { player.playQueue(liked, 0, "Lagu disukai") }) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Putar semua")
                }
                OutlinedButton(onClick = { player.playQueue(liked.shuffled(), 0, "Lagu disukai") }) {
                    Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Acak")
                }
                Text("${liked.size} lagu", Modifier.align(Alignment.CenterVertically), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(liked, key = { it.id }) { song ->
            SongRow(song, isActive = playerState.current?.id == song.id, onClick = { player.playQueue(liked, liked.indexOf(song), "Lagu disukai") })
        }
    }
}

@Composable
private fun PlaylistsTab(onOpenLiked: () -> Unit) {
    val nav = LocalNavigator.current
    val playlists by Library.playlists.collectAsState()
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        NewPlaylistDialog(onDismiss = { creating = false }, onCreate = { Library.createPlaylist(it); creating = false })
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(170.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 170.dp),
    ) {
        item {
            Column(
                Modifier.width(160.dp).clip(RoundedCornerShape(12.dp)).clickable { creating = true }.padding(6.dp),
            ) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Default.Add, null, Modifier.size(40.dp)) }
                Spacer(Modifier.height(8.dp))
                Text("Playlist baru", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            }
        }
        item {
            val liked by Library.liked.collectAsState()
            Column(
                Modifier.width(160.dp).clip(RoundedCornerShape(12.dp)).clickable { onOpenLiked() }.padding(6.dp),
            ) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Default.Favorite, null, Modifier.size(40.dp)) }
                Spacer(Modifier.height(8.dp))
                Text("Lagu disukai", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text("${liked.size} lagu", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(playlists, key = { it.id }) { pl ->
            Column(
                Modifier.width(160.dp).clip(RoundedCornerShape(12.dp)).clickable { nav.push(Screen.LocalPlaylist(pl.id)) }.padding(6.dp),
            ) {
                Artwork(pl.thumbnail, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(10.dp))
                Spacer(Modifier.height(8.dp))
                Text(pl.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${pl.songCount} lagu", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun DownloadsTab() {
    val player = LocalPlayer.current
    val entries by Downloads.entries.collectAsState()
    val progress by Downloads.progress.collectAsState()
    val playerState by player.state.collectAsState()
    val active = progress.filterValues { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.FAILED }
    val songs = entries.map { it.song }

    if (entries.isEmpty() && active.isEmpty()) { Empty("Belum ada lagu offline. Pilih \"Unduh\" di menu lagu, album, atau playlist."); return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
        if (active.isNotEmpty()) {
            item { SectionHeader("Sedang diunduh") }
            items(active.entries.toList(), key = { "dl:" + it.key }) { (id, p) ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            when (p.status) {
                                DownloadStatus.QUEUED -> "Menunggu…"
                                DownloadStatus.DOWNLOADING -> "Mengunduh ${(p.progress * 100).toInt()}%"
                                DownloadStatus.FAILED -> "Gagal: ${p.error ?: ""}"
                                DownloadStatus.DONE -> "Selesai"
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )
                        LinearProgressIndicator(progress = { p.progress }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                    }
                    IconButton(onClick = { Downloads.cancel(id) }) { Icon(Icons.Default.Delete, "Batal") }
                }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { player.playQueue(songs, 0, "Unduhan") }, enabled = songs.isNotEmpty()) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Putar semua")
                }
                OutlinedButton(onClick = { player.playQueue(songs.shuffled(), 0, "Unduhan") }, enabled = songs.isNotEmpty()) {
                    Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Acak")
                }
                Text("${songs.size} lagu offline", Modifier.align(Alignment.CenterVertically), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(entries, key = { it.song.id }) { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    SongRow(e.song, isActive = playerState.current?.id == e.song.id, onClick = { player.playQueue(songs, songs.indexOf(e.song), "Unduhan") })
                }
                IconButton(onClick = { Downloads.delete(e.song.id) }) { Icon(Icons.Default.Delete, "Hapus unduhan") }
            }
        }
    }
}

@Composable
private fun HistoryTab() {
    val player = LocalPlayer.current
    val history by Library.history.collectAsState()
    if (history.isEmpty()) { Empty("Belum ada riwayat pemutaran."); return }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm") }
    val songs = history.map { it.song }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
        item {
            Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${history.size} pemutaran terakhir", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                TextButton(onClick = { Library.clearHistory() }) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(6.dp)); Text("Hapus riwayat") }
            }
        }
        items(history.withIndex().toList(), key = { (i, e) -> "$i:${e.song.id}:${e.playedAt}" }) { (i, entry) ->
            Column {
                Text(
                    fmt.format(Date(entry.playedAt)),
                    Modifier.padding(start = 24.dp, top = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                SongRow(entry.song, onClick = { player.playQueue(songs, i, "Riwayat") })
            }
        }
    }
}

/** Playlists, albums and liked songs from the signed-in YouTube Music account. */
@Composable
private fun YouTubeLibraryTab() {
    val player = LocalPlayer.current
    val nav = LocalNavigator.current
    var playlists by remember { mutableStateOf<List<YTItem>>(emptyList()) }
    var albums by remember { mutableStateOf<List<YTItem>>(emptyList()) }
    var likedCount by remember { mutableStateOf<String?>(null) }
    var likedSongs by remember { mutableStateOf<List<SongItem>>(emptyList()) }

    LaunchedEffect(Unit) {
        YouTube.library("FEmusic_liked_playlists").completed().onSuccess { playlists = it.items }
        YouTube.library("FEmusic_liked_albums").completed().onSuccess { albums = it.items }
        YouTube.playlist("LM").completed().onSuccess { likedSongs = it.songs; likedCount = it.playlist.songCountText }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
        item {
            SectionHeader("Lagu disukai di YouTube", label = likedCount, onMore = { nav.push(Screen.Playlist("LM")) })
            if (likedSongs.isNotEmpty()) {
                Row(Modifier.padding(horizontal = 24.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { player.playQueue(likedSongs, 0, "Lagu disukai (YouTube)") }) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Putar")
                    }
                    OutlinedButton(onClick = { player.playQueue(likedSongs.shuffled(), 0, "Lagu disukai (YouTube)") }) {
                        Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Acak")
                    }
                }
            }
        }
        items(likedSongs.take(10), key = { "yt:" + it.id }) { song ->
            SongRow(song, onClick = { player.playQueue(likedSongs, likedSongs.indexOf(song), "Lagu disukai (YouTube)") })
        }
        if (playlists.isNotEmpty()) {
            item { SectionHeader("Playlist YouTube") }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(170.dp),
                    modifier = Modifier.fillMaxWidth().height(((playlists.size / 5 + 1) * 230).dp),
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    userScrollEnabled = false,
                ) { items(playlists, key = { it.id }) { GridItemCard(it) } }
            }
        }
        if (albums.isNotEmpty()) {
            item { SectionHeader("Album tersimpan") }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(170.dp),
                    modifier = Modifier.fillMaxWidth().height(((albums.size / 5 + 1) * 230).dp),
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    userScrollEnabled = false,
                ) { items(albums, key = { it.id }) { GridItemCard(it) } }
            }
        }
    }
}

@Composable
fun LocalPlaylistScreen(playlistId: Long) {
    val player = LocalPlayer.current
    val nav = LocalNavigator.current
    val playerState by player.state.collectAsState()
    val playlists by Library.playlists.collectAsState()
    val songs = remember(playlists, playlistId) { Library.playlistSongs(playlistId) }
    val name = remember(playlists, playlistId) { Library.playlistName(playlistId) }
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    if (renaming) {
        NewPlaylistDialog(initial = name, title = "Ganti nama playlist", onDismiss = { renaming = false }) {
            Library.renamePlaylist(playlistId, it); renaming = false
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Hapus playlist?") },
            text = { Text("\"$name\" akan dihapus dari koleksi.") },
            confirmButton = { TextButton(onClick = { Library.deletePlaylist(playlistId); confirmDelete = false; nav.back() }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Batal") } },
        )
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.Bottom) {
                Artwork(songs.firstOrNull()?.thumbnail, Modifier.size(200.dp), RoundedCornerShape(12.dp))
                Spacer(Modifier.width(24.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${songs.size} lagu • Playlist lokal", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { player.playQueue(songs, 0, name) }, enabled = songs.isNotEmpty()) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Putar")
                        }
                        OutlinedButton(onClick = { player.playQueue(songs.shuffled(), 0, name) }, enabled = songs.isNotEmpty()) {
                            Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Acak")
                        }
                        TextButton(onClick = { renaming = true }) { Text("Ganti nama") }
                        TextButton(onClick = { confirmDelete = true }) { Text("Hapus") }
                    }
                }
            }
        }
        if (songs.isEmpty()) item { Empty("Playlist kosong. Tambahkan lagu lewat menu ⋮ di lagu mana pun.") }
        items(songs, key = { it.id }) { song ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    SongRow(song, index = songs.indexOf(song), isActive = playerState.current?.id == song.id, onClick = { player.playQueue(songs, songs.indexOf(song), name) })
                }
                com.redify.desktop.ui.player.DragHandle(rowHeight = 60.dp, tint = MaterialTheme.colorScheme.onSurface) { delta ->
                    Library.movePlaylistSong(playlistId, song.id, delta)
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { Library.removeFromPlaylist(playlistId, song.id) }) { Icon(Icons.Default.Delete, "Hapus dari playlist") }
            }
        }
    }
}

@Composable
fun NewPlaylistDialog(
    initial: String = "",
    title: String = "Playlist baru",
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Nama playlist") })
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@Composable
private fun Empty(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
