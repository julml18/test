package com.redify.desktop.data

import com.music.innertube.YouTube
import com.music.innertube.models.SongItem
import com.music.innertube.models.WatchEndpoint
import com.music.lrclib.LrcLib
import com.redify.desktop.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import kotlin.math.abs

const val SRC_LRCLIB = "LRCLIB"
const val SRC_NETEASE = "NetEase"
const val SRC_KUGOU = "KuGou"
const val SRC_YOUTUBE = "YouTube Music"

data class LyricLine(val timeMs: Long, val text: String)

data class Lyrics(
    val lines: List<LyricLine>,
    val synced: Boolean,
    val source: String,
) {
    fun indexAt(positionMs: Long): Int {
        if (!synced) return -1
        var idx = -1
        for ((i, line) in lines.withIndex()) {
            if (line.timeMs <= positionMs) idx = i else break
        }
        return idx
    }
}

@Serializable
private data class LrcTrack(
    val id: Long = 0,
    val trackName: String? = null,
    val artistName: String? = null,
    val albumName: String? = null,
    val duration: Double? = null,
    val instrumental: Boolean = false,
    val plainLyrics: String? = null,
    val syncedLyrics: String? = null,
)

/**
 * Lyrics lookup, in order: LRCLIB /api/get (exact), LRCLIB /api/search (fuzzy),
 * Musicfy's LrcLib module, then YouTube Music's own (plain) lyrics.
 */
object LyricsProvider {
    private val cache = HashMap<String, Lyrics?>()
    private val lrcLine = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?](.*)""")
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val cleanup = listOf(
        Regex("""\s*[\(\[].*?(official|video|audio|lyrics?|visualizer|hd|hq|4k|remaster(ed)?|live|version|edit|explicit).*?[\)\]]""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(?(feat|ft)\.?\s.*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*\|.*$"""),
    )

    private fun cleanTitle(t: String): String = cleanup.fold(t.trim()) { acc, r -> acc.replace(r, "") }.trim()
    private fun cleanArtist(a: String): String =
        a.split(" & ", ", ", " x ", " feat. ", " feat ", " ft. ", " ft ", " and ", ignoreCase = true, limit = 2).first().trim()

    /** Sources in lookup order; also the names the lyrics screen offers for manual switching. */
    val sources = listOf(SRC_LRCLIB, SRC_NETEASE, SRC_KUGOU, SRC_YOUTUBE)

    private val sourceCache = HashMap<String, Lyrics?>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * All sources are queried in parallel; the first *synced* result in priority order wins,
     * otherwise the first plain result. Waiting only on the sources ahead in the list keeps the
     * usual case (LRCLIB hit) as fast as a single request.
     */
    suspend fun forSong(song: SongItem): Lyrics? {
        cache[song.id]?.let { return it }
        if (song.id in cache) return null

        val jobs = sources.map { src -> src to scope.async { fromSource(song, src) } }
        var plain: Lyrics? = null
        var result: Lyrics? = null
        for ((_, job) in jobs) {
            val l = runCatching { job.await() }.getOrNull() ?: continue
            if (l.synced) { result = l; break }
            if (plain == null) plain = l
        }
        result = result ?: plain
        log("lyrics '${song.title}' -> ${result?.source ?: "none"}")
        cache[song.id] = result
        return result
    }

    /** Warm the cache for the upcoming song so the lyrics are already there when it starts. */
    fun prefetch(song: SongItem) {
        if (song.id in cache) return
        scope.launch { runCatching { forSong(song) } }
    }

    /** Fetch lyrics from one named source (see [sources]); cached per song+source. */
    suspend fun fromSource(song: SongItem, source: String): Lyrics? {
        val key = "${song.id}|$source"
        if (key in sourceCache) return sourceCache[key]
        val title = cleanTitle(song.title)
        val artist = cleanArtist(song.artists.firstOrNull()?.name ?: "")
        val duration = song.duration ?: -1
        val result = withContext(Dispatchers.IO) {
            runCatching {
                when (source) {
                    SRC_LRCLIB -> lrclibGet(title, artist, duration, song.album?.name) ?: lrclibSearch(title, artist, duration) ?: lrclibModule(song, title, artist, duration)
                    SRC_NETEASE -> netease(title, artist, duration)
                    SRC_KUGOU -> kugou(title, artist, duration)
                    SRC_YOUTUBE -> fromYouTube(song)
                    else -> null
                }
            }.onFailure { log("lyrics $source failed", it) }.getOrNull()
        }
        log("lyrics $source '${song.title}' -> ${if (result == null) "none" else if (result.synced) "synced" else "plain"}")
        sourceCache[key] = result
        return result
    }

    // ---- NetEase Cloud Music -------------------------------------------------------

    private fun netease(title: String, artist: String, duration: Int): Lyrics? {
        val q = "$artist $title".trim()
        val searchUrl = "https://music.163.com/api/search/get/web".toHttpUrl().newBuilder()
            .addQueryParameter("s", q).addQueryParameter("type", "1").addQueryParameter("limit", "10").build()
        val body = http.newCall(request(searchUrl.toString(), referer = "https://music.163.com")).execute().use { res ->
            if (res.code != 200) { log("netease search HTTP ${res.code}"); return null }
            res.body?.string().orEmpty()
        }
        val songs = json.parseToJsonElement(body).jsonObject["result"]?.jsonObject?.get("songs")?.jsonArray ?: return null
        val candidates = songs.mapNotNull { el ->
            val o = el.jsonObject
            val id = o["id"]?.jsonPrimitive?.longOrNull ?: return@mapNotNull null
            val name = o["name"]?.jsonPrimitive?.contentOrNull ?: ""
            val dur = (o["duration"]?.jsonPrimitive?.longOrNull ?: 0L) / 1000.0
            Triple(id, name, dur)
        }.sortedBy { (_, name, dur) ->
            (if (duration > 0 && dur > 0) abs(dur - duration) else 30.0) + (if (name.equals(title, ignoreCase = true)) 0 else 5)
        }
        for ((id, _, dur) in candidates.take(3)) {
            if (duration > 0 && dur > 0 && abs(dur - duration) > 20) continue
            val lyricUrl = "https://music.163.com/api/song/lyric?id=$id&lv=1&kv=1&tv=-1"
            val lb = http.newCall(request(lyricUrl, referer = "https://music.163.com")).execute().use { if (it.code == 200) it.body?.string().orEmpty() else "" }
            if (lb.isBlank()) continue
            val lrc = json.parseToJsonElement(lb).jsonObject["lrc"]?.jsonObject?.get("lyric")?.jsonPrimitive?.contentOrNull ?: continue
            parse(lrc, SRC_NETEASE)?.let { return it }
        }
        return null
    }

    // ---- KuGou ------------------------------------------------------------------------

    private fun kugou(title: String, artist: String, duration: Int): Lyrics? {
        val keyword = if (artist.isBlank()) title else "$artist - $title"
        val searchUrl = "https://lyrics.kugou.com/search".toHttpUrl().newBuilder()
            .addQueryParameter("ver", "1").addQueryParameter("man", "yes").addQueryParameter("client", "pc")
            .addQueryParameter("keyword", keyword)
            .apply { if (duration > 0) addQueryParameter("duration", (duration * 1000).toString()) }
            .build()
        val body = http.newCall(request(searchUrl.toString())).execute().use { res ->
            if (res.code != 200) { log("kugou search HTTP ${res.code}"); return null }
            res.body?.string().orEmpty()
        }
        val cands = json.parseToJsonElement(body).jsonObject["candidates"]?.jsonArray ?: return null
        val sorted = cands.map { it.jsonObject }.sortedBy { o ->
            val d = (o["duration"]?.jsonPrimitive?.longOrNull ?: 0L) / 1000.0
            if (duration > 0 && d > 0) abs(d - duration) else 30.0
        }
        for (o in sorted.take(3)) {
            val id = o["id"]?.jsonPrimitive?.contentOrNull ?: continue
            val key = o["accesskey"]?.jsonPrimitive?.contentOrNull ?: continue
            val dl = "https://lyrics.kugou.com/download?ver=1&client=pc&id=$id&accesskey=$key&fmt=lrc&charset=utf8"
            val db = http.newCall(request(dl)).execute().use { if (it.code == 200) it.body?.string().orEmpty() else "" }
            if (db.isBlank()) continue
            val content = json.parseToJsonElement(db).jsonObject["content"]?.jsonPrimitive?.contentOrNull ?: continue
            val lrc = runCatching { String(java.util.Base64.getDecoder().decode(content), Charsets.UTF_8) }.getOrNull() ?: continue
            parse(lrc, SRC_KUGOU)?.let { return it }
        }
        return null
    }

    // ---- LRCLIB (direct) ----------------------------------------------------------

    private fun lrclibGet(title: String, artist: String, duration: Int, album: String?): Lyrics? {
        if (artist.isBlank() || duration <= 0) return null
        val url = "https://lrclib.net/api/get".toHttpUrl().newBuilder()
            .addQueryParameter("track_name", title)
            .addQueryParameter("artist_name", artist)
            .addQueryParameter("duration", duration.toString())
            .apply { if (!album.isNullOrBlank()) addQueryParameter("album_name", album) }
            .build()
        return runCatching {
            http.newCall(request(url.toString())).execute().use { res ->
                if (res.code != 200) { log("lrclib get HTTP ${res.code}"); return null }
                val track = json.decodeFromString<LrcTrack>(res.body?.string().orEmpty())
                track.toLyrics()
            }
        }.onFailure { log("lrclib get failed", it) }.getOrNull()
    }

    private fun lrclibSearch(title: String, artist: String, duration: Int): Lyrics? {
        val attempts = listOf(
            mapOf("track_name" to title, "artist_name" to artist),
            mapOf("track_name" to title),
            mapOf("q" to "$artist $title"),
            mapOf("q" to title),
        )
        for (params in attempts) {
            val url = "https://lrclib.net/api/search".toHttpUrl().newBuilder()
                .apply { params.forEach { (k, v) -> if (v.isNotBlank()) addQueryParameter(k, v) } }
                .build()
            val tracks = runCatching {
                http.newCall(request(url.toString())).execute().use { res ->
                    if (res.code != 200) { log("lrclib search HTTP ${res.code}"); return@use emptyList() }
                    json.decodeFromString<List<LrcTrack>>(res.body?.string().orEmpty())
                }
            }.onFailure { log("lrclib search failed", it) }.getOrDefault(emptyList())
                .filter { !it.instrumental && (it.syncedLyrics != null || it.plainLyrics != null) }
            if (tracks.isEmpty()) continue

            val best = tracks
                .sortedWith(
                    compareBy<LrcTrack> { if (it.syncedLyrics != null) 0 else 1 }
                        .thenBy { t -> if (duration > 0 && t.duration != null) abs(t.duration - duration) else 999.0 }
                )
                .firstOrNull { duration <= 0 || it.duration == null || abs(it.duration - duration) <= 15 }
                ?: tracks.first()
            best.toLyrics()?.let { return it }
        }
        return null
    }

    private fun request(url: String, referer: String? = null): Request = Request.Builder()
        .url(url)
        .header("User-Agent", if (referer == null) "Redify/2.1 (https://github.com/julml18/Redify)" else "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36")
        .apply { if (referer != null) header("Referer", referer) }
        .build()

    private fun LrcTrack.toLyrics(): Lyrics? =
        syncedLyrics?.let { parse(it, "LRCLIB") } ?: plainLyrics?.let { parse(it, "LRCLIB") }

    // ---- Fallbacks -------------------------------------------------------------------

    private suspend fun lrclibModule(song: SongItem, title: String, artist: String, duration: Int): Lyrics? =
        runCatching { LrcLib.getLyrics(title = title, artist = artist, duration = duration, album = song.album?.name).getOrNull() }
            .getOrNull()?.let { parse(it, "LRCLIB") }

    private suspend fun fromYouTube(song: SongItem): Lyrics? = runCatching {
        val next = YouTube.next(song.endpoint ?: WatchEndpoint(videoId = song.id)).getOrNull() ?: return null
        val endpoint = next.lyricsEndpoint ?: return null
        val text = YouTube.lyrics(endpoint).getOrNull() ?: return null
        parse(text, SRC_YOUTUBE)
    }.onFailure { log("youtube lyrics failed", it) }.getOrNull()

    // ---- Parsing -----------------------------------------------------------------------

    private val offsetTag = Regex("""\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)

    fun parse(text: String, source: String): Lyrics? {
        val lines = text.lines()
        // LRC "[offset:+300]" = shift timestamps (positive = lyrics shown earlier).
        val offset = offsetTag.find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val synced = lines.mapNotNull { raw ->
            val m = lrcLine.matchEntire(raw.trim()) ?: return@mapNotNull null
            if (m.groupValues[4].contains(Regex("""^\s*(作词|作曲|编曲|制作人|词|曲)\s*[:：]"""))) return@mapNotNull null
            val (min, sec, frac, body) = m.destructured
            val fracMs = when (frac.length) { 0 -> 0; 1 -> frac.toInt() * 100; 2 -> frac.toInt() * 10; else -> frac.take(3).toInt() }
            LyricLine((min.toLong() * 60_000 + sec.toLong() * 1000 + fracMs - offset).coerceAtLeast(0), body.trim())
        }
        if (synced.isNotEmpty()) return Lyrics(synced.sortedBy { it.timeMs }, synced = true, source = source)
        val plain = lines.map { it.trim() }.filter { it.isNotEmpty() }
        if (plain.isEmpty()) return null
        return Lyrics(plain.map { LyricLine(0, it) }, synced = false, source = source)
    }
}
