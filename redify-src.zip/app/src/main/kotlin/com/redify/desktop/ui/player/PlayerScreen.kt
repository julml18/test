package com.redify.desktop.ui.player

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.graphics.drawscope.rotate
import com.redify.desktop.data.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.redify.desktop.LocalPlayer
import com.redify.desktop.data.Library
import com.redify.desktop.data.Lyrics
import com.redify.desktop.data.LyricsProvider
import com.redify.desktop.playback.RepeatMode
import com.redify.desktop.ui.Artwork
import com.redify.desktop.ui.formatMillis
import com.redify.desktop.ui.ArtworkImage

enum class PlayerMode { VINYL, QUEUE, LYRICS }

/** Musicfy's expanded player: blurred artwork background, vinyl / queue / lyrics modes, lyric pill, menu sheet. */
@Composable
fun PlayerScreen(onCollapse: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    var mode by remember { mutableStateOf(PlayerMode.VINYL) }
    var menuOpen by remember { mutableStateOf(false) }

    var lyrics by remember { mutableStateOf<Lyrics?>(null) }
    var lyricsLoading by remember { mutableStateOf(false) }
    var lyricsSource by remember { mutableStateOf<String?>(null) }   // null = automatic
    LaunchedEffect(song?.id) { lyricsSource = null }
    LaunchedEffect(song?.id, lyricsSource) {
        lyrics = null
        if (song != null) {
            lyricsLoading = true
            lyrics = runCatching {
                lyricsSource?.let { LyricsProvider.fromSource(song, it) } ?: LyricsProvider.forSong(song)
            }.getOrNull()
            lyricsLoading = false
        }
    }
    // Warm up lyrics for the next song so they are ready the moment it starts.
    LaunchedEffect(state.currentIndex, state.queue.size) {
        state.queue.getOrNull(state.currentIndex + 1)?.let(LyricsProvider::prefetch)
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF0E0E10))) {
        // Blurred artwork background, like Musicfy's player.
        val settingsBg by Settings.state.collectAsState()
        if (song?.thumbnail != null && settingsBg.blurEnabled) {
            ArtworkImage(song.thumbnail, Modifier.fillMaxSize().blur(settingsBg.blurStrength.dp).alpha(0.55f), size = 544)
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.25f), Color.Black.copy(alpha = 0.75f)))))

        if (mode == PlayerMode.VINYL) {
            if (settingsBg.playerStyle == "TURNTABLE") VinylView(onShowQueue = { mode = PlayerMode.QUEUE }, onMenu = { menuOpen = true }, onLyrics = { mode = PlayerMode.LYRICS }, lyrics = lyrics)
            else StyledPlayerView(settingsBg.playerStyle, onShowQueue = { mode = PlayerMode.QUEUE }, onMenu = { menuOpen = true }, onLyrics = { mode = PlayerMode.LYRICS }, lyrics = lyrics)
        } else BoxWithConstraints(Modifier.fillMaxSize()) {
            val contentWidth = minOf(maxWidth, 720.dp)
            Column(Modifier.width(contentWidth).fillMaxHeight().align(Alignment.Center)) {
                AnimatedContent(
                    targetState = mode,
                    transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(200)) },
                    modifier = Modifier.weight(1f),
                ) { m ->
                    when (m) {
                        PlayerMode.VINYL -> {}
                        PlayerMode.QUEUE -> QueueView(onShowVinyl = { mode = PlayerMode.VINYL })
                        PlayerMode.LYRICS -> LyricsView(lyrics, loading = lyricsLoading, selectedSource = lyricsSource, onPickSource = { lyricsSource = it }, onBack = { mode = PlayerMode.VINYL })
                    }
                }
                if (mode == PlayerMode.QUEUE) {
                    LyricPill(lyrics, onClick = { mode = PlayerMode.LYRICS })
                }
            }
        }

        IconButton(onClick = onCollapse, modifier = Modifier.align(Alignment.TopStart).padding(12.dp)) {
            Icon(Icons.Default.KeyboardArrowDown, "Tutup", tint = Color.White)
        }

        if (menuOpen) PlayerMenuSheet(onDismiss = { menuOpen = false })
    }
}

// ---- Vinyl -------------------------------------------------------------------------

@Composable
internal fun VinylView(onShowQueue: () -> Unit, onMenu: () -> Unit, onLyrics: () -> Unit, lyrics: Lyrics?) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    val likedIds by Library.likedIds.collectAsState()
    val liked = song != null && song.id in likedIds

    // Double-tap the record = like, with a heart burst + "Added to Liked Songs" note (Musicfy).
    val heart = remember { Animatable(0f) }
    var heartTick by remember { mutableStateOf(0) }
    var likedNote by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(heartTick) {
        if (heartTick == 0) return@LaunchedEffect
        heart.snapTo(0f)
        heart.animateTo(1f, tween(260))
        kotlinx.coroutines.delay(500)
        heart.animateTo(0f, tween(300))
        kotlinx.coroutines.delay(1500)
        likedNote = null
    }

    Box(Modifier.fillMaxSize()) {
        // Turntable fills the window: the record sits on the left and bleeds off the edge like
        // Musicfy; the tonearm is computed from the record so the needle really lands on it.
        Turntable(thumbnail = song?.thumbnail, playing = state.isPlaying, modifier = Modifier.fillMaxSize())
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val w = maxWidth; val h = maxHeight
            Box(
                Modifier.fillMaxWidth(0.5f).fillMaxHeight(0.78f).pointerInput(song?.id) {
                    detectTapGestures(
                        onDoubleTap = {
                            song?.let { s ->
                                val wasLiked = s.id in likedIds
                                Library.toggleLike(s)
                                likedNote = if (wasLiked) "Removed from Liked Songs" else "Added to Library and Liked Songs"
                                heartTick++
                            }
                        },
                        onTap = { player.togglePlayPause() },
                    )
                }
            )
            if (heart.value > 0f) {
                Icon(
                    Icons.Default.Favorite, null, tint = Color.White.copy(alpha = heart.value),
                    modifier = Modifier.size(160.dp).offset(x = w * 0.22f - 80.dp, y = h * 0.42f - 80.dp).scale(0.6f + 0.6f * heart.value),
                )
            }
        }

        // Volume under the record: [ − ] (speaker + slider) [ + ]
        Row(
            Modifier.align(Alignment.BottomStart).padding(start = 40.dp, bottom = 28.dp).width(360.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RoundButton(size = 44.dp, onClick = { player.setVolume(state.volume - 5) }) { Icon(Icons.Default.Remove, "Kecilkan", tint = Color.White, modifier = Modifier.size(22.dp)) }
            var lastVol by remember { mutableStateOf(100) }
            Icon(
                when { state.volume == 0 -> Icons.Default.VolumeOff; state.volume < 50 -> Icons.Default.VolumeDown; else -> Icons.Default.VolumeUp },
                "Bisukan", tint = Color.White,
                modifier = Modifier.size(26.dp).clickable {
                    if (state.volume > 0) { lastVol = state.volume; player.setVolume(0) } else player.setVolume(lastVol.coerceAtLeast(10))
                },
            )
            Box(Modifier.weight(1f)) {
                ProgressBar(fraction = state.volume / 100f, onSeek = { player.setVolume((it * 100).toInt()) }, onDrag = { player.setVolume((it * 100).toInt()) })
            }
            Text("${state.volume}%", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.width(38.dp))
            RoundButton(size = 44.dp, onClick = { player.setVolume(state.volume + 5) }) { Icon(Icons.Default.Add, "Besarkan", tint = Color.White, modifier = Modifier.size(22.dp)) }
        }

        Column(Modifier.align(Alignment.BottomEnd).fillMaxWidth(0.55f).widthIn(max = 780.dp).padding(end = 24.dp)) {
        // Controls column on the right, info + menu on the left (Musicfy order).
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MenuRow(Icons.Default.MoreHoriz, "Other menu", onMenu)
                MenuRow(Icons.Default.Timer, if (state.sleepTimerEndsAt != null) "Sleep timer aktif" else "Sleep timer") { onMenu() }
                MenuRow(Icons.Default.PlayCircleOutline, "See video") {
                    song?.let { com.redify.desktop.openUrl("https://music.youtube.com/watch?v=${it.id}") }
                }
                MenuRow(
                    if (state.repeat == RepeatMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    when (state.repeat) { RepeatMode.OFF -> "Repeat"; RepeatMode.ALL -> "Repeat: all"; RepeatMode.ONE -> "Repeat: one" },
                    player::cycleRepeat,
                )
                Spacer(Modifier.height(6.dp))
                if (likedNote != null) Text(likedNote!!, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, modifier = Modifier.padding(start = 64.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RoundButton(size = 48.dp, onClick = onShowQueue) { Icon(Icons.Default.ExpandMore, "Antrean", tint = Color.White) }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                song?.title ?: "Tidak ada yang diputar",
                                fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold, color = Color.White,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                            )
                            val settings by Settings.state.collectAsState()
                            if (settings.showFormatBadge && state.streamCodec != null) {
                                Spacer(Modifier.width(10.dp))
                                CodecChip(
                                    (state.streamCodec ?: "") +
                                        (if (settings.showSampleRate && state.streamSampleRate != null) " ${state.streamSampleRate!! / 1000f}kHz" else "")
                                )
                            }
                        }
                        Text(
                            song?.artists?.joinToString { it.name } ?: "",
                            fontSize = 18.sp, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                RoundButton(size = 64.dp, onClick = { song?.let(Library::toggleLike) }) {
                    Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Sukai", tint = Color.White)
                }
                RoundButton(size = 64.dp, onClick = player::previous) { Icon(Icons.Default.FastRewind, "Sebelumnya", tint = Color.White) }
                RoundButton(size = 64.dp, onClick = player::togglePlayPause) {
                    Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Putar", tint = Color.White)
                }
                RoundButton(size = 64.dp, onClick = player::next) { Icon(Icons.Default.FastForward, "Berikutnya", tint = Color.White) }
            }
        }
        LyricPill(lyrics, onClick = onLyrics)
        }
    }
}

@Composable
internal fun Turntable(thumbnail: String?, playing: Boolean, modifier: Modifier) {
    var angle by remember { mutableStateOf(0f) }
    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) angle = (angle + (now - last) / 1_000_000_000f * 33.3f / 60f * 360f) % 360f
                last = now
            }
        }
    }
    // 0 = arm parked outside the record, 1 = needle on the outer groove.
    val armT by animateFloatAsState(if (playing) 1f else 0f, tween(900))

    BoxWithConstraints(modifier.clipToBounds()) {
        val w = maxWidth; val h = maxHeight
        val diameter = minOf(h * 1.15f, w * 0.62f)
        val cx = w * 0.22f
        val cy = h * 0.42f

        // Record (rotating)
        Box(
            Modifier
                .size(diameter)
                .offset(x = cx - diameter / 2, y = cy - diameter / 2)
                .rotate(angle),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2
                drawCircle(Color(0xFF0B0B0B), r)
                var gr = r * 0.99f
                while (gr > r * 0.40f) {
                    drawCircle(Color.White.copy(alpha = 0.035f), gr, style = Stroke(width = 1.2f))
                    gr -= r * 0.011f
                }
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.13f), Color.Transparent, Color.White.copy(alpha = 0.07f), Color.Transparent)),
                    r,
                )
            }
            Artwork(thumbnail, Modifier.size(diameter * 0.40f).aspectRatio(1f), CircleShape)
        }

        // Tonearm (static canvas on top)
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(cx.toPx(), cy.toPx())
            val radius = diameter.toPx() / 2
            // Pivot sits just outside the record's top-right, like a real deck.
            val pivot = Offset(center.x + radius * 1.02f, (center.y - radius * 0.80f).coerceAtLeast(size.height * 0.04f))
            // Needle target: on the record at the 1 o'clock side facing the pivot.
            val dir = (pivot - center).let { d -> val len = kotlin.math.hypot(d.x, d.y); Offset(d.x / len, d.y / len) }
            val onRecord = center + dir * (radius * 0.86f)
            val parked = center + dir * (radius * 1.10f)
            val needle = Offset(parked.x + (onRecord.x - parked.x) * armT, parked.y + (onRecord.y - parked.y) * armT)

            val armW = radius * 0.045f
            // Base / counterweight
            drawCircle(Color(0xFF1C1C1E), armW * 4.2f, pivot)
            drawCircle(Color(0xFF2E2E31), armW * 3f, pivot)
            drawLine(Color(0xFF3A3A3E), pivot, Offset(pivot.x + armW * 5f, pivot.y - armW * 2.5f), strokeWidth = armW * 2.2f, cap = StrokeCap.Round)
            // Arm
            drawLine(Color(0xFF8E8E93), pivot, needle, strokeWidth = armW, cap = StrokeCap.Round)
            drawLine(Color(0xFFD6D6DA), pivot, needle, strokeWidth = armW * 0.45f, cap = StrokeCap.Round)
            // Headshell + stylus
            val back = Offset(needle.x + (pivot.x - needle.x) * 0.06f, needle.y + (pivot.y - needle.y) * 0.06f)
            drawLine(Color(0xFF2A2A2D), back, needle, strokeWidth = armW * 2.4f, cap = StrokeCap.Round)
            drawCircle(Color(0xFF151517), armW * 1.3f, needle)
        }
    }
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(24.dp)).clickable(onClick = onClick).padding(end = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RoundButton(size = 44.dp, onClick = onClick) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(14.dp))
        Text(label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun RoundButton(size: androidx.compose.ui.unit.Dp, onClick: () -> Unit, enabled: Boolean = true, solid: Boolean = false, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (solid) Color(0xFF2A2A2E) else Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
internal fun CodecChip(label: String) {
    Text(
        label,
        color = Color.White.copy(alpha = 0.7f),
        fontSize = 11.sp,
        modifier = Modifier
            .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

// ---- Queue -------------------------------------------------------------------------------

@Composable
private fun QueueView(onShowVinyl: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    val likedIds by Library.likedIds.collectAsState()
    val liked = song != null && song.id in likedIds
    val listState = rememberLazyListState()
    LaunchedEffect(state.currentIndex) { if (state.currentIndex >= 0) listState.animateScrollToItem(state.currentIndex) }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(56.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Artwork(song?.thumbnail, Modifier.size(88.dp), RoundedCornerShape(12.dp))
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Text(song?.title ?: "", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artists?.joinToString { it.name } ?: "", fontSize = 16.sp, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RoundButton(size = 52.dp, onClick = { song?.let(Library::toggleLike) }) {
                Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Color.White)
            }
        }
        Spacer(Modifier.height(20.dp))

        Box(Modifier.weight(1f)) {
            LazyColumn(state = listState, contentPadding = PaddingValues(bottom = 24.dp, end = 72.dp)) {
                itemsIndexed(state.queue, key = { i, s -> "$i:${s.id}" }) { index, item ->
                    val isCurrent = index == state.currentIndex
                    if (isCurrent) {
                        Text("Now Playing", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(top = 8.dp, bottom = 10.dp))
                    }
                    if (index == state.currentIndex + 1) {
                        Text("Continue Playing", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(top = 18.dp))
                        Text("Queue from ${state.queueTitle ?: "antrean"}", fontSize = 14.sp, color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(bottom = 10.dp))
                    }
                    val past = index < state.currentIndex
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isCurrent) Color.White.copy(alpha = 0.1f) else Color.Transparent)
                            .clickable { player.skipTo(index) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .alpha(if (past) 0.45f else 1f),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Artwork(item.thumbnail, Modifier.size(56.dp), RoundedCornerShape(10.dp))
                            if (isCurrent) Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.artists.joinToString { it.name }, fontSize = 14.sp, color = Color.White.copy(alpha = 0.65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (!isCurrent) DragHandle(onMove = { delta -> player.moveInQueue(index, index + delta) })
                    }
                }
            }
            // Floating controls on the right, like the screenshot (solid so the list never shows through).
            Column(Modifier.align(Alignment.BottomEnd).padding(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                RoundButton(size = 48.dp, onClick = onShowVinyl, solid = true) { Icon(Icons.Default.ExpandLess, null, tint = Color.White) }
                RoundButton(size = 48.dp, onClick = player::toggleShuffle, solid = true) {
                    Icon(Icons.Default.Shuffle, null, tint = if (state.shuffle) Color.White else Color.White.copy(alpha = 0.5f))
                }
                RoundButton(size = 48.dp, onClick = player::cycleRepeat, solid = true) {
                    Icon(
                        if (state.repeat == RepeatMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, null,
                        tint = if (state.repeat != RepeatMode.OFF) Color.White else Color.White.copy(alpha = 0.5f),
                    )
                }
            }
        }

        TransportControls()
        Spacer(Modifier.height(20.dp))
    }
}

/** Progress bar + time labels + big prev / play / next, shared by the queue and lyrics views. */
@Composable
internal fun TransportControls() {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    Column(Modifier.fillMaxWidth()) {
        var dragging by remember { mutableStateOf(false) }
        var dragPos by remember { mutableStateOf(0f) }
        val duration = state.durationMs.coerceAtLeast(1L).toFloat()
        ProgressBar(
            fraction = (if (dragging) dragPos else state.positionMs.toFloat()) / duration,
            onSeek = { f -> dragging = false; player.seekTo((f * duration).toLong()) },
            onDrag = { f -> dragging = true; dragPos = f * duration },
        )
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Text(formatMillis(if (dragging) dragPos.toLong() else state.positionMs), color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(formatMillis(state.durationMs), color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = player::previous, modifier = Modifier.size(80.dp)) { Icon(Icons.Default.FastRewind, null, tint = Color.White, modifier = Modifier.size(64.dp)) }
            IconButton(onClick = player::togglePlayPause, modifier = Modifier.size(88.dp)) {
                Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(72.dp))
            }
            IconButton(onClick = player::next, modifier = Modifier.size(80.dp)) { Icon(Icons.Default.FastForward, null, tint = Color.White, modifier = Modifier.size(64.dp)) }
        }
    }
}

/** "Next Song" pill shown under the lyrics, like Musicfy. */
@Composable
internal fun NextSongPill() {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val next = state.queue.getOrNull(state.currentIndex + 1) ?: return
    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp)
            .clip(RoundedCornerShape(22.dp)).background(Color.White.copy(alpha = 0.1f)).border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(22.dp))
            .clickable(onClick = player::next).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(next.thumbnail, Modifier.size(40.dp), RoundedCornerShape(8.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Next Song", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
            Text("${next.title} - ${next.artists.joinToString { it.name }}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun ProgressBar(fraction: Float, onSeek: (Float) -> Unit, onDrag: (Float) -> Unit) {
    var widthPx by remember { mutableStateOf(1f) }
    Box(
        Modifier
            .fillMaxWidth()
            .height(20.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { onSeek((it.x / widthPx).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                var last = 0f
                detectDragGestures(
                    onDragEnd = { onSeek(last) },
                    onDrag = { change, _ -> change.consume(); last = (change.position.x / widthPx).coerceIn(0f, 1f); onDrag(last) },
                )
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)))
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(6.dp).clip(CircleShape).background(Color.White))
    }
}

// ---- Lyrics (karaoke) -------------------------------------------------------------------

@Composable
private fun LyricsView(lyrics: Lyrics?, loading: Boolean, selectedSource: String?, onPickSource: (String?) -> Unit, onBack: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    val listState = rememberLazyListState()
    val position = rememberLivePosition()
    val settings by Settings.state.collectAsState()
    val activeIndex = lyrics?.indexAt(position) ?: -1
    var showSources by remember { mutableStateOf(false) }
    LaunchedEffect(activeIndex) { if (activeIndex >= 0) listState.animateScrollToItem(activeIndex, scrollOffset = -160) }

    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(52.dp))
        // Header: song + source badge
        Row(Modifier.clickable(onClick = onBack), verticalAlignment = Alignment.CenterVertically) {
            Artwork(song?.thumbnail, Modifier.size(60.dp), RoundedCornerShape(12.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(song?.title ?: "", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artists?.joinToString { it.name } ?: "", fontSize = 14.sp, color = Color.White.copy(alpha = 0.7f), maxLines = 1)
            }
            Spacer(Modifier.width(12.dp))
            Box(Modifier.clickable { showSources = !showSources }) { SourceBadge(lyrics, loading) }
        }
        // Source chips + timing control (click the badge to show/hide)
        AnimatedVisibility(visible = showSources || (lyrics == null && !loading)) {
            Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SourceChip("Otomatis", selectedSource == null) { onPickSource(null) }
                    LyricsProvider.sources.forEach { src ->
                        SourceChip(src, selectedSource == src, loading = loading && selectedSource == src) { onPickSource(src) }
                    }
                }
                Spacer(Modifier.width(12.dp))
                OffsetControl(settings.lyricsOffsetMs)
            }
        }
        Spacer(Modifier.height(8.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading && lyrics == null -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                    Spacer(Modifier.height(16.dp))
                    Text("Mencari lirik…", color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
                }
                lyrics == null -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Lyrics, null, tint = Color.White.copy(alpha = 0.35f), modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("Lirik tidak ditemukan", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (selectedSource == null) "Semua sumber sudah dicoba. Pilih sumber di atas untuk mencoba lagi."
                        else "Tidak ada di $selectedSource. Coba sumber lain di atas.",
                        color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp, textAlign = TextAlign.Center,
                    )
                }
                else -> {
                    LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 120.dp, bottom = 320.dp)) {
                        itemsIndexed(lyrics.lines) { i, line ->
                            val active = i == activeIndex
                            val distance = if (activeIndex < 0) 0 else kotlin.math.abs(i - activeIndex)
                            val targetAlpha = when {
                                !lyrics.synced -> 0.9f
                                active -> 1f
                                i < activeIndex -> (0.4f - distance * 0.08f).coerceAtLeast(0.14f)
                                else -> (0.55f - distance * 0.06f).coerceAtLeast(0.16f)
                            }
                            val alpha by animateFloatAsState(targetAlpha, tween(300), label = "alpha")
                            val scale by animateFloatAsState(if (active) 1f else 0.94f, tween(300), label = "scale")
                            // Lines far from the current one get softly blurred, like Musicfy.
                            val blurTarget = if (!lyrics.synced || activeIndex < 0) 0f else ((distance - 1).coerceAtLeast(0) * 1.2f).coerceAtMost(6f)
                            val blurDp by animateFloatAsState(blurTarget, tween(300), label = "blur")
                            val text: AnnotatedString = if (active && lyrics.synced) karaoke(line.text, lyrics, i, position)
                            else AnnotatedString(line.text.ifBlank { "♪" })
                            Text(
                                text,
                                fontSize = 32.sp,
                                lineHeight = 40.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (active) Color.White else Color.White.copy(alpha = alpha),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .graphicsLayer { scaleX = scale; scaleY = scale; transformOrigin = TransformOrigin(0f, 0.5f) }
                                    .then(if (blurDp > 0.05f) Modifier.blur(blurDp.dp) else Modifier)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable(enabled = lyrics.synced) { player.seekTo(line.timeMs) }
                                    .padding(horizontal = 8.dp, vertical = 10.dp),
                            )
                        }
                        item {
                            Spacer(Modifier.height(24.dp))
                            Text(
                                "Sumber: ${lyrics.source} · ${if (lyrics.synced) "lirik tersinkron" else "teks saja"}",
                                color = Color.White.copy(alpha = 0.4f), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp),
                            )
                        }
                    }
                    // Soft fade at the top and bottom edges of the list.
                    Box(Modifier.fillMaxWidth().height(90.dp).align(Alignment.TopCenter).background(Brush.verticalGradient(listOf(Color(0xFF0E0E10).copy(alpha = 0.9f), Color.Transparent))))
                    Box(Modifier.fillMaxWidth().height(140.dp).align(Alignment.BottomCenter).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF0E0E10).copy(alpha = 0.95f)))))
                }
            }
        }
        TransportControls()
        NextSongPill()
    }
}

@Composable
private fun SourceBadge(lyrics: Lyrics?, loading: Boolean) {
    val (label, tint) = when {
        loading && lyrics == null -> "Mencari…" to Color.White.copy(alpha = 0.6f)
        lyrics == null -> "Tidak ada" to Color(0xFFFF8A80)
        lyrics.synced -> "${lyrics.source} · Sinkron" to Color(0xFF9CFFB0)
        else -> "${lyrics.source} · Teks" to Color(0xFFFFE08A)
    }
    Row(
        Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.1f)).border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(tint))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun SourceChip(label: String, selected: Boolean, loading: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.1f))
            .border(1.dp, Color.White.copy(alpha = if (selected) 0f else 0.12f), CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 2.dp, color = if (selected) Color.Black else Color.White)
            Spacer(Modifier.width(8.dp))
        }
        Text(label, color = if (selected) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Lyrics timing: + shows lines earlier, − later; click the value to reset. */
@Composable
private fun OffsetControl(offsetMs: Int) {
    Row(
        Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.1f)).border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = { Settings.update { it.copy(lyricsOffsetMs = it.lyricsOffsetMs - 100) } }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Remove, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
        Column(Modifier.clickable { Settings.update { it.copy(lyricsOffsetMs = 300) } }.padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${if (offsetMs >= 0) "+" else ""}$offsetMs ms", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("waktu lirik", color = Color.White.copy(alpha = 0.5f), fontSize = 9.sp)
        }
        IconButton(onClick = { Settings.update { it.copy(lyricsOffsetMs = it.lyricsOffsetMs + 100) } }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
    }
}

/**
 * Playback position that advances every frame between VLC time events (which only arrive a few
 * times a second), plus the user's lyrics offset. This is what keeps karaoke lines in sync.
 */
@Composable
fun rememberLivePosition(): Long {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val settings by Settings.state.collectAsState()
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state.isPlaying) {
        while (state.isPlaying) { withFrameNanos { now = System.currentTimeMillis() } }
    }
    val base = if (state.isPlaying) state.positionMs + ((now - state.positionAtMs) * state.rate).toLong() else state.positionMs
    return (base + settings.lyricsOffsetMs).coerceAtLeast(0)
}

/** Splits a lyric line into a sung (bright) part and the rest (dim), by elapsed fraction of the line. */
internal fun karaoke(text: String, lyrics: Lyrics, index: Int, positionMs: Long): AnnotatedString {
    if (!lyrics.synced) return AnnotatedString(text.ifBlank { "♪" })
    val line = lyrics.lines[index]
    val next = lyrics.lines.getOrNull(index + 1)?.timeMs ?: (line.timeMs + 4000)
    val f = ((positionMs - line.timeMs).toFloat() / (next - line.timeMs).coerceAtLeast(1)).coerceIn(0f, 1f)
    val shown = text.ifBlank { "♪" }
    // Advance word by word so the highlight lands on word boundaries.
    var k = (shown.length * f).toInt()
    val nextSpace = shown.indexOf(' ', k)
    if (f < 1f && nextSpace >= 0) k = nextSpace
    return buildAnnotatedString {
        withStyle(SpanStyle(color = Color.White)) { append(shown.take(k)) }
        withStyle(SpanStyle(color = Color.White.copy(alpha = 0.45f))) { append(shown.drop(k)) }
    }
}

/** One-line lyric pill at the bottom of the player, like Musicfy. */
@Composable
internal fun LyricPill(lyrics: Lyrics?, onClick: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val position = rememberLivePosition()
    val idx = lyrics?.indexAt(position) ?: -1
    val line = lyrics?.lines?.getOrNull(idx)
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .shadow(8.dp, RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.1f))
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(28.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) {
        val text: AnnotatedString = when {
            lyrics == null -> AnnotatedString("Lirik tidak tersedia")
            line == null -> AnnotatedString("♪")
            else -> karaoke(line.text, lyrics, idx, position)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = Color.White.copy(alpha = 0.7f), fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(Icons.Default.Lyrics, null, tint = Color.White.copy(alpha = 0.6f))
        }
    }
}

/**
 * Two-line drag handle: drag it up/down to move the row. Calls [onMove] with -1 / +1 every time
 * the pointer travels one row height, so the row "walks" through the list while dragging.
 */
@Composable
fun DragHandle(rowHeight: androidx.compose.ui.unit.Dp = 72.dp, tint: Color = Color.White, onMove: (Int) -> Unit) {
    val rowPx = with(androidx.compose.ui.platform.LocalDensity.current) { rowHeight.toPx() }
    var acc by remember { mutableStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    Icon(
        Icons.Default.DragHandle, "Geser untuk memindahkan",
        tint = if (dragging) tint else tint.copy(alpha = 0.5f),
        modifier = Modifier
            .size(36.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { acc = 0f; dragging = true },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                    onDrag = { change, offset ->
                        change.consume()
                        acc += offset.y
                        while (acc > rowPx) { onMove(+1); acc -= rowPx }
                        while (acc < -rowPx) { onMove(-1); acc += rowPx }
                    },
                )
            },
    )
}
