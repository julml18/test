package com.redify.desktop.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import com.redify.desktop.LocalNavigator
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.music.innertube.YouTube
import com.music.innertube.YouTube.SearchFilter
import com.music.innertube.models.SongItem
import com.music.innertube.models.YTItem
import com.redify.desktop.LocalPlayer
import com.redify.desktop.ui.GridItemCard
import com.redify.desktop.ui.ItemCarousel
import com.redify.desktop.ui.SectionHeader
import com.redify.desktop.ui.SongRow

private enum class Filter(val label: String, val filter: SearchFilter?) {
    ALL("Semua", null),
    SONGS("Lagu", SearchFilter.FILTER_SONG),
    VIDEOS("Video", SearchFilter.FILTER_VIDEO),
    ALBUMS("Album", SearchFilter.FILTER_ALBUM),
    ARTISTS("Artis", SearchFilter.FILTER_ARTIST),
    PLAYLISTS("Playlist", SearchFilter.FILTER_COMMUNITY_PLAYLIST),
}

/** Search page with its own field + suggestions (Musicfy has no top bar; search is a tab). */
@Composable
fun SearchPage(initialQuery: String) {
    val nav = LocalNavigator.current
    var text by remember { mutableStateOf(initialQuery) }
    var query by remember(initialQuery) { mutableStateOf(initialQuery) }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    var showSuggestions by remember { mutableStateOf(false) }

    LaunchedEffect(text) {
        if (text.length < 2 || text == query) { suggestions = emptyList(); return@LaunchedEffect }
        kotlinx.coroutines.delay(250)
        YouTube.searchSuggestions(text).onSuccess { suggestions = it.queries.take(8) }
    }
    fun submit(q: String) {
        val t = q.trim(); if (t.isEmpty()) return
        text = t; query = t; showSuggestions = false; suggestions = emptyList()
    }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(16.dp))
        Box(Modifier.padding(horizontal = 24.dp)) {
            androidx.compose.material3.OutlinedTextField(
                value = text,
                onValueChange = { text = it; showSuggestions = true },
                singleLine = true,
                placeholder = { Text("Cari lagu, album, artis…") },
                leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Search, null) },
                shape = androidx.compose.foundation.shape.CircleShape,
                modifier = Modifier.fillMaxWidth().onPreviewKeyEvent { e ->
                    if (e.key == androidx.compose.ui.input.key.Key.Enter) { submit(text); true } else false
                },
            )
            androidx.compose.material3.DropdownMenu(
                expanded = showSuggestions && suggestions.isNotEmpty(),
                onDismissRequest = { showSuggestions = false },
                properties = androidx.compose.ui.window.PopupProperties(focusable = false),
            ) {
                suggestions.forEach { s -> androidx.compose.material3.DropdownMenuItem(text = { Text(s) }, onClick = { submit(s) }) }
            }
        }
        if (query.isBlank()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Ketik lalu tekan Enter untuk mencari", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            SearchScreen(query)
        }
    }
}

@Composable
fun SearchScreen(query: String) {
    var filter by remember(query) { mutableStateOf(Filter.ALL) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 16.dp)) {
            Text("Hasil untuk \"$query\"", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Filter.entries) { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f.label) })
                }
            }
        }
        if (filter == Filter.ALL) SearchSummary(query) else SearchFiltered(query, filter.filter!!)
    }
}

@Composable
private fun SearchSummary(query: String) {
    val player = LocalPlayer.current
    Loaded(key = "summary:$query", fetch = { YouTube.searchSummary(query) }) { page ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
            page.summaries.forEach { summary ->
                item { SectionHeader(summary.title) }
                val songs = summary.items.filterIsInstance<SongItem>()
                if (songs.size == summary.items.size && songs.isNotEmpty()) {
                    items(songs, key = { summary.title + it.id }) { song ->
                        SongRow(song, onClick = { player.playQueue(songs, songs.indexOf(song), summary.title) })
                    }
                } else {
                    item { ItemCarousel(summary.items) }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
private fun SearchFiltered(query: String, filter: SearchFilter) {
    val player = LocalPlayer.current
    var items by remember(query, filter) { mutableStateOf<List<YTItem>>(emptyList()) }
    var continuation by remember(query, filter) { mutableStateOf<String?>(null) }
    var loadingMore by remember { mutableStateOf(false) }

    Loaded(key = "search:$query:${filter.value}", fetch = {
        YouTube.search(query, filter).onSuccess { items = it.items; continuation = it.continuation }
    }) {
        val songs = items.filterIsInstance<SongItem>()
        val allSongs = songs.size == items.size

        suspend fun loadMore() {
            val c = continuation ?: return
            loadingMore = true
            YouTube.searchContinuation(c).onSuccess {
                items = items + it.items
                continuation = it.continuation
            }
            loadingMore = false
        }

        if (allSongs) {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 170.dp)) {
                items(songs, key = { it.id }) { song ->
                    SongRow(song, onClick = { player.playQueue(songs, songs.indexOf(song), query) })
                }
                if (continuation != null) {
                    item {
                        LaunchedEffect(items.size) { if (!loadingMore) loadMore() }
                        TextButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Memuat…") }
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(170.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 170.dp),
            ) {
                items(items, key = { it.id }) { GridItemCard(it) }
                if (continuation != null) {
                    item {
                        LaunchedEffect(items.size) { if (!loadingMore) loadMore() }
                        Text("Memuat…", Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}
