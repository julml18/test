package com.redify.desktop

import androidx.compose.runtime.mutableStateListOf
import com.music.innertube.models.BrowseEndpoint

sealed class Screen {
    data object Home : Screen()
    data object Explore : Screen()
    data object Library : Screen()
    data object Settings : Screen()
    data object Import : Screen()
    data object SettingsHub : Screen()
    data class SettingsPage(val key: String) : Screen()
    data class LocalPlaylist(val id: Long) : Screen()
    data class Search(val query: String) : Screen()
    data class Album(val browseId: String) : Screen()
    data class Artist(val browseId: String) : Screen()
    data class Playlist(val playlistId: String) : Screen()
    data class ArtistItems(val title: String, val endpoint: BrowseEndpoint) : Screen()
    data class Browse(val title: String, val browseId: String, val params: String?) : Screen()
}

class Navigator(start: Screen = Screen.Home) {
    val stack = mutableStateListOf<Screen>(start)
    val current: Screen get() = stack.last()
    val canGoBack: Boolean get() = stack.size > 1

    fun push(screen: Screen) {
        if (stack.last() != screen) stack.add(screen)
    }

    fun replaceRoot(screen: Screen) {
        stack.clear()
        stack.add(screen)
    }

    fun back() {
        if (canGoBack) stack.removeAt(stack.lastIndex)
    }

    /** Open any YTItem-ish destination by its endpoint type. */
    fun openBrowse(endpoint: BrowseEndpoint, title: String) {
        when {
            endpoint.isArtistEndpoint -> push(Screen.Artist(endpoint.browseId))
            endpoint.isAlbumEndpoint -> push(Screen.Album(endpoint.browseId))
            endpoint.browseId.startsWith("VL") -> push(Screen.Playlist(endpoint.browseId.removePrefix("VL")))
            else -> push(Screen.Browse(title, endpoint.browseId, endpoint.params))
        }
    }
}
