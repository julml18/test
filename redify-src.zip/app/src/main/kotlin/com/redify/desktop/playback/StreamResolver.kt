package com.redify.desktop.playback

import com.music.innertube.YouTube
import com.music.innertube.models.YouTubeClient
import com.music.innertube.models.response.PlayerResponse
import com.music.innertube.NewPipeExtractor
import com.redify.desktop.data.Settings
import com.redify.desktop.log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Resolves a playable audio stream URL for a YouTube video id.
 *
 * Port of Musicfy's YTPlayerUtils: walks the same client list, deciphers signatureCipher /
 * n-param through NewPipeExtractor when a client only returns ciphered URLs, validates the URL
 * with a HEAD request, and remembers which clients failed for a video so a retry (after VLC
 * rejects a stream) tries something different.
 */
object StreamResolver {

    data class Stream(
        val url: String,
        val mimeType: String,
        val bitrate: Int,
        val client: YouTubeClient,
        val durationMs: Long?,
        val sampleRate: Int? = null,
        val loudnessDb: Double? = null,
    ) {
        val codec: String get() = when {
            "opus" in mimeType -> "OPUS"
            "mp4a" in mimeType -> "AAC"
            else -> mimeType.substringAfter("codecs=\"").substringBefore("\"").uppercase().ifBlank { "AUDIO" }
        }
    }

    // Logged in: same order as Musicfy (MAIN_CLIENT = VISIONOS, then STREAM_FALLBACK_CLIENTS).
    // Guest: clients that YouTube serves without a sign-in / "confirm you're not a bot" check
    // first (Android VR, iOS, TV embedded), so most songs play without an account.
    private val clients: List<YouTubeClient>
        get() = if (Settings.current.isLoggedIn) listOf(
            YouTubeClient.VISIONOS,
            YouTubeClient.IPADOS,
            YouTubeClient.IOS,
            YouTubeClient.ANDROID_VR_1_43_32,
            YouTubeClient.ANDROID_VR_1_61_48,
            YouTubeClient.ANDROID_VR_1_65_10,
            YouTubeClient.ANDROID_VR_NO_AUTH,
            YouTubeClient.TVHTML5_SIMPLY_EMBEDDED_PLAYER,
            YouTubeClient.WEB_REMIX,
            YouTubeClient.WEB,
            YouTubeClient.MOBILE,
            YouTubeClient.ANDROID_NO_SDK,
            YouTubeClient.ANDROID_CREATOR,
            YouTubeClient.WEB_CREATOR,
            YouTubeClient.TVHTML5,
        ) else listOf(
            YouTubeClient.ANDROID_VR_NO_AUTH,
            YouTubeClient.ANDROID_VR_1_43_32,
            YouTubeClient.ANDROID_VR_1_61_48,
            YouTubeClient.ANDROID_VR_1_65_10,
            YouTubeClient.IOS,
            YouTubeClient.VISIONOS,
            YouTubeClient.IPADOS,
            YouTubeClient.TVHTML5_SIMPLY_EMBEDDED_PLAYER,
            YouTubeClient.WEB_REMIX,
            YouTubeClient.WEB,
            YouTubeClient.MOBILE,
            YouTubeClient.ANDROID_NO_SDK,
        )

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val cache = HashMap<String, Pair<Stream, Long>>()
    /** Clients that produced a stream VLC could not play, per video. */
    private val failedClients = HashMap<String, MutableSet<String>>()

    /** Call when VLC reported an error for [videoId]: the cached stream is dropped and its client blacklisted. */
    fun markFailed(videoId: String) {
        val stream = cache.remove(videoId)?.first ?: return
        failedClients.getOrPut(videoId) { mutableSetOf() }.add(stream.client.clientName + stream.client.clientVersion)
        log("stream marked failed: $videoId via ${stream.client.clientName}")
    }

    suspend fun resolve(videoId: String): Result<Stream> = withContext(Dispatchers.IO) {
        runCatching {
            cache[videoId]?.let { (stream, expiresAt) ->
                if (System.currentTimeMillis() < expiresAt) return@runCatching stream
            }
            val skip = failedClients[videoId].orEmpty()
            var lastReason: String? = null
            var sigTimestamp: Int? = null
            var refreshedVisitor = false

            for (client in clients) {
                if (client.clientName + client.clientVersion in skip) continue
                if (client.useSignatureTimestamp && sigTimestamp == null) {
                    sigTimestamp = runCatching { NewPipeExtractor.getSignatureTimestamp(videoId).getOrNull() }.getOrNull()
                }
                val response = YouTube.player(videoId, client = client, signatureTimestamp = sigTimestamp).getOrElse { e ->
                    log("player() ${client.clientName} failed: ${e.message}"); null
                } ?: continue
                if (response.playabilityStatus.status != "OK") {
                    lastReason = response.playabilityStatus.reason ?: response.playabilityStatus.status
                    log("player() ${client.clientName}: ${response.playabilityStatus.status} ${lastReason ?: ""}")
                    // "Sign in to confirm you're not a bot": YouTube has flagged this guest session.
                    // A fresh visitorData usually clears it; do that once per resolve.
                    if (!refreshedVisitor && !Settings.current.isLoggedIn && looksLikeBotCheck(response.playabilityStatus.status, lastReason)) {
                        refreshedVisitor = true
                        YouTube.refreshVisitorData().onSuccess { v -> Settings.update { it.copy(visitorData = v) }; log("visitorData refreshed") }
                    }
                    continue
                }
                val stream = pickStream(response, client, videoId) ?: continue
                if (validate(stream.url, client)) {
                    log("stream ok: $videoId via ${client.clientName} (${stream.codec} ${stream.bitrate / 1000}k)")
                    cacheStream(videoId, stream, response)
                    return@runCatching stream
                } else {
                    log("stream rejected by HEAD: $videoId via ${client.clientName}")
                }
            }

            // Last resort: let NewPipeExtractor fetch everything itself.
            val np = NewPipeExtractor.newPipePlayer(videoId)
            val audio = np.filter { it.first in 139..141 || it.first in 249..251 }.sortedByDescending { it.first }
            val url = audio.firstOrNull()?.second
            if (url != null && validate(url, YouTubeClient.WEB)) {
                val stream = Stream(url, if (audio.first().first >= 249) "audio/webm; codecs=\"opus\"" else "audio/mp4; codecs=\"mp4a.40.2\"", 0, YouTubeClient.WEB, null)
                cache[videoId] = stream to (System.currentTimeMillis() + 3_000_000)
                log("stream ok: $videoId via NewPipe itag ${audio.first().first}")
                return@runCatching stream
            }
            val hint = if (lastReason != null && looksLikeBotCheck(null, lastReason) && !Settings.current.isLoggedIn)
                " — YouTube membatasi jaringan ini; coba lagi sebentar, atau login di Profil"
            else lastReason?.let { " ($it)" } ?: ""
            error("Lagu tidak bisa diputar$hint")
        }
    }

    private fun looksLikeBotCheck(status: String?, reason: String?): Boolean {
        val r = (reason ?: "").lowercase()
        return status == "LOGIN_REQUIRED" || "sign in" in r || "bot" in r || "masuk" in r
    }

    private fun cacheStream(videoId: String, stream: Stream, response: PlayerResponse) {
        val ttl = (response.streamingData?.expiresInSeconds ?: 3600).coerceAtMost(3600) * 1000L
        cache[videoId] = stream to (System.currentTimeMillis() + ttl - 60_000)
    }

    private fun pickStream(response: PlayerResponse, client: YouTubeClient, videoId: String): Stream? {
        val formats = response.streamingData?.adaptiveFormats.orEmpty()
            .filter { it.isAudio && it.isOriginal && (it.url != null || it.signatureCipher != null) }
        if (formats.isEmpty()) return null

        val best = when (Settings.current.audioQuality) {
            "LOW" -> formats.minByOrNull { it.bitrate }
            "MEDIUM" -> formats.minByOrNull { kotlin.math.abs(it.bitrate - 128_000) }
            else -> formats.maxWithOrNull(compareBy<PlayerResponse.StreamingData.Format> { it.bitrate }.thenBy { codecRank(it.mimeType) })
        } ?: return null

        // Direct URL for app clients; web clients return ciphered URLs that NewPipe deciphers (sig + n-param).
        val direct = best.url
        val url = direct?.takeIf { !client.useSignatureTimestamp }
            ?: runCatching { NewPipeExtractor.getStreamUrl(best, videoId) }.getOrNull()
            ?: direct
        if (url == null) return null

        return Stream(
            url = url,
            mimeType = best.mimeType,
            bitrate = best.bitrate,
            client = client,
            durationMs = best.approxDurationMs?.toLongOrNull(),
            sampleRate = best.audioSampleRate,
            loudnessDb = best.loudnessDb ?: response.playerConfig?.audioConfig?.loudnessDb,
        )
    }

    private fun codecRank(mimeType: String): Int = when {
        "mp4a" in mimeType -> 3
        "opus" in mimeType -> 2
        else -> 1
    }

    private fun validate(url: String, client: YouTubeClient): Boolean = runCatching {
        val request = Request.Builder()
            .url(url)
            .head()
            .header("User-Agent", client.userAgent)
            .build()
        http.newCall(request).execute().use { it.code in 200..299 }
    }.getOrDefault(false)

    fun userAgentFor(stream: Stream): String = stream.client.userAgent
}
