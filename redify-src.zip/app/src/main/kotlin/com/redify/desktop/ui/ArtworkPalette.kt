package com.redify.desktop.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.awt.image.BufferedImage
import javax.imageio.ImageIO
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Port of Musicfy's ArtworkPalette: one hue from the cover art, moved through
 * different lightness values so the whole player reads as a set.
 */
data class ArtworkPalette(
    val accent: Color,
    val onAccent: Color,
    val container: Color,
    val onContainer: Color,
    val surface: Color,
) {
    companion object {
        val Neutral = ArtworkPalette(
            accent = Color.White,
            onAccent = Color.Black,
            container = Color.White.copy(alpha = 0.15f),
            onContainer = Color.White,
            surface = Color(0xFF121212),
        )

        fun from(seed: Color): ArtworkPalette {
            val (h, s, _) = seed.toHsl()
            val saturation = s.coerceIn(0.25f, 0.85f)
            val accent = hslColor(h, saturation, 0.72f)
            val container = hslColor(h, saturation * 0.55f, 0.26f)
            val surface = hslColor(h, saturation * 0.35f, 0.11f)
            return ArtworkPalette(
                accent = accent,
                onAccent = contrastingOn(accent),
                container = container,
                onContainer = contrastingOn(container),
                surface = surface,
            )
        }

        private fun contrastingOn(background: Color): Color {
            val l = background.luminance()
            val onWhite = 1.05 / (l + 0.05)
            val onBlack = (l + 0.05) / 0.05
            return if (onWhite >= onBlack) Color.White else Color.Black
        }
    }
}

fun Color.toHsl(): Triple<Float, Float, Float> {
    val r = red; val g = green; val b = blue
    val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
    val l = (mx + mn) / 2f
    if (mx == mn) return Triple(0f, 0f, l)
    val d = mx - mn
    val s = if (l > 0.5f) d / (2f - mx - mn) else d / (mx + mn)
    val h = when (mx) {
        r -> ((g - b) / d + (if (g < b) 6f else 0f)) * 60f
        g -> ((b - r) / d + 2f) * 60f
        else -> ((r - g) / d + 4f) * 60f
    }
    return Triple(h, s, l)
}

fun hslColor(hue: Float, saturation: Float, lightness: Float): Color {
    val s = saturation.coerceIn(0f, 1f); val l = lightness.coerceIn(0f, 1f)
    val c = (1f - abs(2f * l - 1f)) * s
    val hp = ((hue % 360f) + 360f) % 360f / 60f
    val x = c * (1f - abs(hp % 2f - 1f))
    val (r1, g1, b1) = when {
        hp < 1 -> Triple(c, x, 0f); hp < 2 -> Triple(x, c, 0f); hp < 3 -> Triple(0f, c, x)
        hp < 4 -> Triple(0f, x, c); hp < 5 -> Triple(x, 0f, c); else -> Triple(c, 0f, x)
    }
    val m = l - c / 2f
    return Color(r1 + m, g1 + m, b1 + m)
}

/** Picks a "vibrant" seed colour from an image: the most common saturated, mid-lightness bucket. */
object ArtworkColorExtractor {
    private val http = OkHttpClient()
    private val cache = HashMap<String, Color?>()

    suspend fun seedFor(url: String?): Color? {
        if (url == null) return null
        cache[url]?.let { return it }
        if (url in cache) return null
        val color = withContext(Dispatchers.IO) {
            runCatching {
                val bytes = http.newCall(Request.Builder().url(if ("ytimg.com" in url) url else url.hiRes(128)).build()).execute().use { it.body?.bytes() }
                    ?: return@runCatching null
                val img = ImageIO.read(bytes.inputStream()) ?: return@runCatching null
                extract(img)
            }.getOrNull()
        }
        cache[url] = color
        return color
    }

    private fun extract(img: BufferedImage): Color? {
        val buckets = HashMap<Int, IntArray>() // key -> [count, rSum, gSum, bSum]
        val step = max(1, img.width / 64)
        var y = 0
        while (y < img.height) {
            var x = 0
            while (x < img.width) {
                val rgb = img.getRGB(x, y)
                val r = (rgb shr 16) and 0xFF; val g = (rgb shr 8) and 0xFF; val b = rgb and 0xFF
                val c = Color(r, g, b)
                val (_, s, l) = c.toHsl()
                if (s > 0.2f && l in 0.15f..0.85f) {
                    val key = (r shr 5 shl 6) or (g shr 5 shl 3) or (b shr 5)
                    val acc = buckets.getOrPut(key) { IntArray(4) }
                    acc[0]++; acc[1] += r; acc[2] += g; acc[3] += b
                }
                x += step
            }
            y += step
        }
        val best = buckets.values.maxByOrNull { it[0] } ?: return null
        return Color(best[1] / best[0], best[2] / best[0], best[3] / best[0])
    }
}

@Composable
fun rememberArtworkPalette(thumbnail: String?, enabled: Boolean): ArtworkPalette? {
    var palette by remember { mutableStateOf<ArtworkPalette?>(null) }
    LaunchedEffect(thumbnail, enabled) {
        palette = if (!enabled) null else ArtworkColorExtractor.seedFor(thumbnail)?.let(ArtworkPalette::from)
    }
    return palette
}
