package com.redify.desktop.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.music.innertube.models.SongItem
import com.redify.desktop.data.Library
import com.redify.desktop.ui.Artwork

@Composable
fun AddToPlaylistDialog(song: SongItem, onDismiss: () -> Unit) {
    val playlists by Library.playlists.collectAsState()
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        NewPlaylistDialog(onDismiss = { creating = false }) { name ->
            Library.createPlaylist(name, firstSong = song)
            creating = false
            onDismiss()
        }
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah ke playlist") },
        text = {
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                Row(
                    Modifier.fillMaxWidth().clickable { creating = true }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.Add, null, Modifier.size(40.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Playlist baru", fontWeight = FontWeight.SemiBold)
                }
                playlists.forEach { pl ->
                    Row(
                        Modifier.fillMaxWidth().clickable { Library.addToPlaylist(pl.id, song); onDismiss() }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Artwork(pl.thumbnail, Modifier.size(40.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(pl.name)
                            Text("${pl.songCount} lagu", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}
