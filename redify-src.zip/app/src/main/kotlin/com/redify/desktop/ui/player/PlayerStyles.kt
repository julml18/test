package com.redify.desktop.ui.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redify.desktop.LocalPlayer
import com.redify.desktop.data.Library
import com.redify.desktop.data.Lyrics
import com.redify.desktop.data.LyricsProvider
import com.redify.desktop.data.Settings
import com.redify.desktop.ui.Artwork
import com.redify.desktop.ui.ArtworkImage
import com.redify.desktop.ui.formatMillis
import com.redify.desktop.ui.rememberArtworkPalette

/** Musicfy's "Styles": the five looks of the expanded player. */
enum class PlayerStyle(val key: String, val title: String) {
    DEFAULT("DEFAULT", "Default"),
    TURNTABLE("TURNTABLE", "Turntable"),
    POSTER("POSTER", "Poster"),
    TIMELINE("TIMELINE", "Timeline"),
    LYRICS_STAGE("LYRICS_STAGE", "Lyrics stage");

    companion object {
        fun of(key: String) = entries.firstOrNull { it.key == key } ?: TURNTABLE
        fun label(key: String) = of(key).title
    }
}

/** Renders the chosen non-turntable style (the turntable has its own view in PlayerScreen). */
@Composable
internal fun StyledPlayerView(styleKey: String, onShowQueue: () -> Unit, onMenu: () -> Unit, onLyrics: () -> Unit, lyrics: Lyrics?) {
    when (PlayerStyle.of(styleKey)) {
        PlayerStyle.DEFAULT -> DefaultStyle(onShowQueue, onMenu, onLyrics, lyrics)
        PlayerStyle.POSTER -> PosterStyle(onMenu, onLyrics, lyrics)
        PlayerStyle.TIMELINE -> TimelineStyle(onMenu, onLyrics, lyrics, showLyric = false)
        PlayerStyle.LYRICS_STAGE -> TimelineStyle(onMenu, onLyrics, lyrics, showLyric = true)
        PlayerStyle.TURNTABLE -> VinylView(onShowQueue, onMenu, onLyrics, lyrics)
    }
}

/** Centers a phone-like column on a wide window. */
@Composable
private fun Phone(maxW: androidx.compose.ui.unit.Dp = 520.dp, content: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        Box(Modifier.width(minOf(maxWidth, maxW)).fillMaxHeight().align(Alignment.Center)) { content() }
    }
}

// ---- Default: big square artwork, title row, progress, transport -------------------------

@Composable
private fun DefaultStyle(onShowQueue: () -> Unit, onMenu: () -> Unit, onLyrics: () -> Unit, lyrics: Lyrics?) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    val likedIds by Library.likedIds.collectAsState()
    val liked = song != null && song.id in likedIds
    val settings by Settings.state.collectAsState()

    Phone {
        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
            Spacer(Modifier.height(56.dp))
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Artwork(song?.thumbnail, Modifier.fillMaxHeight().aspectRatio(1f), RoundedCornerShape(28.dp))
            }
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(song?.title ?: "", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                        if (settings.showFormatBadge && state.streamCodec != null) { Spacer(Modifier.width(10.dp)); CodecChip(state.streamCodec!!) }
                    }
                    Text(song?.artists?.joinToString { it.name } ?: "", color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                RoundButton(size = 48.dp, onClick = { song?.let(Library::toggleLike) }) { Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Color.White) }
                Spacer(Modifier.width(10.dp))
                RoundButton(size = 48.dp, onClick = onShowQueue) { Icon(Icons.Default.ExpandMore, null, tint = Color.White) }
                Spacer(Modifier.width(10.dp))
                RoundButton(size = 48.dp, onClick = onMenu) { Icon(Icons.Default.MoreHoriz, null, tint = Color.White) }
            }
            Spacer(Modifier.height(16.dp))
            TransportControls()
            LyricPill(lyrics, onClick = onLyrics)
        }
    }
}

// ---- Poster: full-bleed artwork with the current lyric on top ------------------------------

@Composable
private fun PosterStyle(onMenu: () -> Unit, onLyrics: () -> Unit, lyrics: Lyrics?) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    val position = rememberLivePosition()
    val idx = lyrics?.indexAt(position) ?: -1
    val line = lyrics?.lines?.getOrNull(idx)
    val palette = rememberArtworkPalette(song?.thumbnail, enabled = true)
    val tint = palette?.accent ?: Color(0xFF6A1F2A)

    Phone(maxW = 560.dp) {
        Box(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 48.dp).clip(RoundedCornerShape(36.dp)).background(tint.copy(alpha = 0.85f))) {
            // Artwork on the upper part, fading into the tinted lower half.
            if (song?.thumbnail != null) {
                ArtworkImage(song.thumbnail, Modifier.fillMaxWidth().fillMaxHeight(0.62f), size = 1024)
            }
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.62f).background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to tint.copy(alpha = 0.85f))))

            Box(Modifier.align(Alignment.TopEnd).padding(16.dp)) {
                RoundButton(size = 40.dp, onClick = onMenu) { Icon(Icons.Default.MoreHoriz, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
            }

            // Current lyric, karaoke-highlighted
            Box(Modifier.fillMaxWidth().fillMaxHeight(0.80f).padding(horizontal = 28.dp), contentAlignment = Alignment.BottomStart) {
                Text(
                    when { lyrics == null -> AnnotatedString(""); line == null -> AnnotatedString("♪"); else -> karaoke(line.text, lyrics, idx, position) },
                    color = Color.White, fontSize = 34.sp, lineHeight = 42.sp, fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clickable(onClick = onLyrics).padding(bottom = 40.dp),
                )
            }

            // Bottom: artist + title left, small transport right
            Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text(song?.artists?.joinToString { it.name } ?: "", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, maxLines = 1)
                    Text(song?.title ?: "", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    RoundButton(size = 36.dp, onClick = player::previous) { Icon(Icons.Default.FastRewind, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    RoundButton(size = 36.dp, onClick = player::togglePlayPause) { Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    RoundButton(size = 36.dp, onClick = player::next) { Icon(Icons.Default.FastForward, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                }
            }
        }
    }
}

// ---- Timeline / Lyrics stage: tinted card, elapsed time fills from the top -----------------

@Composable
private fun TimelineStyle(onMenu: () -> Unit, onLyrics: () -> Unit, lyrics: Lyrics?, showLyric: Boolean) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    val position = rememberLivePosition()
    val idx = lyrics?.indexAt(position) ?: -1
    val line = lyrics?.lines?.getOrNull(idx)
    val palette = rememberArtworkPalette(song?.thumbnail, enabled = true)
    val tint = palette?.accent ?: Color(0xFF8A5A66)
    val fraction = if (state.durationMs > 0) (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
    val fill by animateFloatAsState(fraction, tween(600), label = "fill")

    Phone(maxW = 560.dp) {
        Box(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 48.dp).clip(RoundedCornerShape(36.dp)).background(tint.copy(alpha = 0.35f))) {
            // Elapsed part of the song, as a lighter block growing downwards.
            Box(Modifier.fillMaxWidth().fillMaxHeight(fill.coerceAtLeast(0.001f)).background(tint.copy(alpha = 0.55f)))

            Box(Modifier.align(Alignment.TopEnd).padding(16.dp)) {
                RoundButton(size = 40.dp, onClick = onMenu) { Icon(Icons.Default.MoreHoriz, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
            }

            Column(Modifier.fillMaxSize().padding(28.dp)) {
                if (showLyric) {
                    Text(
                        when { lyrics == null -> AnnotatedString("Lirik tidak tersedia"); line == null -> AnnotatedString("♪"); else -> karaoke(line.text, lyrics, idx, position) },
                        color = Color.White, fontSize = 30.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(end = 48.dp).clickable(onClick = onLyrics),
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 48.dp)) {
                        Artwork(song?.thumbnail, Modifier.size(48.dp), RoundedCornerShape(10.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(song?.title ?: "", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song?.artists?.joinToString { it.name } ?: "", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 1)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text(formatMillis(position.coerceAtMost(state.durationMs.coerceAtLeast(0))), color = Color.White, fontSize = 64.sp, lineHeight = 68.sp, fontWeight = FontWeight.Bold)
                Text(formatMillis(state.durationMs), color = Color.White.copy(alpha = 0.75f), fontSize = 64.sp, lineHeight = 68.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    RoundButton(size = 36.dp, onClick = player::previous) { Icon(Icons.Default.FastRewind, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(8.dp))
                    RoundButton(size = 36.dp, onClick = player::togglePlayPause) { Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(8.dp))
                    RoundButton(size = 36.dp, onClick = player::next) { Icon(Icons.Default.FastForward, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                }
            }
        }
    }
}

// ---- Styles picker screen ---------------------------------------------------------------------

@Composable
fun StylesScreen() {
    val settings by Settings.state.collectAsState()
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val song = state.current
    var lyrics by remember { mutableStateOf<Lyrics?>(null) }
    LaunchedEffect(song?.id) { lyrics = song?.let { runCatching { LyricsProvider.forSong(it) }.getOrNull() } }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(56.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Styles", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(PlayerStyle.label(settings.playerStyle), color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
        }
        Spacer(Modifier.height(16.dp))
        if (song == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Putar sebuah lagu dulu untuk melihat pratinjau gaya player.", color = Color.White.copy(alpha = 0.7f))
            }
            return
        }
        LazyRow(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 40.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(28.dp),
        ) {
            items(PlayerStyle.entries) { style ->
                val selected = settings.playerStyle == style.key
                Column(Modifier.width(360.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.weight(1f).fillMaxWidth()
                            .clip(RoundedCornerShape(40.dp))
                            .background(Color(0xFF0E0E10))
                            .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.White.copy(alpha = 0.12f), RoundedCornerShape(40.dp)),
                    ) {
                        if (song.thumbnail.isNotBlank()) {
                            ArtworkImage(song.thumbnail, Modifier.fillMaxSize().blur(60.dp).alpha(0.5f), size = 256)
                        }
                        StyledPlayerView(style.key, onShowQueue = {}, onMenu = {}, onLyrics = {}, lyrics = lyrics)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(style.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier.fillMaxWidth().clip(CircleShape).background(if (selected) Color.White else Color.White.copy(alpha = 0.12f))
                            .clickable { Settings.update { it.copy(playerStyle = style.key) } }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text(if (selected) "Dipakai" else "Set", color = if (selected) Color.Black else Color.White, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
