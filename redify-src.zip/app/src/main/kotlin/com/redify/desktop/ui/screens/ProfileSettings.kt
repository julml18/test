package com.redify.desktop.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.redify.desktop.LocalNavigator
import com.redify.desktop.LocalPlayer
import com.redify.desktop.Screen
import com.redify.desktop.data.AppSettings
import com.redify.desktop.data.Downloads
import com.redify.desktop.data.Settings
import com.redify.desktop.openUrl
import com.redify.desktop.ui.Artwork
import java.text.SimpleDateFormat
import java.util.Date

const val APP_VERSION = "2.3.3"
private val Card = Color(0xFF151517)
private val CardInner = Color(0xFF1E1E21)

// ---- Profile (4th tab) ----------------------------------------------------------------

@Composable
fun ProfileScreen() {
    val nav = LocalNavigator.current
    val s by Settings.state.collectAsState()
    val name = s.accountName?.takeIf { it.isNotBlank() } ?: s.profileName.ifBlank { "Listener" }
    var editing by remember { mutableStateOf(s.profileName.isBlank()) }
    val scroll = rememberScrollState()

    Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
        // Header card
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)).background(Color(0xFF111113)).padding(24.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                        Text("R", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(14.dp))
                    Text("Hello again, $name!", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(20.dp))
                // ID card
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF2A2A2D)).clickable { editing = !editing }.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("PROFILE USR#${"%010d".format(kotlin.math.abs(name.hashCode()) % 10_000_000_000L)}", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (s.accountThumbnail != null) Artwork(s.accountThumbnail, Modifier.size(84.dp), CircleShape)
                            else Box(Modifier.size(84.dp).clip(CircleShape).background(Color(0xFF4A4A4E)))
                            Spacer(Modifier.width(20.dp))
                            Column {
                                Text("ID CARD OF", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                Text(name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                Text("joined at ${SimpleDateFormat("dd MMM yyyy").format(Date(s.joinedAt))}", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                            }
                        }
                    }
                    Text("${name}'s CARD", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(start = 12.dp).rotate(90f))
                }
                if (editing) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = s.profileName, onValueChange = { v -> Settings.update { it.copy(profileName = v) } },
                        singleLine = true, label = { Text("Nama tampilan") }, modifier = Modifier.fillMaxWidth(),
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("click the card to rename", color = Color.White.copy(alpha = 0.4f), fontSize = 13.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }

        Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Listening time
            val h = s.listeningSeconds / 3600; val m = (s.listeningSeconds % 3600) / 60
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(24.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$h", fontSize = 72.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("h", fontSize = 22.sp, color = Color.White, modifier = Modifier.padding(bottom = 10.dp))
                    Spacer(Modifier.width(18.dp))
                    Box(Modifier.width(1.dp).height(56.dp).background(Color.White.copy(alpha = 0.2f)))
                    Spacer(Modifier.width(18.dp))
                    Text("$m", fontSize = 72.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("m", fontSize = 22.sp, color = Color.White, modifier = Modifier.padding(bottom = 10.dp))
                    Spacer(Modifier.weight(1f))
                    Text("Total Listening\ntime", color = Color.White.copy(alpha = 0.55f), fontSize = 15.sp, fontFamily = FontFamily.Monospace, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                }
                Spacer(Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
                Spacer(Modifier.height(12.dp))
                Text("View Stats  >", color = Color.White.copy(alpha = 0.6f), fontSize = 15.sp, modifier = Modifier.clickable { nav.replaceRoot(Screen.Library) })
            }
            // Version
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Version", color = Color.White.copy(alpha = 0.55f), fontSize = 15.sp)
                    Text(APP_VERSION, fontSize = 72.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
                Text(
                    "Star the repo!", color = Color.Black, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(CircleShape).background(Color.White).clickable { openUrl("https://github.com/realidkroo/musicfy") }.padding(horizontal = 22.dp, vertical = 12.dp),
                )
            }
            Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            Tile(Icons.Default.Settings, "Open settings") { nav.push(Screen.SettingsHub) }
            Spacer(Modifier.height(150.dp))
        }
    }
}

// ---- Settings hub ---------------------------------------------------------------------------

@Composable
fun SettingsHubScreen() {
    val nav = LocalNavigator.current
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 16.dp)) {
        Spacer(Modifier.height(40.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search any settings") }, shape = CircleShape,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(20.dp))
        val all = listOf(
            Triple(Icons.Default.Settings, "General", "general"),
            Triple(Icons.Default.Contrast, "Appearance", "appearance"),
            Triple(Icons.Default.PlayArrow, "Playback", "playback"),
            Triple(Icons.Default.GraphicEq, "Audio", "audio"),
            Triple(Icons.Default.Equalizer, "Audio Lab", "audiolab"),
            Triple(Icons.Default.Extension, "Modules", "modules"),
        )
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(20.dp)) {
                Text("Reccomended item", color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.clickable { nav.push(Screen.SettingsPage("audiolab")) }, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).clip(CircleShape).background(CardInner), contentAlignment = Alignment.Center) { Icon(Icons.Default.Equalizer, null, tint = Color.White) }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Configure Crossfade settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("settings>audio lab", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
                    }
                }
            }
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            all.filter { query.isBlank() || it.second.contains(query, true) }.forEach { (icon, label, key) ->
                Tile(icon, label) { nav.push(Screen.SettingsPage(key)) }
            }
        }
        Spacer(Modifier.height(170.dp))
    }
}

@Composable
fun SettingsPageScreen(key: String) {
    val s by Settings.state.collectAsState()
    val player = LocalPlayer.current
    val nav = LocalNavigator.current
    val title = when (key) { "general" -> "General"; "appearance" -> "Appearance"; "playback" -> "Playback"; "audio" -> "Audio"; "audiolab" -> "Audio Lab"; else -> "Modules" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(64.dp))
        Text(title, fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(20.dp))
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (key) {
                "general" -> {
                    Text("Generally app settings", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Group {
                        Toggle(Icons.Default.Settings, "Offline mode", "play downloaded music only", s.offlineMode) { v -> Settings.update { it.copy(offlineMode = v) }; Settings.applyToYouTube() }
                        Toggle(Icons.Default.PlayArrow, "Don't skip on failure", "Stay on a failed stream instead of skipping", s.dontSkipOnFailure) { v -> Settings.update { it.copy(dontSkipOnFailure = v) } }
                    }
                    SliderCard("Skip timeout", "${s.skipTimeoutSec}s", s.skipTimeoutSec.toFloat(), 1f..30f) { v -> Settings.update { it.copy(skipTimeoutSec = v.toInt()) } }
                }
                "appearance" -> {
                    Text("Player appearance", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp)
                    Tile(Icons.Default.Contrast, "Styles · ${com.redify.desktop.ui.player.PlayerStyle.label(s.playerStyle)}") { nav.push(Screen.SettingsPage("styles")) }
                    Group {
                        Toggle(Icons.Default.GraphicEq, "Audio format badge", "What the song is playing as, beside its title", s.showFormatBadge) { v -> Settings.update { it.copy(showFormatBadge = v) } }
                        Toggle(Icons.Default.GraphicEq, "Show sample rate", "The stream's sample rate after its format", s.showSampleRate) { v -> Settings.update { it.copy(showSampleRate = v) } }
                        Toggle(Icons.Default.Contrast, "Warna dari sampul album", "Palet aplikasi mengikuti sampul lagu", s.artworkTheme) { v -> Settings.update { it.copy(artworkTheme = v) } }
                    }
                    Text("Global Appearance", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Group {
                        Toggle(Icons.Default.Contrast, "Blur", "Glass blur across player background", s.blurEnabled) { v -> Settings.update { it.copy(blurEnabled = v) } }
                        SliderRow("Blur strength", "${s.blurStrength}px", s.blurStrength.toFloat(), 10f..120f) { v -> Settings.update { it.copy(blurStrength = v.toInt()) } }
                        Toggle(Icons.Default.Contrast, "Animation", "Smooth UI transitions", s.animations) { v -> Settings.update { it.copy(animations = v) } }
                        Toggle(Icons.Default.Contrast, "Tema gelap", "Matikan untuk tema terang", s.darkTheme) { v -> Settings.update { it.copy(darkTheme = v) } }
                    }
                }
                "playback" -> Group {
                    Toggle(Icons.Default.PlayArrow, "Save Player's last state", "Antrean & posisi dipulihkan saat dibuka lagi", s.saveLastState) { v -> Settings.update { it.copy(saveLastState = v) }; if (!v) player.clearLastState() }
                    Toggle(Icons.Default.PlayArrow, "Resume on launch", "Langsung putar lagu terakhir saat aplikasi dibuka", s.resumeOnLaunch) { v -> Settings.update { it.copy(resumeOnLaunch = v) } }
                }
                "audio" -> {
                    Group {
                        Toggle(Icons.Default.GraphicEq, "Audio Normalization", "Balance loudness across all tracks", s.normalization) { v -> Settings.update { it.copy(normalization = v) }; player.refreshVolume() }
                    }
                    Text("AUDIO QUALITY", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, letterSpacing = 2.sp)
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "AUTO" to ("Auto" to "High quality (desktop is always on a good connection)"),
                            "HIGH" to ("High" to "The best the streamer has: less compression, more data"),
                            "MEDIUM" to ("Medium" to "Around 128 kbps, easy on data"),
                            "LOW" to ("Low" to "The smallest streams, for slow connections"),
                        ).forEach { (k, v) -> Choice(v.first, v.second, s.audioQuality == k) { Settings.update { it.copy(audioQuality = k) } } }
                        Text("Berlaku untuk lagu berikutnya yang diputar.", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                    }
                }
                "audiolab" -> {
                    EqualizerCard()
                    Group {
                        Toggle(Icons.Default.GraphicEq, "Crossfade", "Lagu berikutnya masuk memudar saat lagu ini hampir selesai", s.crossfadeEnabled) { v -> Settings.update { it.copy(crossfadeEnabled = v) } }
                        SliderRow("Crossfade duration", "${s.crossfadeSec}s", s.crossfadeSec.toFloat(), 2f..12f) { v -> Settings.update { it.copy(crossfadeSec = v.toInt()) } }
                    }
                }
                else -> {
                    Text("Account & data", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    AccountCard()
                    Tile(Icons.Default.Extension, "Impor playlist (Spotify, Apple Music, Deezer, YouTube, CSV)") { nav.push(Screen.Import) }
                    val downloads by Downloads.entries.collectAsState()
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(20.dp)) {
                        Text("Unduhan offline", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Text("${downloads.size} lagu • ${"%.1f".format(Downloads.totalBytes() / 1024f / 1024f)} MB", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(170.dp))
    }
}

// ---- Building blocks ------------------------------------------------------------------------

@Composable
private fun Group(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(vertical = 6.dp)) { content() }
}

@Composable
private fun Toggle(icon: ImageVector, title: String, subtitle: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(CardInner), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (enabled) Color.White else Color.White.copy(alpha = 0.5f), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun SliderRow(title: String, value: String, current: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
        Row { Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(value, color = Color.White.copy(alpha = 0.6f)) }
        Slider(value = current, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun SliderCard(title: String, value: String, current: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).padding(20.dp)) {
        Row { Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Text(value, color = Color.White.copy(alpha = 0.6f)) }
        Slider(value = current, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun Choice(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (selected) Color(0xFF2A2A2D) else CardInner)
            .border(1.dp, if (selected) Color.White.copy(alpha = 0.5f) else Color.Transparent, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp)
        }
        if (selected) Icon(Icons.Default.Check, null, tint = Color.White)
    }
}

@Composable
private fun Tile(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(CardInner), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White) }
        Spacer(Modifier.width(18.dp))
        Text(label, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Suppress("unused")
private fun AppSettings.unused() = Unit
