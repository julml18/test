package com.redify.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.redify.desktop.LocalNavigator
import com.redify.desktop.LocalPlayer
import com.redify.desktop.Screen
import com.redify.desktop.data.Library
import com.redify.desktop.playback.RepeatMode

@Composable
fun PlayerBar(
    queueOpen: Boolean,
    onToggleQueue: () -> Unit,
    lyricsOpen: Boolean,
    onToggleLyrics: () -> Unit,
    fullScreen: Boolean = false,
    onToggleFullScreen: () -> Unit = {},
) {
    val player = LocalPlayer.current
    val nav = LocalNavigator.current
    val state by player.state.collectAsState()
    val song = state.current
    val likedIds by Library.likedIds.collectAsState()
    val liked = song != null && song.id in likedIds

    var dragging by remember { mutableStateOf(false) }
    var dragPosition by remember { mutableStateOf(0f) }

    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(
            Modifier.fillMaxWidth().height(88.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Now playing
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Artwork(song?.thumbnail, Modifier.size(56.dp).clickable(enabled = song != null, onClick = onToggleFullScreen))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        song?.title ?: "Tidak ada yang diputar",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val artist = song?.artists?.firstOrNull()
                    Text(
                        song?.artists?.joinToString { it.name } ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable(enabled = artist?.id != null) {
                            artist?.id?.let { nav.push(Screen.Artist(it)) }
                        },
                    )
                    state.error?.let {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error, maxLines = 1)
                    }
                }
                IconButton(onClick = { song?.let(Library::toggleLike) }, enabled = song != null) {
                    Icon(
                        if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Sukai",
                        tint = if (liked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Transport
            Column(Modifier.weight(1.4f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = player::toggleShuffle) {
                        Icon(
                            Icons.Default.Shuffle, "Acak",
                            tint = if (state.shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = player::previous, enabled = song != null) { Icon(Icons.Default.SkipPrevious, "Sebelumnya") }
                    FilledIconButton(onClick = player::togglePlayPause, enabled = song != null, modifier = Modifier.size(48.dp)) {
                        if (state.isBuffering) {
                            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        } else {
                            Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Putar/Jeda")
                        }
                    }
                    IconButton(onClick = player::next, enabled = song != null) { Icon(Icons.Default.SkipNext, "Berikutnya") }
                    IconButton(onClick = player::cycleRepeat) {
                        Icon(
                            if (state.repeat == RepeatMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                            "Ulangi",
                            tint = if (state.repeat != RepeatMode.OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(formatMillis(if (dragging) dragPosition.toLong() else state.positionMs), style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.width(8.dp))
                    val duration = state.durationMs.coerceAtLeast(1L).toFloat()
                    Slider(
                        value = if (dragging) dragPosition else state.positionMs.toFloat().coerceIn(0f, duration),
                        onValueChange = { dragging = true; dragPosition = it },
                        onValueChangeFinished = {
                            player.seekTo(dragPosition.toLong())
                            dragging = false
                        },
                        valueRange = 0f..duration,
                        enabled = song != null,
                        modifier = Modifier.weight(1f).height(24.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(formatMillis(state.durationMs), style = MaterialTheme.typography.labelSmall)
                }
            }

            // Volume + queue
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                var lastVolume by remember { mutableStateOf(100) }
                IconButton(onClick = {
                    if (state.volume > 0) { lastVolume = state.volume; player.setVolume(0) } else player.setVolume(lastVolume.coerceAtLeast(10))
                }) {
                    Icon(
                        when {
                            state.volume == 0 -> Icons.Default.VolumeOff
                            state.volume < 50 -> Icons.Default.VolumeDown
                            else -> Icons.Default.VolumeUp
                        },
                        "Bisukan",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                VolumeSlider(
                    value = state.volume,
                    onValueChange = { player.setVolume(it) },
                    modifier = Modifier.width(130.dp),
                )
                Text(
                    "${state.volume}%",
                    Modifier.width(40.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.End,
                )
                Spacer(Modifier.width(4.dp))
                IconButton(onClick = onToggleFullScreen, enabled = song != null) {
                    Icon(
                        if (fullScreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen, "Layar penuh",
                        tint = if (fullScreen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onToggleLyrics) {
                    Icon(
                        Icons.Default.Lyrics, "Lirik",
                        tint = if (lyricsOpen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onToggleQueue) {
                    Icon(
                        Icons.Default.QueueMusic, "Antrean",
                        tint = if (queueOpen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/** Simple custom slider: round thumb, filled track - no M3 stop-indicator dot that reads as a second knob. */
@Composable
private fun VolumeSlider(value: Int, onValueChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    val fraction = value.coerceIn(0, 100) / 100f
    val trackColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
    val fillColor = MaterialTheme.colorScheme.primary
    var widthPx by remember { mutableStateOf(1f) }
    Box(
        modifier
            .height(24.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { offset -> onValueChange((offset.x / widthPx * 100).toInt().coerceIn(0, 100)) }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    onValueChange((change.position.x / widthPx * 100).toInt().coerceIn(0, 100))
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(trackColor))
        Box(Modifier.fillMaxWidth(fraction).height(4.dp).clip(CircleShape).background(fillColor))
        Box(
            Modifier
                .offset { IntOffset((fraction * widthPx - 7.dp.toPx()).toInt().coerceAtLeast(0), 0) }
                .size(14.dp)
                .clip(CircleShape)
                .background(fillColor),
        )
    }
}

@Composable
fun QueuePanel(onClose: () -> Unit) {
    val player = LocalPlayer.current
    val state by player.state.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(state.currentIndex) {
        if (state.currentIndex >= 0) listState.animateScrollToItem(state.currentIndex)
    }

    Column(
        Modifier.width(360.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Antrean", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                state.queueTitle?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Tutup") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        if (state.queue.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("Antrean kosong", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(state = listState, modifier = Modifier.fillMaxWidth()) {
                itemsIndexed(state.queue, key = { i, s -> "$i:${s.id}" }) { index, song ->
                    SongRow(
                        song = song,
                        isActive = index == state.currentIndex,
                        onClick = { player.skipTo(index) },
                    )
                }
            }
        }
    }
}
