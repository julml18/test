package com.redify.desktop.data

import com.music.innertube.models.SongItem
import com.redify.desktop.appDataDir
import com.redify.desktop.playback.StreamResolver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

enum class DownloadStatus { QUEUED, DOWNLOADING, DONE, FAILED }

@Serializable
data class DownloadEntry(
    val song: SongItem,
    val path: String,
    val mimeType: String,
    val bytes: Long = 0,
    val addedAt: Long = System.currentTimeMillis(),
)

data class DownloadProgress(val status: DownloadStatus, val progress: Float = 0f, val error: String? = null)

/**
 * Offline downloads - desktop counterpart of Musicfy's ExoPlayer DownloadService.
 * Audio is stored as-is (m4a/webm) under AppData\Redify\downloads; an index JSON maps ids to files.
 */
object Downloads {
    private val dir = File(appDataDir(), "downloads").apply { mkdirs() }
    private val indexFile = File(appDataDir(), "downloads.json")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val slots = Semaphore(2)
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private val jobs = HashMap<String, Job>()

    private val _entries = MutableStateFlow(loadIndex())
    /** Completed downloads, newest first. */
    val entries: StateFlow<List<DownloadEntry>> = _entries
    private val _progress = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val progress: StateFlow<Map<String, DownloadProgress>> = _progress

    private fun loadIndex(): List<DownloadEntry> = runCatching {
        if (!indexFile.exists()) emptyList()
        else json.decodeFromString<List<DownloadEntry>>(indexFile.readText()).filter { File(it.path).exists() }
    }.getOrDefault(emptyList())

    @Synchronized
    private fun saveIndex() {
        runCatching { indexFile.writeText(json.encodeToString(_entries.value)) }
    }

    fun localFile(songId: String): File? =
        _entries.value.firstOrNull { it.song.id == songId }?.let { File(it.path) }?.takeIf { it.exists() }

    fun isDownloaded(songId: String) = localFile(songId) != null

    fun download(song: SongItem) {
        if (isDownloaded(song.id) || jobs.containsKey(song.id)) return
        _progress.update { it + (song.id to DownloadProgress(DownloadStatus.QUEUED)) }
        jobs[song.id] = scope.launch {
            slots.withPermit {
                runCatching { fetch(song) }
                    .onSuccess { entry ->
                        _entries.update { listOf(entry) + it.filter { e -> e.song.id != song.id } }
                        saveIndex()
                        _progress.update { it + (song.id to DownloadProgress(DownloadStatus.DONE, 1f)) }
                    }
                    .onFailure { e ->
                        _progress.update { it + (song.id to DownloadProgress(DownloadStatus.FAILED, error = e.message)) }
                    }
            }
            jobs.remove(song.id)
        }
    }

    fun downloadAll(songs: List<SongItem>) = songs.forEach(::download)

    fun cancel(songId: String) {
        jobs.remove(songId)?.cancel()
        _progress.update { it - songId }
    }

    fun delete(songId: String) {
        cancel(songId)
        localFile(songId)?.delete()
        _entries.update { it.filter { e -> e.song.id != songId } }
        saveIndex()
    }

    private suspend fun fetch(song: SongItem): DownloadEntry {
        _progress.update { it + (song.id to DownloadProgress(DownloadStatus.DOWNLOADING, 0f)) }
        val stream = StreamResolver.resolve(song.id).getOrThrow()
        val ext = when {
            "mp4" in stream.mimeType -> "m4a"
            "webm" in stream.mimeType -> "webm"
            else -> "bin"
        }
        val target = File(dir, "${song.id}.$ext")
        val tmp = File(dir, "${song.id}.$ext.part")
        val request = Request.Builder().url(stream.url).header("User-Agent", StreamResolver.userAgentFor(stream)).build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            val body = response.body ?: error("Respons kosong")
            val total = body.contentLength()
            body.byteStream().use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read: Int
                    var done = 0L
                    while (input.read(buf).also { read = it } != -1) {
                        out.write(buf, 0, read)
                        done += read
                        if (total > 0) {
                            val p = done.toFloat() / total
                            _progress.update { it + (song.id to DownloadProgress(DownloadStatus.DOWNLOADING, p)) }
                        }
                    }
                }
            }
        }
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) error("Gagal menyimpan file")
        return DownloadEntry(song = song, path = target.absolutePath, mimeType = stream.mimeType, bytes = target.length())
    }

    fun totalBytes(): Long = _entries.value.sumOf { it.bytes }
}
