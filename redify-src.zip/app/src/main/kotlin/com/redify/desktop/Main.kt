package com.redify.desktop

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowState
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import coil3.ImageLoader
import coil3.compose.setSingletonImageLoaderFactory
import coil3.disk.DiskCache
import coil3.memory.MemoryCache
import coil3.request.crossfade
import com.music.innertube.YouTube
import com.music.innertube.models.YouTubeLocale
import com.redify.desktop.data.Library
import com.redify.desktop.data.Settings
import com.redify.desktop.playback.PlayerController
import com.redify.desktop.ui.RedifyTheme
import com.redify.desktop.ui.rememberArtworkPalette
import okio.Path.Companion.toOkioPath
import java.awt.Desktop
import java.io.File
import java.net.URI
import java.util.Locale

private val crashLog: File by lazy { File(appDataDir(), "redify.log") }

fun log(message: String, error: Throwable? = null) {
    runCatching {
        crashLog.appendText(
            "${java.time.LocalDateTime.now()} $message" +
                (error?.let { "\n" + it.stackTraceToString() } ?: "") + "\n"
        )
    }
}

fun main() {
    Thread.setDefaultUncaughtExceptionHandler { t, e -> log("Uncaught on ${t.name}", e) }
    log("Redify starting (java ${System.getProperty("java.version")}, ${System.getProperty("os.name")})")

    // Same defaults as Musicfy Android's first run.
    YouTube.locale = YouTubeLocale(
        gl = Locale.getDefault().country.ifBlank { "ID" },
        hl = Locale.getDefault().language.ifBlank { "id" },
    )

    application {
        var player by remember { mutableStateOf<PlayerController?>(null) }
        var initError by remember { mutableStateOf<String?>(null) }
        var initStep by remember { mutableStateOf("Menyiapkan…") }

        // Heavy initialisation runs off the UI thread so the window always appears,
        // and every step is logged to %APPDATA%\Redify\redify.log.
        LaunchedEffect(Unit) {
            withContext(Dispatchers.IO) {
                try {
                    initStep = "Memuat pengaturan…"; log("step: settings")
                    Settings.applyToYouTube()
                    initStep = "Membuka koleksi lokal…"; log("step: library")
                    Library.liked.value
                    initStep = "Mencari VLC…"; log("step: player")
                    // LibVLC can hang while loading (broken plugin cache, 32-bit VLC with a 64-bit app…);
                    // build the player on its own thread and give up waiting after 30 s so the window
                    // explains what to do instead of sitting on "Mencari VLC…" forever.
                    val ready = java.util.concurrent.CompletableFuture<PlayerController>()
                    Thread({
                        try { ready.complete(PlayerController()) } catch (e: Throwable) { ready.completeExceptionally(e) }
                    }, "player-init").apply { isDaemon = true }.start()
                    val p = try {
                        ready.get(30, java.util.concurrent.TimeUnit.SECONDS)
                    } catch (e: java.util.concurrent.TimeoutException) {
                        log("player init timed out after 30s (VLC hang?)")
                        initError = "VLC tidak merespons saat dimuat.\n\n" +
                            "Pastikan yang terpasang adalah VLC media player 64-bit versi 3.x dari videolan.org " +
                            "(bukan versi Microsoft Store / 32-bit), lalu buka Redify lagi.\n" +
                            "Kalau masih begini, hapus folder %APPDATA%\\vlc dan kirim %APPDATA%\\Redify\\redify.log."
                        // Keep waiting in the background; if VLC eventually comes up, continue normally.
                        ready.get()
                    } catch (e: java.util.concurrent.ExecutionException) {
                        throw e.cause ?: e
                    }
                    log("Init done, vlcAvailable=${p.vlcAvailable}")
                    initError = null
                    player = p
                } catch (e: Throwable) {
                    log("Init failed at '$initStep'", e)
                    initError = "$initStep ${e::class.simpleName}: ${e.message}"
                }
            }
        }

        val windowState: WindowState = rememberWindowState(size = DpSize(1280.dp, 820.dp))

        setSingletonImageLoaderFactory { context ->
            ImageLoader.Builder(context)
                .crossfade(true)
                .memoryCache { MemoryCache.Builder().maxSizePercent(context, 0.2).build() }
                .diskCache {
                    DiskCache.Builder()
                        .directory(appDataDir().resolve("image_cache").toOkioPath())
                        .maxSizeBytes(256L * 1024 * 1024)
                        .build()
                }
                .build()
        }

        Window(
            onCloseRequest = {
                runCatching { player?.release() }
                exitApplication()
            },
            title = "Redify",
            state = windowState,
        ) {
            val controller = player
            if (controller == null) {
                RedifyTheme(darkTheme = true) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        if (initError != null) StartupError("$initError\n\nLog: ${crashLog.absolutePath}")
                        else StartupLoading(initStep)
                    }
                }
                return@Window
            }
            val settings by Settings.state.collectAsState()
            LaunchedEffect(Unit) {
                log("window ready")
                // Visitor data makes Home/recommendations consistent between requests.
                if (settings.visitorData == null) {
                    YouTube.refreshVisitorData().onSuccess { v -> Settings.update { it.copy(visitorData = v) } }
                }
            }
            val playerState by controller.state.collectAsState()
            val palette = rememberArtworkPalette(playerState.current?.thumbnail, enabled = settings.artworkTheme)
            RedifyTheme(darkTheme = settings.darkTheme, palette = palette) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (controller.vlcAvailable) {
                        App(controller)
                    } else {
                        VlcMissing()
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun StartupLoading(step: String) {
    Column(Modifier.fillMaxSize().padding(48.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
        androidx.compose.material3.CircularProgressIndicator()
        Spacer(Modifier.height(16.dp))
        Text("Redify", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(step, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@androidx.compose.runtime.Composable
private fun StartupError(message: String) {
    Column(Modifier.fillMaxSize().padding(48.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
        Text("Redify gagal dimulai", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@androidx.compose.runtime.Composable
private fun VlcMissing() {
    Column(
        Modifier.fillMaxSize().padding(48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        Text("VLC media player belum terpasang", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            "Redify memakai mesin audio LibVLC. Pasang VLC 3.x versi 64-bit, lalu buka aplikasi ini lagi.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = { openUrl("https://www.videolan.org/vlc/download-windows.html") }) {
            Text("Unduh VLC")
        }
    }
}

fun appDataDir(): File {
    val os = System.getProperty("os.name").lowercase()
    val base = when {
        "win" in os -> File(System.getenv("APPDATA") ?: System.getProperty("user.home"))
        "mac" in os -> File(System.getProperty("user.home"), "Library/Application Support")
        else -> File(System.getenv("XDG_DATA_HOME") ?: (System.getProperty("user.home") + "/.local/share"))
    }
    return File(base, "Redify").apply { mkdirs() }
}

fun openUrl(url: String) {
    runCatching {
        if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(URI(url))
    }
}
