package com.redify.desktop.playback

import com.music.innertube.YouTube
import com.music.innertube.models.SongItem
import com.music.innertube.models.WatchEndpoint
import com.redify.desktop.data.Downloads
import com.redify.desktop.data.Library
import com.redify.desktop.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import uk.co.caprica.vlcj.factory.discovery.NativeDiscovery
import uk.co.caprica.vlcj.player.base.Equalizer
import uk.co.caprica.vlcj.player.base.MediaPlayer
import uk.co.caprica.vlcj.player.base.State
import uk.co.caprica.vlcj.player.base.MediaPlayerEventAdapter
import uk.co.caprica.vlcj.player.component.AudioPlayerComponent

enum class RepeatMode { OFF, ALL, ONE }

data class PlayerState(
    val queue: List<SongItem> = emptyList(),
    val queueTitle: String? = null,
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    /** Wall-clock time when [positionMs] was last reported, for frame-accurate interpolation. */
    val positionAtMs: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L,
    val volume: Int = 100,
    val rate: Float = 1f,
    val streamCodec: String? = null,
    val streamBitrate: Int? = null,
    val streamSampleRate: Int? = null,
    val sleepTimerEndsAt: Long? = null,
    val shuffle: Boolean = false,
    val repeat: RepeatMode = RepeatMode.OFF,
    val error: String? = null,
) {
    val current: SongItem? get() = queue.getOrNull(currentIndex)
    val hasNext: Boolean get() = currentIndex in 0 until queue.lastIndex || repeat == RepeatMode.ALL
    val hasPrevious: Boolean get() = currentIndex > 0 || positionMs > 3000
}

/**
 * Playback engine for the desktop app, built on vlcj (LibVLC).
 * Mirrors the subset of Musicfy's MusicService needed for Tahap 1:
 * queue, play/pause/next/previous, seek, shuffle, repeat and radio continuation.
 */
class PlayerController {

    val vlcAvailable: Boolean = runCatching { NativeDiscovery().discover() }
        .onFailure { com.redify.desktop.log("vlc discovery failed", it) }
        .getOrDefault(false)
        .also { com.redify.desktop.log("vlc discovery: $it") }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val component: AudioPlayerComponent? = if (vlcAvailable) {
        com.redify.desktop.log("creating LibVLC instance…")
        runCatching { AudioPlayerComponent() }
            .onFailure { com.redify.desktop.log("AudioPlayerComponent failed", it) }
            .onSuccess { com.redify.desktop.log("AudioPlayerComponent ok") }
            .getOrNull()
    } else null
    private val factory = component?.mediaPlayerFactory()

    // Two decks: the active one plays, the other is used to fade the next track in (crossfade).
    private val players: List<MediaPlayer> = buildList {
        component?.mediaPlayer()?.let { add(it) }
        runCatching { factory?.mediaPlayers()?.newMediaPlayer() }.getOrNull()?.let { add(it) }
    }.also { com.redify.desktop.log("decks ready: ${it.size}") }
    private var active = 0
    private val player: MediaPlayer? get() = players.getOrNull(active)
    private val secondary: MediaPlayer? get() = if (players.size > 1) players[1 - active] else null
    @Volatile private var crossfading = false
    private var retriedFor: String? = null
    private var prefetched: Pair<Int, Source>? = null
    private var prefetchJob: Job? = null

    /** Everything needed to start a track on a deck. */
    private data class Source(
        val mrl: String,
        val options: Array<String>,
        val codec: String?,
        val bitrate: Int?,
        val sampleRate: Int?,
        val gain: Float,
    )

    // ---- Equalizer (LibVLC 10-band) -------------------------------------------
    val eqBandFrequencies: FloatArray = factory?.equalizer()?.bands()?.toFloatArray() ?: floatArrayOf(60f, 170f, 310f, 600f, 1000f, 3000f, 6000f, 12000f, 14000f, 16000f)
    val eqPresets: List<String> = factory?.equalizer()?.presets().orEmpty()
    private var equalizer: Equalizer? = null

    fun presetAmps(name: String): FloatArray =
        factory?.equalizer()?.newEqualizer(name)?.amps() ?: FloatArray(eqBandFrequencies.size)

    fun applyEqualizer(enabled: Boolean, preamp: Float, amps: List<Float>) {
        val p = player ?: return
        if (!enabled) {
            players.forEach { it.audio().setEqualizer(null) }
            return
        }
        val eq = equalizer ?: factory?.equalizer()?.newEqualizer()?.also { equalizer = it } ?: return
        eq.setPreamp(preamp)
        amps.forEachIndexed { i, a -> if (i < eqBandFrequencies.size) eq.setAmp(i, a) }
        players.forEach { it.audio().setEqualizer(eq) }
    }

    private fun applySavedEqualizer() {
        val s = Settings.current
        applyEqualizer(s.eqEnabled, s.eqPreamp, s.eqAmps)
    }

    private val _state = MutableStateFlow(PlayerState(volume = Settings.current.volume))
    /** Gain multiplier from YouTube's loudness metadata (audio normalization). */
    private var normalizationGain = 1f
    val state: StateFlow<PlayerState> = _state

    private var loadJob: Job? = null
    private var radioContinuation: String? = null
    private var radioEndpoint: WatchEndpoint? = null
    private var shuffledOrder: List<Int> = emptyList()

    init {
        players.forEach { deck ->
            deck.events().addMediaPlayerEventListener(object : MediaPlayerEventAdapter() {
            // Only the active deck drives the UI; the fading-out deck is ignored.
            private fun isActive(mp: MediaPlayer) = mp === player

            override fun playing(mediaPlayer: MediaPlayer) {
                if (!isActive(mediaPlayer)) return
                _state.update { it.copy(isPlaying = true, isBuffering = false) }
                mediaPlayer.submit {
                    val seek = pendingSeekMs
                    if (seek > 0) { pendingSeekMs = -1; mediaPlayer.controls().setTime(seek) }
                    else if (seek == 0L) pendingSeekMs = -1
                    if (!crossfading) applyVolume(mediaPlayer)
                    if (_state.value.rate != 1f) mediaPlayer.controls().setRate(_state.value.rate)
                }
            }

            override fun paused(mediaPlayer: MediaPlayer) {
                if (isActive(mediaPlayer)) _state.update { it.copy(isPlaying = false) }
            }

            override fun stopped(mediaPlayer: MediaPlayer) {
                if (isActive(mediaPlayer)) _state.update { it.copy(isPlaying = false) }
            }

            override fun buffering(mediaPlayer: MediaPlayer, newCache: Float) {
                if (isActive(mediaPlayer)) _state.update { it.copy(isBuffering = newCache < 100f) }
            }

            override fun lengthChanged(mediaPlayer: MediaPlayer, newLength: Long) {
                if (isActive(mediaPlayer)) _state.update { it.copy(durationMs = newLength) }
            }

            override fun timeChanged(mediaPlayer: MediaPlayer, newTime: Long) {
                if (isActive(mediaPlayer)) _state.update { it.copy(positionMs = newTime, positionAtMs = System.currentTimeMillis()) }
            }

            override fun finished(mediaPlayer: MediaPlayer) {
                if (isActive(mediaPlayer)) scope.launch { onTrackFinished() }
            }

            override fun error(mediaPlayer: MediaPlayer) {
                if (!isActive(mediaPlayer)) return
                val song = _state.value.current
                // First failure: blacklist that stream/client and resolve again with a different one.
                if (song != null && retriedFor != song.id) {
                    retriedFor = song.id
                    StreamResolver.markFailed(song.id)
                    com.redify.desktop.log("VLC error on ${song.title}, retrying with another client")
                    _state.update { it.copy(isBuffering = true, error = "Mencoba sumber lain…") }
                    scope.launch { loadCurrent() }
                    return
                }
                _state.update { it.copy(isPlaying = false, isBuffering = false, error = "Gagal memutar lagu") }
                if (Settings.current.dontSkipOnFailure) return
                scope.launch { delay(Settings.current.skipTimeoutSec * 1000L); if (_state.value.hasNext) next() }
            }
            })
        }

        // Safety net: VLC time events can be sparse; poll position while playing.
        // Also counts listening time (Musicfy's "Total Listening time") and saves the last state.
        scope.launch {
            var tick = 0
            while (isActive) {
                delay(500)
                val p = player ?: continue
                if (_state.value.isPlaying) {
                    _state.update { it.copy(positionMs = p.status().time().coerceAtLeast(0), positionAtMs = System.currentTimeMillis()) }
                    if (++tick % 20 == 0) Settings.update { it.copy(listeningSeconds = it.listeningSeconds + 10) }
                    if (tick % 30 == 0) saveLastState()
                    maybeCrossfade()
                }
            }
        }
    }

    // ---- Queue management ---------------------------------------------------

    fun playQueue(songs: List<SongItem>, startIndex: Int = 0, title: String? = null) {
        if (songs.isEmpty()) return
        radioContinuation = null
        radioEndpoint = null
        _state.update {
            it.copy(queue = songs, currentIndex = startIndex.coerceIn(0, songs.lastIndex), queueTitle = title, error = null)
        }
        reshuffle()
        loadCurrent()
    }

    fun playSong(song: SongItem) {
        playQueue(listOf(song), 0, song.title)
        // Start a radio from this song so playback continues like YouTube Music.
        startRadio(song.endpoint ?: WatchEndpoint(videoId = song.id), keepCurrent = true)
    }

    fun startRadio(endpoint: WatchEndpoint, keepCurrent: Boolean = false) {
        scope.launch {
            YouTube.next(endpoint).onSuccess { result ->
                radioEndpoint = result.endpoint
                radioContinuation = result.continuation
                _state.update { st ->
                    if (keepCurrent && st.queue.isNotEmpty()) {
                        val cur = st.queue[st.currentIndex]
                        val extra = result.items.filter { it.id != cur.id }
                        st.copy(queue = listOf(cur) + extra, currentIndex = 0, queueTitle = result.title ?: st.queueTitle)
                    } else {
                        val index = result.currentIndex ?: 0
                        st.copy(queue = result.items, currentIndex = index, queueTitle = result.title)
                    }
                }
                reshuffle()
                if (!keepCurrent) loadCurrent()
            }
        }
    }

    fun addToQueue(song: SongItem) {
        _state.update { st ->
            if (st.queue.isEmpty()) st.copy(queue = listOf(song), currentIndex = 0)
            else st.copy(queue = st.queue + song)
        }
        if (_state.value.queue.size == 1) loadCurrent()
    }

    fun playNext(song: SongItem) {
        _state.update { st ->
            if (st.queue.isEmpty()) st.copy(queue = listOf(song), currentIndex = 0)
            else st.copy(queue = st.queue.toMutableList().apply { add(st.currentIndex + 1, song) })
        }
        if (_state.value.queue.size == 1) loadCurrent()
    }

    /** Moves a queue item (drag reorder). The current song keeps playing; indices are adjusted. */
    fun moveInQueue(from: Int, to: Int) {
        _state.update { st ->
            if (from !in st.queue.indices || to !in st.queue.indices || from == to) return@update st
            val q = st.queue.toMutableList()
            val item = q.removeAt(from); q.add(to, item)
            val cur = when {
                st.currentIndex == from -> to
                from < st.currentIndex && to >= st.currentIndex -> st.currentIndex - 1
                from > st.currentIndex && to <= st.currentIndex -> st.currentIndex + 1
                else -> st.currentIndex
            }
            st.copy(queue = q, currentIndex = cur)
        }
        reshuffle()
        saveLastState()
    }

    fun removeFromQueue(index: Int) {
        _state.update { st ->
            if (index !in st.queue.indices || index == st.currentIndex) st
            else st.copy(
                queue = st.queue.toMutableList().apply { removeAt(index) },
                currentIndex = if (index < st.currentIndex) st.currentIndex - 1 else st.currentIndex,
            )
        }
    }

    fun skipTo(index: Int) {
        if (index !in _state.value.queue.indices) return
        _state.update { it.copy(currentIndex = index) }
        loadCurrent()
    }

    // ---- Transport ------------------------------------------------------------

    /** Position to seek to once the next media starts (resume after relaunch / stalled stream). */
    @Volatile private var pendingSeekMs: Long = -1

    fun togglePlayPause() {
        val p = player ?: return
        val st = _state.value
        val song = st.current ?: return
        if (p.status().isPlaying) { p.controls().pause(); return }

        val vlcState = runCatching { p.status().state() }.getOrNull()
        if (vlcState == State.PAUSED) {
            p.controls().play()
            // Stalled HTTP stream (paused too long): if VLC doesn't resume, reload at the same position.
            scope.launch {
                delay(2500)
                val now = _state.value
                if (!now.isPlaying && now.current?.id == song.id && runCatching { p.status().state() }.getOrNull() != State.PLAYING) {
                    pendingSeekMs = now.positionMs
                    loadCurrent()
                }
            }
            return
        }
        // Nothing loaded yet (queue restored after relaunch), or the media has ended / errored:
        // load the current song again and continue from where we were.
        pendingSeekMs = if (vlcState == State.ENDED) 0 else st.positionMs
        loadCurrent()
    }

    fun next() {
        val st = _state.value
        if (st.queue.isEmpty()) return
        val nextIndex = nextIndexFor(st)
        if (nextIndex == null) {
            // Try to extend the radio queue first.
            scope.launch {
                if (loadMoreRadio()) {
                    nextIndexFor(_state.value)?.let { skipTo(it) }
                } else {
                    player?.controls()?.stop()
                    _state.update { it.copy(isPlaying = false, positionMs = 0) }
                }
            }
            return
        }
        skipTo(nextIndex)
    }

    fun previous() {
        val st = _state.value
        if (st.positionMs > 3000 || st.currentIndex <= 0) {
            seekTo(0)
            return
        }
        skipTo(st.currentIndex - 1)
    }

    fun seekTo(positionMs: Long) {
        player?.controls()?.setTime(positionMs.coerceAtLeast(0))
        _state.update { it.copy(positionMs = positionMs, positionAtMs = System.currentTimeMillis()) }
    }

    fun setVolume(volume: Int) {
        val v = volume.coerceIn(0, 100)
        _state.update { it.copy(volume = v) }
        player?.let { applyVolume(it) }
        Settings.update { it.copy(volume = v) }
    }

    fun setRate(rate: Float) {
        val r = rate.coerceIn(0.5f, 2f)
        player?.controls()?.setRate(r)
        _state.update { it.copy(rate = r) }
    }

    /** Sleep timer: pause after [minutes]; null cancels. */
    private var sleepJob: Job? = null
    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        if (minutes == null) { _state.update { it.copy(sleepTimerEndsAt = null) }; return }
        val endsAt = System.currentTimeMillis() + minutes * 60_000L
        _state.update { it.copy(sleepTimerEndsAt = endsAt) }
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            player?.controls()?.setPause(true)
            _state.update { it.copy(sleepTimerEndsAt = null) }
        }
    }

    /** Audio output devices known to LibVLC (id to description). */
    fun outputDevices(): List<Pair<String, String>> =
        runCatching { player?.audio()?.outputDevices()?.map { it.deviceId to it.longName } }.getOrNull().orEmpty()

    fun setOutputDevice(deviceId: String) {
        runCatching { player?.audio()?.setOutputDevice(null, deviceId) }
    }

    fun toggleShuffle() {
        _state.update { it.copy(shuffle = !it.shuffle) }
        reshuffle()
    }

    fun cycleRepeat() {
        _state.update {
            it.copy(
                repeat = when (it.repeat) {
                    RepeatMode.OFF -> RepeatMode.ALL
                    RepeatMode.ALL -> RepeatMode.ONE
                    RepeatMode.ONE -> RepeatMode.OFF
                }
            )
        }
    }

    /** Re-applies volume (used when the normalization setting changes). */
    fun refreshVolume() { player?.let { applyVolume(it) } }

    // ---- Last state (Musicfy "Save Player's last state") -----------------------------
    private val stateFile = java.io.File(com.redify.desktop.appDataDir(), "player_state.json")
    private val stateJson = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }

    @kotlinx.serialization.Serializable
    private data class SavedState(val queue: List<SongItem>, val index: Int, val positionMs: Long, val title: String?)

    private fun saveLastState() {
        if (!Settings.current.saveLastState) return
        val st = _state.value
        if (st.queue.isEmpty()) return
        runCatching { stateFile.writeText(stateJson.encodeToString(SavedState.serializer(), SavedState(st.queue.take(200), st.currentIndex, st.positionMs, st.queueTitle))) }
    }

    private fun restoreLastState() {
        if (!Settings.current.saveLastState || !stateFile.exists()) return
        val saved = runCatching { stateJson.decodeFromString(SavedState.serializer(), stateFile.readText()) }.getOrNull() ?: return
        if (saved.queue.isEmpty()) return
        _state.update { it.copy(queue = saved.queue, currentIndex = saved.index.coerceIn(0, saved.queue.lastIndex), queueTitle = saved.title, positionMs = saved.positionMs) }
        if (Settings.current.resumeOnLaunch) loadCurrent()
    }

    fun clearLastState() { runCatching { stateFile.delete() } }

    fun release() {
        saveLastState()
        loadJob?.cancel()
        players.forEach { runCatching { it.controls().stop() } }
        players.getOrNull(1)?.let { runCatching { it.release() } }
        component?.release()
    }

    // ---- Internals ------------------------------------------------------------

    /**
     * Loudness normalisation gain from YouTube's loudnessDb. Kept mild (±3 dB) so the user's volume
     * setting stays meaningful: a song never drops below ~70 % of the chosen volume.
     */
    private fun loudnessGain(loudnessDb: Double?): Float =
        loudnessDb?.let { Math.pow(10.0, -it / 20.0).toFloat().coerceIn(0.7f, 1.2f) } ?: 1f

    private fun applyVolume(p: MediaPlayer) {
        val gain = if (Settings.current.normalization) normalizationGain else 1f
        p.audio().setVolume((_state.value.volume * gain).toInt().coerceIn(0, 150))
    }

    private fun loadCurrent() {
        val song = _state.value.current ?: return
        val p = player
        if (p == null) {
            _state.update { it.copy(error = "VLC tidak ditemukan. Install VLC media player dulu.") }
            return
        }
        if (Settings.current.offlineMode && Downloads.localFile(song.id) == null) {
            _state.update { it.copy(isBuffering = false, isPlaying = false, error = "Mode offline: lagu ini belum diunduh") }
            scope.launch { delay(800); if (_state.value.hasNext) next() }
            return
        }
        loadJob?.cancel()
        prefetched = null
        if (!crossfading) secondary?.let { runCatching { it.controls().stop() } }
        _state.update { it.copy(isBuffering = true, positionMs = pendingSeekMs.coerceAtLeast(0), durationMs = (song.duration ?: 0) * 1000L, error = null) }
        loadJob = scope.launch {
            // Offline copy first - no network needed.
            Downloads.localFile(song.id)?.let { file ->
                normalizationGain = 1f
                _state.update { it.copy(streamCodec = if (file.extension == "webm") "OPUS" else "AAC", streamBitrate = null, streamSampleRate = null) }
                p.media().play(file.absolutePath, ":no-video")
                applyVolume(p)
                applySavedEqualizer()
                Library.recordPlay(song)
                saveLastState()
                return@launch
            }
            StreamResolver.resolve(song.id)
                .onSuccess { stream ->
                    if (!isActive) return@onSuccess
                    p.media().play(
                        stream.url,
                        ":http-user-agent=${StreamResolver.userAgentFor(stream)}",
                        ":network-caching=1500",
                        ":no-video",
                    )
                    // Loudness normalisation like Musicfy/ExoPlayer: gain = 10^(-loudnessDb/20), capped.
                    normalizationGain = loudnessGain(stream.loudnessDb)
                    _state.update { it.copy(streamCodec = stream.codec, streamBitrate = stream.bitrate, streamSampleRate = stream.sampleRate) }
                    applyVolume(p)
                    applySavedEqualizer()
                    Library.recordPlay(song)
                    saveLastState()
                    // Pre-fetch more radio items when we are near the end of the queue.
                    val st = _state.value
                    if (st.currentIndex >= st.queue.lastIndex - 2) loadMoreRadio()
                }
                .onFailure { e ->
                    _state.update { it.copy(isBuffering = false, isPlaying = false, error = e.message ?: "Gagal memuat lagu") }
                    if (Settings.current.dontSkipOnFailure) return@onFailure
                    delay(Settings.current.skipTimeoutSec * 1000L)
                    if (_state.value.hasNext) next()
                }
        }
    }

    // ---- Crossfade ----------------------------------------------------------------
    private fun maybeCrossfade() {
        val s = Settings.current
        if (!s.crossfadeEnabled || crossfading || secondary == null) return
        val st = _state.value
        if (st.durationMs <= 0 || st.repeat == RepeatMode.ONE) return
        val nextIndex = nextIndexFor(st) ?: return
        val remaining = st.durationMs - st.positionMs
        val fadeMs = s.crossfadeSec * 1000L
        // Resolve the next stream ahead of time so the fade starts exactly on cue.
        if (remaining <= fadeMs + 15_000 && prefetched?.first != nextIndex && prefetchJob?.isActive != true) {
            prefetchJob = scope.launch {
                prepareSource(st.queue[nextIndex]).onSuccess { prefetched = nextIndex to it }
            }
        }
        if (remaining in 1..fadeMs) startCrossfade(nextIndex)
    }

    private fun startCrossfade(nextIndex: Int) {
        val old = player ?: return
        val new = secondary ?: return
        crossfading = true
        scope.launch {
            val st = _state.value
            val nextSong = st.queue.getOrNull(nextIndex) ?: run { crossfading = false; return@launch }
            val src = prefetched?.takeIf { it.first == nextIndex }?.second
                ?: prepareSource(nextSong).getOrNull()
                ?: run { crossfading = false; return@launch }
            prefetched = null

            new.audio().setVolume(0)
            new.media().play(src.mrl, *src.options)
            if (_state.value.rate != 1f) new.controls().setRate(_state.value.rate)

            active = 1 - active
            normalizationGain = src.gain
            _state.update {
                it.copy(
                    currentIndex = nextIndex, positionMs = 0, positionAtMs = System.currentTimeMillis(),
                    durationMs = (nextSong.duration ?: 0) * 1000L, isBuffering = false, error = null,
                    streamCodec = src.codec, streamBitrate = src.bitrate, streamSampleRate = src.sampleRate,
                )
            }
            Library.recordPlay(nextSong)
            saveLastState()

            val target = targetVolume()
            val fadeMs = Settings.current.crossfadeSec * 1000L
            val steps = 30
            repeat(steps) { i ->
                val f = (i + 1) / steps.toFloat()
                runCatching {
                    old.audio().setVolume((target * (1f - f)).toInt())
                    new.audio().setVolume((target * f).toInt())
                }
                delay(fadeMs / steps)
            }
            runCatching { old.controls().stop() }
            crossfading = false
            val now = _state.value
            if (now.currentIndex >= now.queue.lastIndex - 2) loadMoreRadio()
        }
    }

    private fun targetVolume(): Int {
        val gain = if (Settings.current.normalization) normalizationGain else 1f
        return (_state.value.volume * gain).toInt().coerceIn(0, 150)
    }

    /** Resolves a song to something a deck can play (offline file first, then YouTube stream). */
    private suspend fun prepareSource(song: SongItem): Result<Source> {
        Downloads.localFile(song.id)?.let { file ->
            return Result.success(Source(file.absolutePath, arrayOf(":no-video"), if (file.extension == "webm") "OPUS" else "AAC", null, null, 1f))
        }
        return StreamResolver.resolve(song.id).map { stream ->
            Source(
                mrl = stream.url,
                options = arrayOf(":http-user-agent=${StreamResolver.userAgentFor(stream)}", ":network-caching=1500", ":no-video"),
                codec = stream.codec, bitrate = stream.bitrate, sampleRate = stream.sampleRate,
                gain = loudnessGain(stream.loudnessDb),
            )
        }
    }

    private suspend fun onTrackFinished() {
        if (crossfading) return
        val st = _state.value
        when (st.repeat) {
            RepeatMode.ONE -> loadCurrent()
            else -> next()
        }
    }

    private fun nextIndexFor(st: PlayerState): Int? {
        if (st.shuffle && shuffledOrder.isNotEmpty()) {
            val pos = shuffledOrder.indexOf(st.currentIndex)
            return when {
                pos in 0 until shuffledOrder.lastIndex -> shuffledOrder[pos + 1]
                st.repeat == RepeatMode.ALL -> shuffledOrder.first()
                else -> null
            }
        }
        return when {
            st.currentIndex < st.queue.lastIndex -> st.currentIndex + 1
            st.repeat == RepeatMode.ALL -> 0
            else -> null
        }
    }

    private fun reshuffle() {
        val st = _state.value
        shuffledOrder = if (st.shuffle) {
            val others = st.queue.indices.filter { it != st.currentIndex }.shuffled()
            listOf(st.currentIndex) + others
        } else emptyList()
    }

    private suspend fun loadMoreRadio(): Boolean {
        val endpoint = radioEndpoint ?: return false
        val continuation = radioContinuation ?: return false
        val result = YouTube.next(endpoint, continuation).getOrNull() ?: return false
        radioContinuation = result.continuation
        val existing = _state.value.queue.map { it.id }.toSet()
        val fresh = result.items.filter { it.id !in existing }
        if (fresh.isEmpty()) return false
        _state.update { it.copy(queue = it.queue + fresh) }
        reshuffle()
        return true
    }

    init {
        // Declared last so every property above (state file, json) is initialised first.
        restoreLastState()
    }
}
