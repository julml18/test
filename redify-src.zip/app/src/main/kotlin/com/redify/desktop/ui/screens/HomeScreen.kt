package com.redify.desktop.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.music.innertube.YouTube
import com.music.innertube.pages.HomePage
import com.redify.desktop.LocalNavigator
import com.redify.desktop.LocalOpenPlayer
import com.redify.desktop.LocalPlayer
import com.redify.desktop.Screen
import com.redify.desktop.data.Library
import com.redify.desktop.data.Settings
import com.redify.desktop.ui.rememberArtworkPalette
import com.music.innertube.models.SongItem
import androidx.compose.material.icons.filled.Casino
import androidx.compose.ui.draw.rotate
import com.redify.desktop.ui.Artwork
import com.redify.desktop.ui.ArtworkImage
import com.redify.desktop.ui.ItemCarousel
import com.redify.desktop.ui.SectionHeader

private val BottomPadding = 170.dp // room for the floating mini player + nav pill

@Composable
fun HomeScreen() {
    var selectedChip by remember { mutableStateOf<HomePage.Chip?>(null) }
    val nav = LocalNavigator.current

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = BottomPadding)) {
        item { Hero() }
        item { GachaCard() }
        item { RecentlyPlayed() }
        item { MostPlayed() }
        item { HistorySection() }
        item { YourPlaylists() }
        item {
            Loaded(key = selectedChip?.title ?: "home", fetch = { YouTube.home(params = selectedChip?.endpoint?.params) }, modifier = Modifier.fillMaxWidth().height(300.dp)) { page ->
                Column {
                    val chips = page.chips.orEmpty()
                    if (chips.isNotEmpty()) {
                        LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(chips, key = { it.title }) { chip ->
                                val selected = selectedChip?.title == chip.title
                                FilterChip(selected = selected, onClick = { selectedChip = if (selected) null else chip }, label = { Text(chip.title) })
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                    page.sections.forEachIndexed { i, section ->
                        HomeSectionHeader(section, onMore = section.endpoint?.let { ep -> { nav.openBrowse(ep, section.title) } })
                        val videos = section.items.filterIsInstance<SongItem>()
                        if (videos.isNotEmpty() && videos.size == section.items.size && videos.all { it.isVideoLike }) WideCarousel(videos)
                        else ItemCarousel(section.items)
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

/** Big "Continue" header with the current/last song's artwork, like Musicfy's home. */
@Composable
private fun Hero() {
    val player = LocalPlayer.current
    val nav = LocalNavigator.current
    val openPlayer = LocalOpenPlayer.current
    val state by player.state.collectAsState()
    val history by Library.history.collectAsState()
    val song = state.current ?: history.firstOrNull()?.song

    Box(Modifier.fillMaxWidth().height(460.dp)) {
        if (song?.thumbnail != null) {
            ArtworkImage(song.thumbnail, Modifier.fillMaxSize().alpha(0.9f), size = 1024)
        } else {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF2A2A2E), Color.Black))))
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0f to Color.Black.copy(alpha = 0.35f), 0.55f to Color.Transparent, 1f to MaterialTheme.colorScheme.background)
            )
        )
        // Logo + account
        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Text("R", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { nav.replaceRoot(Screen.Settings) }, modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))) {
                Icon(Icons.Default.Person, "Akun", tint = Color.White)
            }
        }
        Column(Modifier.align(Alignment.BottomStart).padding(horizontal = 24.dp, vertical = 20.dp)) {
            Text(if (state.current != null) "Continue" else if (song != null) "Last played" else "Selamat datang", color = Color.White.copy(alpha = 0.75f), fontSize = 16.sp)
            Text(
                song?.let { "${it.title} - ${it.artists.joinToString { a -> a.name }}" } ?: "Redify",
                color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(14.dp))
            if (song != null) {
                Row(
                    Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.18f)).clickable {
                        if (state.current == null) player.playSong(song) else if (!state.isPlaying) player.togglePlayPause() else openPlayer()
                    }.padding(horizontal = 22.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Play", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun RecentlyPlayed() {
    val nav = LocalNavigator.current
    val player = LocalPlayer.current
    val liked by Library.liked.collectAsState()
    val history by Library.history.collectAsState()
    val recent = remember(history) { history.map { it.song }.distinctBy { it.id }.take(20) }

    Column(Modifier.padding(top = 4.dp)) {
        Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp).clickable { nav.replaceRoot(Screen.Library) }, verticalAlignment = Alignment.CenterVertically) {
            Text("Recently Played", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Column(Modifier.width(190.dp).clip(RoundedCornerShape(14.dp)).clickable { nav.replaceRoot(Screen.Library) }.padding(4.dp)) {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFFE2641E), Color(0xFFBD8A2F), Color(0xFF5E8F3A)))),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.FavoriteBorder, null, tint = Color.White, modifier = Modifier.size(84.dp)) }
                    Spacer(Modifier.height(8.dp))
                    Text("Disukai", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Text("${liked.size} lagu", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                }
            }
            itemsIndexed(recent, key = { i, s -> "$i:${s.id}" }) { i, song ->
                Column(Modifier.width(190.dp).clip(RoundedCornerShape(14.dp)).clickable { player.playQueue(recent, i, "Recently Played") }.padding(4.dp)) {
                    Artwork(song.thumbnail, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(18.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(song.title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artists.joinToString { it.name }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

// ---- Musicfy-style additions ------------------------------------------------------------

private val SongItem.isVideoLike: Boolean
    get() = "ytimg.com" in thumbnail || musicVideoType?.let { it != "MUSIC_VIDEO_TYPE_ATV" } == true

/** "Gacha here! Random plays" card: tilted artworks from your library and a roll button that plays a random mix. */
@Composable
private fun GachaCard() {
    val player = LocalPlayer.current
    val liked by Library.liked.collectAsState()
    val history by Library.history.collectAsState()
    val pool = remember(liked, history) { (liked + history.map { it.song }).distinctBy { it.id } }
    if (pool.isEmpty()) return
    var seed by remember { mutableStateOf(0) }
    val picks = remember(pool, seed) { pool.shuffled().take(3) }
    val palette = rememberArtworkPalette(picks.firstOrNull()?.thumbnail, enabled = true)
    val tint = palette?.accent ?: Color(0xFFB06A5A)

    Box(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).fillMaxWidth().height(300.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.55f), Color(0xFF1A1A1C)))),
    ) {
        // Tilted artworks on the right
        picks.getOrNull(0)?.let { Artwork(it.thumbnail, Modifier.align(Alignment.TopEnd).padding(top = 18.dp, end = 60.dp).size(170.dp).rotate(8f), RoundedCornerShape(22.dp)) }
        picks.getOrNull(1)?.let { Artwork(it.thumbnail, Modifier.align(Alignment.BottomEnd).padding(bottom = 10.dp, end = 10.dp).size(150.dp).rotate(-6f), RoundedCornerShape(22.dp)) }
        picks.getOrNull(2)?.let { Artwork(it.thumbnail, Modifier.align(Alignment.TopEnd).padding(top = 40.dp, end = 230.dp).size(110.dp).rotate(-12f).alpha(0.8f), RoundedCornerShape(18.dp)) }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color.Black.copy(alpha = 0.55f), 0.5f to Color.Transparent)))

        Column(Modifier.align(Alignment.BottomStart).padding(28.dp)) {
            Icon(
                Icons.Default.PlayArrow, null, tint = Color(0xFFFF8A80),
                modifier = Modifier.size(110.dp).clickable { player.playQueue(pool.shuffled(), 0, "Random plays") },
            )
            Spacer(Modifier.height(6.dp))
            Text("Gacha here!", color = Color.White.copy(alpha = 0.7f), fontSize = 15.sp)
            Text("Random plays", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.2f))
                    .clickable { seed++; player.playQueue(pool.shuffled(), 0, "Random plays") }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Default.Casino, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("roll!!", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun HomeTitle(title: String, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).then(if (onMore != null) Modifier.clickable(onClick = onMore) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (onMore != null) {
            Spacer(Modifier.width(6.dp))
            Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** "Most Played": top 6 from history, two numbered columns like Musicfy. */
@Composable
private fun MostPlayed() {
    val player = LocalPlayer.current
    val history by Library.history.collectAsState()
    val top = remember(history) {
        history.groupBy { it.song.id }.values.sortedByDescending { it.size }.take(6).map { it.first().song }
    }
    if (top.size < 2) return
    Column {
        HomeTitle("Most Played")
        val rows = (top.size + 1) / 2
        Column(Modifier.padding(horizontal = 24.dp)) {
            repeat(rows) { r ->
                Row(Modifier.fillMaxWidth()) {
                    listOf(r, r + rows).forEach { idx ->
                        val song = top.getOrNull(idx)
                        if (song == null) { Spacer(Modifier.weight(1f)); return@forEach }
                        Row(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { player.playQueue(top, idx, "Most Played") }.padding(vertical = 6.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${idx + 1}", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(36.dp))
                            Artwork(song.thumbnail, Modifier.size(56.dp), RoundedCornerShape(10.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artists.joinToString { it.name }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Spacer(Modifier.width(12.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** "History": pages of three rows, scrolled horizontally. */
@Composable
private fun HistorySection() {
    val nav = LocalNavigator.current
    val player = LocalPlayer.current
    val history by Library.history.collectAsState()
    val songs = remember(history) { history.map { it.song }.distinctBy { it.id }.take(30) }
    if (songs.size < 4) return
    Column {
        HomeTitle("History") { nav.replaceRoot(Screen.Library) }
        LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            itemsIndexed(songs.chunked(3)) { pageIndex, page ->
                Column(Modifier.width(380.dp)) {
                    page.forEachIndexed { j, song ->
                        val index = pageIndex * 3 + j
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { player.playQueue(songs, index, "History") }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Artwork(song.thumbnail, Modifier.size(60.dp), RoundedCornerShape(12.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artists.joinToString { it.name }, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { player.playSong(song) }) { Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** "Your Playlists <name>": local playlists as square cards. */
@Composable
private fun YourPlaylists() {
    val nav = LocalNavigator.current
    val playlists by Library.playlists.collectAsState()
    val settings by Settings.state.collectAsState()
    if (playlists.isEmpty()) return
    Column {
        Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp).clickable { nav.replaceRoot(Screen.Library) }, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Person, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Your Playlists", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Text(settings.profileName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(playlists, key = { it.id }) { pl ->
                Column(Modifier.width(190.dp).clip(RoundedCornerShape(14.dp)).clickable { nav.push(Screen.LocalPlaylist(pl.id)) }.padding(4.dp)) {
                    Artwork(pl.thumbnail, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(18.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(pl.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${pl.songCount} lagu", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** YouTube section header with the small label + artist avatar ("More like Taylor Swift"). */
@Composable
private fun HomeSectionHeader(section: HomePage.Section, onMore: (() -> Unit)?) {
    Row(
        Modifier.padding(horizontal = 24.dp, vertical = 8.dp).then(if (onMore != null) Modifier.clickable(onClick = onMore) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        section.thumbnail?.let { thumb ->
            Artwork(thumb, Modifier.size(40.dp), CircleShape)
            Spacer(Modifier.width(12.dp))
        }
        Column {
            section.label?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(section.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (onMore != null) {
                    Spacer(Modifier.width(6.dp))
                    Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

/** Wide 16:9 cards for video shelves ("Music Videos for You", "Live Shows"). */
@Composable
private fun WideCarousel(videos: List<SongItem>) {
    val player = LocalPlayer.current
    LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        itemsIndexed(videos, key = { i, v -> "$i:${v.id}" }) { i, video ->
            Box(Modifier.width(420.dp).height(236.dp).clip(RoundedCornerShape(22.dp)).clickable { player.playQueue(videos, i) }) {
                ArtworkImage(video.thumbnail, Modifier.fillMaxSize(), size = 720)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent, Color.Transparent))))
                Column(Modifier.padding(18.dp)) {
                    Text(video.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(video.artists.joinToString { it.name }, color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp, maxLines = 1)
                }
            }
        }
    }
}
