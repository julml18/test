package com.redify.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Explicit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.music.innertube.models.AlbumItem
import com.music.innertube.models.ArtistItem
import com.music.innertube.models.PlaylistItem
import com.music.innertube.models.SongItem
import com.music.innertube.models.YTItem
import com.redify.desktop.LocalNavigator
import com.redify.desktop.LocalPlayer
import com.redify.desktop.Screen
import com.redify.desktop.data.Downloads
import com.redify.desktop.data.Library
import com.redify.desktop.ui.screens.AddToPlaylistDialog

fun formatDuration(seconds: Int?): String {
    if (seconds == null || seconds <= 0) return ""
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun formatMillis(ms: Long): String = formatDuration((ms / 1000).toInt()).ifEmpty { "0:00" }

private val YTIMG_FILE = Regex("/vi(_webp)?/([^/]+)/[^/?]+\\.(jpg|webp)")

/**
 * Picks a larger thumbnail where YouTube's URL template allows it.
 * - Album art (lh3.googleusercontent.com): `=w120-h120` / `=s120` → requested size.
 * - Video thumbnails (i.ytimg.com): `default.jpg` (120×90) → `maxresdefault.jpg`.
 */
fun String.hiRes(size: Int = 544): String = when {
    "ytimg.com" in this -> replace(YTIMG_FILE, "/vi$1/$2/maxresdefault.$3").substringBefore("?")
    else -> replace(Regex("=w\\d+-h\\d+"), "=w$size-h$size").replace(Regex("=s\\d+"), "=s$size")
}

/** Next-best video thumbnail when maxres doesn't exist for that video (older uploads). */
fun String.hiResFallback(): String? = when {
    "maxresdefault" in this -> replace("maxresdefault", "sddefault")
    "sddefault" in this -> replace("sddefault", "hqdefault")
    else -> null
}

/** Bare hi-res image (no clip/background) with automatic fallback when the hi-res variant is missing. */
@Composable
fun ArtworkImage(url: String, modifier: Modifier = Modifier, size: Int = 1024, contentScale: ContentScale = ContentScale.Crop) {
    var model by remember(url) { mutableStateOf(url.hiRes(size)) }
    AsyncImage(
        model = model,
        contentDescription = null,
        contentScale = contentScale,
        modifier = modifier,
        onError = { model.hiResFallback()?.let { model = it } ?: run { model = url } },
    )
}

@Composable
fun Artwork(url: String?, modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(8.dp)) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
        contentAlignment = Alignment.Center,
    ) {
        if (url != null) {
            var model by remember(url) { mutableStateOf(url.hiRes()) }
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                onError = { model.hiResFallback()?.let { model = it } ?: run { model = url } },
            )
        } else {
            Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun ErrorBox(message: String, onRetry: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(message, style = MaterialTheme.styleBody(), color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (onRetry != null) {
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onRetry) { Text("Coba lagi") }
        }
    }
}

@Composable
fun SectionHeader(title: String, label: String? = null, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            if (label != null) {
                Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (onMore != null) {
            TextButton(onClick = onMore) { Text("Lainnya") }
        }
    }
}

@Composable
fun ItemCarousel(items: List<YTItem>) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        itemsIndexed(items, key = { i, it -> "$i:${it.id}" }) { _, item -> GridItemCard(item) }
    }
}

/** Square card used on Home/Explore/Artist shelves - equivalent to Musicfy's YouTubeGridItem. */
@Composable
fun GridItemCard(item: YTItem, modifier: Modifier = Modifier) {
    val nav = LocalNavigator.current
    val player = LocalPlayer.current
    val isArtist = item is ArtistItem
    val subtitle = when (item) {
        is SongItem -> item.artists.joinToString { it.name }
        is AlbumItem -> listOfNotNull(item.year?.toString(), item.artists?.joinToString { it.name }).joinToString(" • ")
        is PlaylistItem -> item.author?.name ?: item.songCountText ?: ""
        is ArtistItem -> "Artis"
        else -> ""
    }

    Column(
        modifier
            .width(160.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable {
                when (item) {
                    is SongItem -> player.playSong(item)
                    is AlbumItem -> nav.push(Screen.Album(item.browseId))
                    is ArtistItem -> nav.push(Screen.Artist(item.id))
                    is PlaylistItem -> nav.push(Screen.Playlist(item.id))
                    else -> {}
                }
            }
            .padding(6.dp),
    ) {
        Artwork(
            url = item.thumbnail,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f),
            shape = if (isArtist) CircleShape else RoundedCornerShape(10.dp),
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (item.explicit) {
                Icon(Icons.Default.Explicit, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(4.dp))
            }
            Text(
                item.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (subtitle.isNotBlank()) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** List row used for songs in albums/playlists/search - equivalent to Musicfy's SongListItem. */
@Composable
fun SongRow(
    song: SongItem,
    index: Int? = null,
    isActive: Boolean = false,
    showArtwork: Boolean = true,
    onClick: () -> Unit,
) {
    val player = LocalPlayer.current
    val nav = LocalNavigator.current
    var menuOpen by remember { mutableStateOf(false) }
    var addToPlaylist by remember { mutableStateOf(false) }
    val likedIds by Library.likedIds.collectAsState()
    val liked = song.id in likedIds
    val downloads by Downloads.entries.collectAsState()
    val downloaded = downloads.any { it.song.id == song.id }

    if (addToPlaylist) AddToPlaylistDialog(song, onDismiss = { addToPlaylist = false })

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isActive) MaterialTheme.colorScheme.surfaceContainerHigh else MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (index != null) {
            Text(
                "${index + 1}",
                Modifier.width(32.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (showArtwork) {
            Artwork(song.thumbnail, Modifier.size(48.dp))
            Spacer(Modifier.width(14.dp))
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (song.explicit) {
                    Icon(Icons.Default.Explicit, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    song.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                listOfNotNull(song.artists.joinToString { it.name }.ifBlank { null }, song.album?.name).joinToString(" • "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (downloaded) {
            Icon(Icons.Default.DownloadDone, "Tersimpan offline", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            formatDuration(song.duration),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Box {
            IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menu") }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Putar") },
                    leadingIcon = { Icon(Icons.Default.PlayArrow, null) },
                    onClick = { menuOpen = false; onClick() },
                )
                DropdownMenuItem(
                    text = { Text("Mulai radio") },
                    leadingIcon = { Icon(Icons.Default.Radio, null) },
                    onClick = { menuOpen = false; player.playSong(song) },
                )
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                    onClick = { menuOpen = false; player.playNext(song) },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                    onClick = { menuOpen = false; player.addToQueue(song) },
                )
                DropdownMenuItem(
                    text = { Text(if (liked) "Hapus dari disukai" else "Sukai") },
                    leadingIcon = { Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null) },
                    onClick = { menuOpen = false; Library.toggleLike(song) },
                )
                DropdownMenuItem(
                    text = { Text(if (downloaded) "Hapus unduhan" else "Unduh (offline)") },
                    leadingIcon = { Icon(Icons.Default.Download, null) },
                    onClick = { menuOpen = false; if (downloaded) Downloads.delete(song.id) else Downloads.download(song) },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke playlist") },
                    leadingIcon = { Icon(Icons.Default.LibraryAdd, null) },
                    onClick = { menuOpen = false; addToPlaylist = true },
                )
                song.album?.let { album ->
                    DropdownMenuItem(
                        text = { Text("Buka album") },
                        onClick = { menuOpen = false; nav.push(Screen.Album(album.id)) },
                    )
                }
                song.artists.firstOrNull { it.id != null }?.let { artist ->
                    DropdownMenuItem(
                        text = { Text("Buka artis") },
                        onClick = { menuOpen = false; nav.push(Screen.Artist(artist.id!!)) },
                    )
                }
            }
        }
    }
}

@Composable
fun MaterialTheme.styleBody() = typography.bodyMedium
