package com.redify.desktop.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.redify.desktop.LocalNavigator
import com.redify.desktop.Screen
import com.redify.desktop.data.Library
import com.redify.desktop.data.Settings
import com.redify.desktop.importer.ImportedTrack
import com.redify.desktop.importer.LinkImportException
import com.redify.desktop.importer.LinkImporter
import com.redify.desktop.importer.ParsedImport
import com.redify.desktop.importer.TrackMatcher
import com.redify.desktop.importer.parseImportCsv
import com.redify.desktop.log
import com.music.innertube.YouTube
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.awt.FileDialog
import java.awt.Frame
import java.io.File

private data class ImportRun(
    val total: Int,
    val done: Int = 0,
    val matched: Int = 0,
    val current: String = "",
    val finished: Boolean = false,
    val unmatched: List<Pair<String, ImportedTrack>> = emptyList(),
    val created: List<Long> = emptyList(),
)

/**
 * Import playlists from Spotify / Apple Music / Deezer / YouTube Music share links, or from a
 * CSV export (TuneMyMusic, Exportify, Musicfy backup). Same engine as Musicfy's importer:
 * each track is matched to a YouTube Music song and saved into a local playlist.
 */
@Composable
fun ImportScreen() {
    val nav = LocalNavigator.current
    val scope = rememberCoroutineScope()
    var link by remember { mutableStateOf("") }
    var reading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var parsed by remember { mutableStateOf<ParsedImport?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    var importLiked by remember { mutableStateOf(true) }
    var mirrorToYouTube by remember { mutableStateOf(false) }
    var run by remember { mutableStateOf<ImportRun?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    fun setParsed(p: ParsedImport) {
        parsed = p
        selected.clear(); selected.addAll(p.playlists.keys)
        run = null
        error = null
    }

    fun readLink() {
        if (link.isBlank()) return
        reading = true; error = null
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { LinkImporter.fetch(link) } }
                .onSuccess { setParsed(it) }
                .onFailure { e ->
                    error = if (e is LinkImportException) e.message else "Gagal membaca tautan: ${e.message}"
                    log("import link failed", e)
                }
            reading = false
        }
    }

    fun pickCsv() {
        val dialog = FileDialog(null as Frame?, "Pilih file CSV", FileDialog.LOAD).apply {
            setFilenameFilter { _, name -> name.endsWith(".csv", true) || name.endsWith(".txt", true) }
            isVisible = true
        }
        val file = dialog.file?.let { File(dialog.directory, it) } ?: return
        runCatching { parseImportCsv(file.readText(), file.nameWithoutExtension) }
            .onSuccess { setParsed(it) }
            .onFailure { error = "CSV tidak bisa dibaca: ${it.message}" }
    }

    fun startImport() {
        val p = parsed ?: return
        val playlists = p.playlists.filterKeys { it in selected }
        val liked = if (importLiked) p.likedSongs else emptyList()
        val total = playlists.values.sumOf { it.size } + liked.size
        if (total == 0) return
        run = ImportRun(total = total)
        job = scope.launch(Dispatchers.IO) {
            val matcher = TrackMatcher()
            val unmatched = mutableListOf<Pair<String, ImportedTrack>>()
            val created = mutableListOf<Long>()
            var done = 0; var matched = 0

            suspend fun process(track: ImportedTrack, playlistName: String?, onFound: suspend (com.music.innertube.models.SongItem) -> Unit) {
                if (!isActive) return
                run = run?.copy(current = "${track.artist} – ${track.title}")
                val song = track.ytItem ?: runCatching { matcher.match(track) }.getOrNull()
                if (song != null) { matched++; onFound(song) } else unmatched += (playlistName ?: "Disukai") to track
                done++
                run = run?.copy(done = done, matched = matched, unmatched = unmatched.toList())
            }

            for ((name, tracks) in playlists) {
                if (!isActive) break
                val id = Library.createPlaylistSync(name)
                created += id
                val ytIds = mutableListOf<String>()
                for (t in tracks) process(t, name) { song ->
                    Library.addToPlaylistSync(id, song)
                    ytIds += song.id
                }
                Library.refreshPlaylistsNow()
                if (mirrorToYouTube && Settings.current.isLoggedIn && ytIds.isNotEmpty()) {
                    runCatching {
                        val ytId = YouTube.createPlaylist(name)
                        YouTube.addVideosToPlaylist(ytId, ytIds)
                    }.onFailure { log("mirror playlist to YouTube failed", it) }
                }
            }
            for (t in liked) process(t, null) { song -> if (!Library.isLiked(song.id)) Library.toggleLike(song).join() }

            run = run?.copy(finished = true, current = "", created = created, unmatched = unmatched.toList())
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Impor playlist", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Dari tautan publik Spotify, Apple Music, Deezer, atau YouTube Music — atau dari file CSV (TuneMyMusic, Exportify). " +
                "Setiap lagu dicocokkan ke YouTube Music lalu disimpan ke playlist lokal.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = link,
                    onValueChange = { link = it },
                    singleLine = true,
                    label = { Text("Tautan playlist / album") },
                    placeholder = { Text("https://open.spotify.com/playlist/…") },
                    leadingIcon = { Icon(Icons.Default.Link, null) },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = ::readLink, enabled = link.isNotBlank() && !reading) { Text("Baca tautan") }
                    OutlinedButton(onClick = ::pickCsv, enabled = !reading) {
                        Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(6.dp)); Text("Pilih file CSV")
                    }
                    if (reading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Text(
                    "Playlist pribadi tidak bisa dibaca dari tautan. Untuk itu, ekspor dulu ke CSV lewat tunemymusic.com atau exportify.net, lalu pilih file-nya di sini.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        parsed?.let { p ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "${p.provider?.label ?: "Sumber"}: ${p.totalPlaylists} playlist, ${p.totalSongs} lagu",
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    )
                    p.warnings.forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                    p.playlists.forEach { (name, tracks) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = name in selected,
                                onCheckedChange = { if (it) selected.add(name) else selected.remove(name) },
                                enabled = run == null,
                            )
                            Text(name, Modifier.weight(1f))
                            Text("${tracks.size} lagu", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (p.likedSongs.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = importLiked, onCheckedChange = { importLiked = it }, enabled = run == null)
                            Text("Lagu disukai", Modifier.weight(1f))
                            Text("${p.likedSongs.size} lagu", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (Settings.current.isLoggedIn) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = mirrorToYouTube, onCheckedChange = { mirrorToYouTube = it }, enabled = run == null)
                            Text("Buat juga playlist-nya di akun YouTube Music saya")
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    val r = run
                    if (r == null) {
                        Button(onClick = ::startImport, enabled = selected.isNotEmpty() || (importLiked && p.likedSongs.isNotEmpty())) {
                            Text("Mulai impor")
                        }
                    } else {
                        LinearProgressIndicator(progress = { if (r.total == 0) 0f else r.done.toFloat() / r.total }, modifier = Modifier.fillMaxWidth())
                        Text(
                            if (r.finished) "Selesai: ${r.matched} dari ${r.total} lagu ditemukan"
                            else "Mencocokkan ${r.done + 1} / ${r.total}: ${r.current}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!r.finished) TextButton(onClick = { job?.cancel(); run = r.copy(finished = true) }) { Text("Batalkan") }
                            if (r.finished && r.created.isNotEmpty()) {
                                Button(onClick = { nav.push(Screen.LocalPlaylist(r.created.first())) }) { Text("Buka playlist") }
                                TextButton(onClick = { nav.replaceRoot(Screen.Library) }) { Text("Ke Koleksi") }
                            }
                        }
                        if (r.finished && r.unmatched.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text("Tidak ditemukan di YouTube Music (${r.unmatched.size}):", fontWeight = FontWeight.SemiBold)
                            r.unmatched.take(50).forEach { (pl, t) ->
                                Text("• ${t.artist} – ${t.title}  ($pl)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (r.unmatched.size > 50) Text("…dan ${r.unmatched.size - 50} lagi", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(170.dp))
    }
}
