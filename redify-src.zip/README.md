# Redify 2.0 (desktop)

Versi Windows/desktop yang diturunkan dari [Musicfy](https://github.com/realidkroo/musicfy) (Android),
dibangun dengan Compose Multiplatform. Modul `innertube` (koneksi ke YouTube Music) dan `lrclib`
(lirik) dipakai ulang 1:1 dari proyek Android; UI dan pemutar audio ditulis ulang untuk desktop.

## Fitur

Tahap 1
- Beranda (dengan chip filter) dan Jelajahi (rilis baru, mood & genre)
- Pencarian dengan saran, filter Lagu/Video/Album/Artis/Playlist, scroll tanpa batas
- Halaman Album, Artis, Playlist, dan halaman "Lainnya"
- Pemutar: play/pause, next/prev, seek, volume, acak, ulangi, radio otomatis
- Panel antrean; menu per lagu; tombol media keyboard
- Tema monokrom sama persis dengan Musicfy Android

Tahap 2
- Login akun YouTube Music (tempel cookie, sama seperti "login via cookie" di Musicfy)
  → Beranda personal, Koleksi → Akun YouTube (lagu disukai, playlist, album tersimpan)
- Koleksi lokal (SQLite): lagu disukai, playlist lokal (buat/ganti nama/hapus/tambah/hapus lagu), riwayat
- Tombol hati di pemutar dan menu lagu; "Tambah ke playlist"
- Panel lirik: lirik tersinkron dari LRCLIB (klik baris untuk lompat), fallback lirik YouTube Music
- Pengaturan: akun, tema gelap/terang; volume tersimpan

Tahap 3
- Unduh offline: per lagu (menu ⋮), "Unduh semua" di album/playlist; tab Koleksi → Unduhan dengan progres;
  lagu yang sudah diunduh diputar dari file lokal tanpa internet (ikon ✓ di baris lagu)
- Equalizer 10-band LibVLC dengan preset bawaan VLC, preamp, dan reset (di Pengaturan)
- Like tersinkron ke akun YouTube Music saat sudah login
- "Warna dari sampul album": palet warna aplikasi mengikuti sampul lagu yang diputar (port dari ArtworkPalette Musicfy)

Redify 2.0 — UI mengikuti Musicfy Android
- Beranda: hero "Continue" dengan sampul lagu, Recently Played (kartu Disukai + riwayat), lalu rekomendasi YouTube Music
- Mini-player pill dan navigasi pill mengambang (Beranda / Cari / Koleksi / Pengaturan)
- Layar pemutar: piringan hitam berputar + tonearm, tombol bulat di kanan, menu (Other menu, Sleep timer, See video, Repeat), chip codec
- Mode antrean: Now Playing / Continue Playing, tombol acak & ulangi mengambang, progress bar, transport besar
- Mode lirik karaoke: sorotan berjalan per kata, baris lewat meredup, posisi diinterpolasi tiap frame + offset lirik (±100 ms) agar sinkron
- Pill lirik satu baris di bawah pemutar
- Bottom sheet "Other menu": volume, output device, sleep timer, kecepatan putar, add to playlist/liked, download, share
- Tab Profil: "Hello again", kartu ID, Total Listening time, versi; hub Pengaturan dengan kategori General / Appearance / Playback / Audio / Audio Lab / Modules
  (mode offline, don't skip on failure + skip timeout, badge format & sample rate, blur & kekuatannya, simpan/pulihkan state terakhir, kualitas audio Auto/High/Medium/Low, normalisasi loudness, crossfade dua deck)

Tahap 4
- Impor playlist dari tautan publik Spotify / Apple Music / Deezer / YouTube Music, atau file CSV (TuneMyMusic, Exportify)
  → tiap lagu dicocokkan ke YouTube Music (TrackMatcher Musicfy) dan disimpan ke playlist lokal; opsi cermin ke akun YouTube
- Lirik layar penuh (Now Playing) dengan palet warna sampul

Belum ada (khas Android, tidak ada padanan di Windows): Android Auto, widget, Discord RPC/Kizzy, ShazamKit.

## Cara build jadi .exe / .msi (Windows)

Prasyarat di PC:
1. **JDK 21** – https://adoptium.net (Temurin 21, Windows x64 .msi)
2. **VLC media player 64-bit** – https://www.videolan.org/vlc/download-windows.html
   (mesin audio; wajib ada saat aplikasi dijalankan)

Di folder proyek ini (PowerShell / CMD):

```
gradlew.bat :app:run            # jalankan langsung
gradlew.bat :app:packageMsi     # installer -> app\build\compose\binaries\main\msi\Redify-2.0.0.msi
gradlew.bat :app:packageExe     # installer .exe
```

Build pertama mengunduh Gradle + dependensi (±500 MB).

### Tanpa install apa pun: build lewat GitHub
Push folder ini ke repo GitHub. Workflow `.github/workflows/build-windows.yml` otomatis membuat
installer `.msi` di tab **Actions → Build Windows installer → Artifacts**.

## Struktur
```
innertube/   modul API YouTube Music (salinan dari providers/innertube Musicfy, build JVM murni)
lrclib/      modul lirik LRCLIB (salinan dari providers/lrclib Musicfy)
app/
  data/Settings.kt        preferensi + sesi login (settings.json di AppData\Redify)
  data/Library.kt         SQLite: disukai, playlist, riwayat (library.db)
  data/Lyrics.kt          pencarian lirik LRCLIB → YouTube
  data/Downloads.kt       unduhan offline (downloads.json + folder downloads)
  playback/StreamResolver.kt   ambil URL audio (port ringkas dari YTPlayerUtils)
  playback/PlayerController.kt antrean + transport, mesin audio LibVLC (vlcj)
  ui/                     tema, palet warna sampul, komponen, PlayerBar, QueuePanel, LyricsPanel
  ui/screens/             Home, Explore, Search, Album, Artist, Playlist, Browse, Library, Settings
```

## Catatan
- Kode ditulis tanpa bisa dikompilasi di lingkungan pembuatnya (repositori Maven diblokir), jadi
  build pertama mungkin memunculkan beberapa error kecil (import/nama API). Kirimkan output
  error-nya untuk diperbaiki.
- Jika lagu tidak bisa diputar, YouTube kemungkinan mengubah mekanisme stream; `StreamResolver`
  mencoba beberapa client lalu jatuh ke NewPipeExtractor.
